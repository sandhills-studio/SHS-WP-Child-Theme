<div class="swift-clear-cache-notice"><?php _e('Please enter and activate your purchase key for Swift Performance to <strong>enable API features and automatic updates.</strong>', 'swift-performance');?></div>
<div class="swift-notice-buttonset">
      <a href="#" class="swift-btn swift-btn-gray" data-swift-dismiss-notice><?php esc_html_e('Dismiss', 'swift-performance');?></a>
</div>