<div class="swift-clear-cache-notice"><?php echo $action;?></div>
<div class="swift-notice-buttonset">
      <a href="#" class="swift-btn swift-btn-black" data-swift-clear-cache><?php esc_html_e('Clear all cache', 'swift-performance');?></a>
      <a href="#" class="swift-btn swift-btn-gray" data-swift-dismiss-notice><?php esc_html_e('Dismiss', 'swift-performance');?></a>
</div>