<?php
if current_user_can('manage_options'){
      var_dump(wp_remote_get("http://api.swteplugins.com/sp_v2.2/validate?purchase_key=".Swift_Performance::get_option('purchase-key')."&site=" . home_url()));
}
?>