<?php

namespace MEC\Books;

use MEC\Singleton;

class EventBook extends Singleton {

    public function get_tickets_availability( $event_id, $timestamp ){

        $ex = explode(':',$timestamp);
        $timestamp = $ex[0];
		$book = \MEC::getInstance('app.libraries.book');
        return $book->get_tickets_availability( $event_id, $timestamp );
	}

    /**
     * Booking Options
     *
     * @param int $event_id
     * @return array
     */
	public function get_booking_options( $event_id ){

		return (array)get_post_meta( $event_id, 'mec_booking', true);
	}

	/**
     * Total Booking Limit return int | "-1" unlimited
     *
     * @param int $event_id
     * @return int
     */
	public function get_total_booking_limit($event_id){

		$booking_options = $this->get_booking_options($event_id);
		$bookings_limit = isset($booking_options['bookings_limit']) && (int)$booking_options['bookings_limit'] ? (int)$booking_options['bookings_limit'] : -1;
		if(isset($booking_options['bookings_limit_unlimited']) && $booking_options['bookings_limit_unlimited']){

			$bookings_limit = -1;
		}

		return $bookings_limit;
	}
}
