<?php declare(strict_types = 1);

namespace MailPoet\Premium\Automation\Integrations\MailPoetPremium\Analytics\Controller;

if (!defined('ABSPATH')) exit;


use DateTimeImmutable;
use MailPoet\Automation\Engine\Data\Automation;
use MailPoet\Automation\Engine\Data\AutomationRun;
use MailPoet\Automation\Engine\Data\AutomationRunLog;
use MailPoet\Automation\Engine\Data\Step;
use MailPoet\Automation\Engine\Registry;
use MailPoet\Automation\Engine\Storage\AutomationRunLogStorage;
use MailPoet\Automation\Engine\Utils\Json;
use MailPoet\Automation\Engine\WordPress;
use MailPoet\Automation\Integrations\Core\Actions\DelayAction;
use MailPoet\Automation\Integrations\MailPoet\Subjects\SubscriberSubject;
use MailPoet\Entities\SubscriberEntity;
use MailPoet\Subscribers\SubscribersRepository;

/**
 * @phpstan-type NextStepProps array{
 *   name: string,
 *   time_left: string,
 *   step: array<string, mixed>
 * } | null
 *
 * @phpstan-type AutomationRunDataProps array{
 *   run: array{
 *     id: int,
 *     automation_id: int,
 *     status: string
 *   },
 *   logs: array<array{
 *     id: int,
 *     automation_run_id: int,
 *     step_id: string,
 *     step_type: string,
 *     step_key: string,
 *     step_name: string,
 *     status: string,
 *     started_at: string,
 *     updated_at: string,
 *     run_number: int,
 *     data: string,
 *     error: ?array<string, mixed>
 *   }>,
 *   next_step: NextStepProps,
 *   automation: array{
 *     steps: array<array{
 *       id: string,
 *       type: string,
 *       key: string,
 *       next_steps: array<array{id: string}>,
 *       args: array<string, mixed>,
 *       filters: ?array<string, mixed>
 *     }>
 *   },
 *   subscriber: ?array{
 *     id: int,
 *     email: string,
 *     first_name: string,
 *     last_name: string,
 *     avatar: string|false
 *   }
 * }
 */
class RunLogController {
  private AutomationRunLogStorage $automationRunLogStorage;
  private Registry $registry;
  private SubscribersRepository $subscribersRepository;
  private WordPress $wp;

  public function __construct(
    AutomationRunLogStorage $automationRunLogStorage,
    Registry $registry,
    SubscribersRepository $subscribersRepository,
    WordPress $wp
  ) {
    $this->automationRunLogStorage = $automationRunLogStorage;
    $this->registry = $registry;
    $this->subscribersRepository = $subscribersRepository;
    $this->wp = $wp;
  }

  /** @return AutomationRunDataProps */
  public function getAutomationRunData(Automation $automation, AutomationRun $automationRun): array {
    $automationRunLogs = $this->automationRunLogStorage->getLogsForAutomationRun($automationRun->getId());
    $subscriber = $this->getAutomationRunSubscriber($automationRun);
    return $this->mapAutomationRunData($automationRun, $automationRunLogs, $automation, $subscriber);
  }

  private function getAutomationRunSubscriber(AutomationRun $automationRun): ?SubscriberEntity {
    $subjects = $automationRun->getSubjects(SubscriberSubject::KEY);
    if (empty($subjects)) {
      return null;
    }
    $subscriberSubject = reset($subjects);
    $id = $subscriberSubject->getArgs()['subscriber_id'];
    return $this->subscribersRepository->findOneById($id);
  }

  private function calculateDelaySchedule(AutomationRunLog $lastLog, Step $nextStep): int {
    if ($nextStep->getKey() !== DelayAction::KEY) {
      return 0;
    }
    return $lastLog->getUpdatedAt()->getTimestamp() + DelayAction::calculateSeconds($nextStep);
  }

  /**
   * @param AutomationRunLog[] $automationRunLogs
   * @return NextStepProps
   */
  private function getNextStep(Automation $automation, AutomationRun $automationRun, array $automationRunLogs): ?array {
    if ($automationRun->getStatus() !== AutomationRun::STATUS_RUNNING) {
      return null;
    }
    $lastLog = end($automationRunLogs);
    if (!$lastLog) {
      return null;
    }
    $lastStep = $automation->getStep($lastLog->getStepId());
    $nextStepIds = $lastStep ? $lastStep->getNextStepIds() : [];
    if (count($nextStepIds) !== 1) {
      return null;
    }
    $nextStep = $automation->getStep($nextStepIds[0]);
    if (!$nextStep) {
      return null;
    }
    $registryStep = $this->registry->getStep($nextStep->getKey());
    return [
      'name' => $registryStep ? $registryStep->getName() : '',
      'time_left' => $this->wp->humanTimeDiff(time(), $this->calculateDelaySchedule($lastLog, $nextStep)),
      'step' => $nextStep->toArray(),
    ];
  }

  /**
   * @param AutomationRunLog[] $automationRunLogs
   * @return AutomationRunDataProps
   */
  private function mapAutomationRunData(
    AutomationRun $automationRun,
    array $automationRunLogs,
    Automation $automation,
    ?SubscriberEntity $subscriber
  ): array {
    return [
      'run' => [
        'id' => $automationRun->getId(),
        'automation_id' => $automationRun->getAutomationId(),
        'status' => $automationRun->getStatus(),
      ],
      'logs' => array_map(
        function ($automationRunLog): array {
          $stepKey = $automationRunLog->getStepKey();
          // translators: %s is step ID
          $stepName = sprintf(__('Unknown step: %s', 'mailpoet-premium'), $stepKey);
          $step = $this->registry->getStep($stepKey);
          if ($step && $step->getName() !== '') {
            $stepName = $step->getName();
          }
          return [
            'id' => $automationRunLog->getId(),
            'automation_run_id' => $automationRunLog->getAutomationRunId(),
            'step_id' => $automationRunLog->getStepId(),
            'step_type' => $automationRunLog->getStepType(),
            'step_key' => $automationRunLog->getStepKey(),
            'step_name' => $stepName,
            'status' => $automationRunLog->getStatus(),
            'started_at' => $automationRunLog->getStartedAt()->format(DateTimeImmutable::W3C),
            'updated_at' => $automationRunLog->getUpdatedAt()->format(DateTimeImmutable::W3C),
            'run_number' => $automationRunLog->getRunNumber(),
            'data' => Json::encode($automationRunLog->getData()),
            'error' => $automationRunLog->getError(),
          ];
        },
        $automationRunLogs
      ),
      'next_step' => $this->getNextStep($automation, $automationRun, $automationRunLogs),
      'automation' => [
        'steps' => array_map(
          function ($step): array {
            return [
              'id' => $step->getId(),
              'type' => $step->getType(),
              'key' => $step->getKey(),
              'next_steps' => array_map(function (string $nextStepId) {
                return ['id' => $nextStepId];
              }, $step->getNextStepIds()),
              'args' => $step->getArgs(),
              'filters' => $step->getFilters() ? $step->getFilters()->toArray() : null,
            ];
          },
          $automation->getSteps()
        ),
      ],
      'subscriber' => $subscriber ? [
        'id' => (int)$subscriber->getId(),
        'email' => $subscriber->getEmail(),
        'first_name' => $subscriber->getFirstName(),
        'last_name' => $subscriber->getLastName(),
        'avatar' => $this->wp->getAvatarUrl($subscriber->getEmail(), ['size' => 40]),
      ] : null,
    ];
  }
}
