<?php
/**
 * Template Library Header Template
 */
?>
<label>
	<input type="radio" value="{{ term_slug }}" name="bdt-elementpack-library-tab">
	<span>{{ title }}</span>
</label>