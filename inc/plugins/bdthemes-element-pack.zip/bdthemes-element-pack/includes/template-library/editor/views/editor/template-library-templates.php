<?php
/**
 * Templates list view
 */
?>
<div id="bdt-elementpack-template-library-templates-container"></div>