<?php
/* This file was automatically generated (Fri Oct 16 2020 15:23:27 GMT+0000 (Coordinated Universal Time)). */
return array(
	'es6-shim' => '0.35.5',
	'es7-shim' => '6.0.0',
	'i18n-react' => '0.7.0',
	'mobx' => '4.15.7',
	'mobx-state-tree' => '3.17.2',
	'react' => '16.13.1',
	'react-aiot' => '1.5.3',
	'react-dom' => '16.13.1',
	'wp-media-picker' => '0.7.2'
);
