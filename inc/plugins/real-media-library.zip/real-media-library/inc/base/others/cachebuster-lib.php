<?php
// Cachebusters generated on 2023-09-29 06:01:22
return [
	'antd' => '3.8.4',
	'classnames' => '2.3.2',
	'enzyme' => '3.11.0',
	'i18n-react' => '0.7.0',
	'jquery' => '3.6.4',
	'lil-uri' => '0.3.1',
	'lodash' => '4.17.21',
	'mobx' => '4.15.7',
	'mobx-react' => '6.3.1',
	'mobx-state-tree' => '3.17.3',
	'react' => '16.14.0',
	'react-aiot' => '1.8.0',
	'react-dom' => '16.14.0'
];
