<?php
/* This file was automatically generated (Wed May 12 2021 10:58:36 GMT+0000 (Coordinated Universal Time)). */
return [
    'src/public/dist/rml_gutenberg.lite.js' => 'f5afd95508cffe393f6197bb611d99a9',
    'src/public/dist/rml_gutenberg.pro.js' => '1e417a01652fc3866e5d9a47fe26e0ae',
    'src/public/dist/rml_shortcode.lite.js' => '08fb88a5ccdfde4933870e898c2c05b8',
    'src/public/dist/rml_shortcode.pro.js' => '3b3720f6092431f26a43a87889cd1266',
    'src/public/dist/rml.lite.js' => '4fd73bba9fed60eac4c9e8a0d0dbff6f',
    'src/public/dist/rml.pro.js' => 'fdbe49767120813a1587c0676a2bc3c7',
    'src/public/dist/rml.css' => '0bf2a70f80c8b160b8e09254dd2aacb4'
];
