<?php
// Cachebusters generated on 2023-09-29 06:02:17
return [
	'src/public/dist/i18n-dependency-map-default-lite.json'=> '99914b932bd37a50b983c5e7c90ae93b',
	'src/public/dist/i18n-dependency-map-default-pro.json'=> '99914b932bd37a50b983c5e7c90ae93b',
	'src/public/dist/rml.css'=> 'b608312c801138cc99484be3ae94a309',
	'src/public/dist/rml.css.map'=> '6082f4febc38cdfa727e63fc47577365',
	'src/public/dist/rml.lite.js'=> '4bf689644a491e64ef67807e1b57ef95',
	'src/public/dist/rml.lite.js.LICENSE.txt'=> '3f4acc96697998db106cf76b25abccf2',
	'src/public/dist/rml.lite.js.map'=> 'cb06e5ee693c27c4709f36d7784a98ca',
	'src/public/dist/rml.pro.js'=> '970d08286034785f8c93327d84a528d9',
	'src/public/dist/rml.pro.js.LICENSE.txt'=> '3f4acc96697998db106cf76b25abccf2',
	'src/public/dist/rml.pro.js.map'=> '5b8c9a46379e6f46c34fa32487d381d7',
	'src/public/dist/rml_gutenberg.lite.js'=> '7400d9b23a15253d6ad4970e1cd2538f',
	'src/public/dist/rml_gutenberg.lite.js.map'=> '7976a4c0d8fa1cb4f75a5be2108fcba7',
	'src/public/dist/rml_gutenberg.lite.js.pot'=> '43b22b0ff1681d57cfabd31528efba0f',
	'src/public/dist/rml_gutenberg.pro.js'=> '33794df649662531f2ac528e0917b9ae',
	'src/public/dist/rml_gutenberg.pro.js.map'=> 'a4b9aa05e80e16a1a97eb6d6d52894e9',
	'src/public/dist/rml_gutenberg.pro.js.pot'=> '36dd2b222c3004c5ea5f86281c58daa8',
	'src/public/dist/rml_shortcode.lite.js'=> '79eacbb62e52a91ab0595e2b41a433b0',
	'src/public/dist/rml_shortcode.lite.js.LICENSE.txt'=> 'd960069effec2b9f973800d234445d78',
	'src/public/dist/rml_shortcode.lite.js.map'=> '753f73f18cad705ee47b00562f237ee9',
	'src/public/dist/rml_shortcode.pro.js'=> 'cf6254d5c4b55f8e8eca5d3567385f13',
	'src/public/dist/rml_shortcode.pro.js.LICENSE.txt'=> 'd960069effec2b9f973800d234445d78',
	'src/public/dist/rml_shortcode.pro.js.map'=> '333e52f6415ad67001b0eb997cfa19ec'
];
