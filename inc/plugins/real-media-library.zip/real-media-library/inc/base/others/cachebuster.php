<?php
/* This file was automatically generated (Sat Jun 05 2021 15:23:36 GMT+0000 (Coordinated Universal Time)). */
return [
    'src/public/dist/rml_gutenberg.lite.js' => 'c0815a80d91c9ad2018a9a4cf1af19ac',
    'src/public/dist/rml_gutenberg.pro.js' => '42badfb484940b6070343e63507fd266',
    'src/public/dist/rml_shortcode.lite.js' => 'e73da7ff0905e47b295cbe447ec42e84',
    'src/public/dist/rml_shortcode.pro.js' => '6820ce04c72472b5675148fdba8abab7',
    'src/public/dist/rml.lite.js' => '18c2eb0a01f03bc295518f6675789517',
    'src/public/dist/rml.pro.js' => '03b3ef0adf2c3576dcf2a80bf5e87daa',
    'src/public/dist/rml.css' => '05d076d905bea4538f0f202b133e37dc'
];
