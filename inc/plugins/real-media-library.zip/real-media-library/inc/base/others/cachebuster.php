<?php
/* This file was automatically generated (Fri Oct 16 2020 15:23:27 GMT+0000 (Coordinated Universal Time)). */
return array(
	'src/public/dist/rml_gutenberg.lite.js' => 'fd2ddfe644aa0d19603bdc226ced39ea',
	'src/public/dist/rml_gutenberg.pro.js' => '3fcf6e26174e2bf42f7956a3b642f799',
	'src/public/dist/rml_shortcode.lite.js' => '78ff08ab98544a7d6d43e27c13e8cdf2',
	'src/public/dist/rml_shortcode.pro.js' => '954f2e1c9e8ae4ea98367fd1d2323ed8',
	'src/public/dist/rml.lite.js' => 'bd050ccc303180f04bb237d3637f5c16',
	'src/public/dist/rml.pro.js' => '66bf739c9e25f3f2a1a6274b5979623c',
	'src/public/dist/rml.css' => '2399cfca36564fa348d31942951e8a71',
);
