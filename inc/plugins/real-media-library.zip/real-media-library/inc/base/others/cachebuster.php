<?php
// Cachebusters generated on 2024-07-17 13:57:38
return [
	'src/public/dist/i18n-dependency-map-default-lite.json'=> '99914b932bd37a50b983c5e7c90ae93b',
	'src/public/dist/i18n-dependency-map-default-pro.json'=> '99914b932bd37a50b983c5e7c90ae93b',
	'src/public/dist/rml.css'=> 'e40967b0632fe996f98a4ee78d14c729',
	'src/public/dist/rml.css.map'=> '3a2a28273b5f77ea9d4a64b562b2d94b',
	'src/public/dist/rml.lite.js'=> 'c0c9ac552d375c7d0b13c4eb7e8901a5',
	'src/public/dist/rml.lite.js.LICENSE.txt'=> '6e1a51f587c97ad0f1c7a9d64f94fb7b',
	'src/public/dist/rml.lite.js.map'=> '21c15affe345aa07ee54132fff1fe550',
	'src/public/dist/rml.pro.js'=> '3affcc9b0f0495d7f727e23a0de6e034',
	'src/public/dist/rml.pro.js.LICENSE.txt'=> '6e1a51f587c97ad0f1c7a9d64f94fb7b',
	'src/public/dist/rml.pro.js.map'=> 'c39937b79de9b1c5bbb64c83edd5063d',
	'src/public/dist/rml_gutenberg.lite.js'=> '4b252c0aebd108afb1157089c4234165',
	'src/public/dist/rml_gutenberg.lite.js.LICENSE.txt'=> '857350bf225de6163ed47691b1d0e94e',
	'src/public/dist/rml_gutenberg.lite.js.map'=> 'd1e1336368c8b479c3688d2578e0506a',
	'src/public/dist/rml_gutenberg.lite.js.pot'=> '43b22b0ff1681d57cfabd31528efba0f',
	'src/public/dist/rml_gutenberg.pro.js'=> '8ffb1dc6141eacbb0423407eeef9f8e2',
	'src/public/dist/rml_gutenberg.pro.js.LICENSE.txt'=> '857350bf225de6163ed47691b1d0e94e',
	'src/public/dist/rml_gutenberg.pro.js.map'=> '19de019d6a010f4968cf1c44b95b9f10',
	'src/public/dist/rml_gutenberg.pro.js.pot'=> '36dd2b222c3004c5ea5f86281c58daa8',
	'src/public/dist/rml_shortcode.lite.js'=> '67d52c11d2a7d18b5e5ada62c5600932',
	'src/public/dist/rml_shortcode.lite.js.LICENSE.txt'=> 'a452c2a88a62bfc69c9ec594992200c5',
	'src/public/dist/rml_shortcode.lite.js.map'=> 'd5bf72be6f2ccea512fd20f92cb14790',
	'src/public/dist/rml_shortcode.pro.js'=> '2eb976038c24f945de8d04768e089c95',
	'src/public/dist/rml_shortcode.pro.js.LICENSE.txt'=> 'a452c2a88a62bfc69c9ec594992200c5',
	'src/public/dist/rml_shortcode.pro.js.map'=> 'dc259498a32f2ed863ac9d4fbd3dda38'
];
