<?php
/* This file was automatically generated (Wed Jul 06 2022 09:43:04 GMT+0000 (Coordinated Universal Time)). */
return [
    'src/public/dist/rml_gutenberg.lite.js' => '3d37a223a96263169ae2b80a657401a6',
    'src/public/dist/rml_gutenberg.pro.js' => '092861083b3d0f93be211d69a05f4ecd',
    'src/public/dist/rml_shortcode.lite.js' => 'ac9b5017d28809a9b30c828ee021b698',
    'src/public/dist/rml_shortcode.pro.js' => 'e5b64b988d0333c152334a6da4a01250',
    'src/public/dist/rml.lite.js' => 'e7dfcefba0fa86893f47364d01a5e192',
    'src/public/dist/rml.pro.js' => '2690e28ec633804d7c48fe0eb99fa348',
    'src/public/dist/rml.css' => '80921e7231fad25062760f4dcf18d25c'
];
