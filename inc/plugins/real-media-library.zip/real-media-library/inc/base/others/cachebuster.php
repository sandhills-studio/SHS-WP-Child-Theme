<?php
/* This file was automatically generated (Fri Aug 20 2021 08:55:48 GMT+0000 (Coordinated Universal Time)). */
return [
    'src/public/dist/rml_gutenberg.lite.js' => 'c0815a80d91c9ad2018a9a4cf1af19ac',
    'src/public/dist/rml_gutenberg.pro.js' => '42badfb484940b6070343e63507fd266',
    'src/public/dist/rml_shortcode.lite.js' => 'e73da7ff0905e47b295cbe447ec42e84',
    'src/public/dist/rml_shortcode.pro.js' => '6820ce04c72472b5675148fdba8abab7',
    'src/public/dist/rml.lite.js' => '4a23b6998c2319f197e2f4ddc601a6fe',
    'src/public/dist/rml.pro.js' => 'ab9a027c1667bab7653f73b0030164aa',
    'src/public/dist/rml.css' => '05d076d905bea4538f0f202b133e37dc'
];
