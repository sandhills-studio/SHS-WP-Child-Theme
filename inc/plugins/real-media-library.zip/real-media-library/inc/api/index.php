<?php



// Silence is golden.
