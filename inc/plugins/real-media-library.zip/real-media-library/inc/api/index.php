<?php

// namespace MatthiasWeb\RealMediaLibrary\Vendor; // excluded from scope due to API exposing

// Silence is golden.
