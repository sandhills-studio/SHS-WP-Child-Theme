<div class="info-banner-content-wrapper" >
	<div class="info-banner-front-content">
	<?php echo $list_img.$list_title.$list_sub_title; ?>
	</div>
	<div class="info-banner-back-content">
		<div class="info-banner-back-content-inner">
			<?php echo $description.$loop_button; ?>
		</div>
	</div>

</div>
