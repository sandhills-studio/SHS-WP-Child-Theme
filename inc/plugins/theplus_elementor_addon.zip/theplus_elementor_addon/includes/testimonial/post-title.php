<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<div class="post-title"><?php echo esc_html(get_the_title()); ?></div>