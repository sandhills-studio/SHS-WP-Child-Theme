<div class="entry-content">
	<?php echo $caption; ?>
</div>