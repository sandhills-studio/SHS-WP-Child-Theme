<?php

namespace MailPoet\Models;

if (!defined('ABSPATH')) exit;


class Log extends Model {
  public static $_table = MP_LOG_TABLE; // phpcs:ignore PSR2.Classes.PropertyDeclaration

}
