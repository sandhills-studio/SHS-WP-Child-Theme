<?php
/**
 * Elementor Product Tab Widget
 *
 * @package Woostify Pro
 */

namespace Elementor;

/**
 * Class woostify elementor product tab widget.
 */
class Woostify_Elementor_Product_Tab_Widget extends Widget_Base {
	/**
	 * Category
	 */
	public function get_categories() {
		return [ 'woostify-theme' ];
	}

	/**
	 * Name
	 */
	public function get_name() {
		return 'woostify-product-tab';
	}

	/**
	 * Title
	 */
	public function get_title() {
		return esc_html__( 'Woostify - Product Tab', 'woostify-pro' );
	}

	/**
	 * Icon
	 */
	public function get_icon() {
		return 'eicon-product-tabs';
	}

	/**
	 * Controls
	 */
	protected function _register_controls() {
		$this->general();
		$this->styles();
	}

	/**
	 * General
	 */
	private function general() {
		$this->start_controls_section(
			'general',
			[
				'label' => esc_html__( 'General', 'woostify-pro' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'   => __( 'Title', 'woostify-pro' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'List Title' , 'woostify-pro' ),
			]
		);

		$repeater->add_control(
			'data',
			[
				'label'     => __( 'Source', 'woostify-pro' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'select',
				'separator' => 'before',
				'options'   => [
					'select'    => __( 'Select Products', 'woostify-pro' ),
					'featured'  => __( 'Featured', 'woostify-pro' ),
					'best-sell' => __( 'Best Sellers', 'woostify-pro' ),
					'sale'      => __( 'On Sale', 'woostify-pro' ),
				],
			]
		);

		$repeater->add_control(
			'cat_ids',
			[
				'label'     => esc_html__( 'Categories', 'woostify-pro' ),
				'type'      => Controls_Manager::SELECT2,
				'options'   => woostify_narrow_data( 'term', 'product_cat' ),
				'multiple'  => true,
				'condition' => [
					'data' => 'select',
				],
			]
		);

		$repeater->add_control(
			'ex_cat_ids',
			[
				'label'     => esc_html__( 'Exclude Categories', 'woostify-pro' ),
				'type'      => Controls_Manager::SELECT2,
				'options'   => woostify_narrow_data( 'term', 'product_cat' ),
				'multiple'  => true,
				'condition' => [
					'data!' => 'select',
				],
			]
		);

		$repeater->add_control(
			'product_ids',
			[
				'label'     => esc_html__( 'Products', 'woostify-pro' ),
				'type'      => Controls_Manager::SELECT2,
				'options'   => woostify_narrow_data( 'post', 'product' ),
				'multiple'  => true,
				'condition' => [
					'data' => 'select',
				],
			]
		);

		$repeater->add_control(
			'ex_product_ids',
			[
				'label'    => esc_html__( 'Exclude Products', 'woostify-pro' ),
				'type'     => Controls_Manager::SELECT2,
				'options'  => woostify_narrow_data( 'post', 'product' ),
				'multiple' => true,
			]
		);

		$repeater->add_control(
			'total',
			[
				'label'     => esc_html__( 'Total Products', 'woostify-pro' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 4,
				'min'       => 1,
				'max'       => 100,
				'step'      => 1,
				'separator' => 'before',
			]
		);

		$repeater->add_control(
			'col',
			[
				'type'    => Controls_Manager::SELECT,
				'label'   => esc_html__( 'Columns', 'woostify-pro' ),
				'default' => 4,
				'options' => [
					1 => 1,
					2 => 2,
					3 => 3,
					4 => 4,
					5 => 5,
					6 => 6,
				],
			]
		);

		$repeater->add_control(
			'orderby',
			[
				'label'     => esc_html__( 'Order By', 'woostify-pro' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'name',
				'condition' => [
					'data!' => 'best-sell',
				],
				'options'   => [
					'ID'     => esc_html__( 'ID', 'woostify-pro' ),
					'name'   => esc_html__( 'Name', 'woostify-pro' ),
					'title'  => esc_html__( 'Title', 'woostify-pro' ),
					'price'  => esc_html__( 'Price', 'woostify-pro' ),
					'rating' => esc_html__( 'Rating', 'woostify-pro' ),
					'date'   => esc_html__( 'Date', 'woostify-pro' ),
					'rand'   => esc_html__( 'Random', 'woostify-pro' ),
				],
			]
		);

		$repeater->add_control(
			'order',
			[
				'label'   => esc_html__( 'Order', 'woostify-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'ASC',
				'options' => [
					'ASC'  => esc_html__( 'ASC', 'woostify-pro' ),
					'DESC' => esc_html__( 'DESC', 'woostify-pro' ),
				],
			]
		);

		$this->add_control(
			'list',
			[
				'label'   => __( 'Product Tab', 'woostify-pro' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => [
					[
						'title' => __( 'Featured', 'woostify-pro' ),
						'data'  => 'featured',
					],
					[
						'title' => __( 'Best Sellers', 'woostify-pro' ),
						'data'  => 'best-sell',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style
	 */
	private function styles() {

		$this->start_controls_section(
			'style',
			[
				'label' => esc_html__( 'Style', 'woostify-pro' ),
			]
		);

		$this->add_control(
			'layout',
			[
				'label'   => __( 'Layout', 'woostify-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => [
					'grid'     => __( 'Grid', 'woostify-pro' ),
					'carousel' => __( 'Carousel', 'woostify-pro' ),
				],
			]
		);

		// Heading.
		$this->add_control(
			'label_heading',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( 'Heading', 'woostify-pro' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			]
		);

		$this->add_control(
			'heading_margin',
			[
				'label'              => __( 'Margin', 'woostify-pro' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em' ],
				'allowed_dimensions' => [ 'top', 'bottom' ],
				'selectors'          => [
					'{{WRAPPER}} .woostify-products-tab-head' => 'margin: {{TOP}}{{UNIT}} 0px {{BOTTOM}}{{UNIT}} 0px;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'heading_border',
				'label'    => __( 'Border', 'woostify-pro' ),
				'selector' => '{{WRAPPER}} .woostify-products-tab-head',
			]
		);

		// Heading items.
		$this->add_control(
			'label_heading_item',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( 'Heading Items', 'woostify-pro' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			]
		);

		$this->add_control(
			'heading_color',
			[
				'label'      => __( 'Color', 'woostify-pro' ),
				'type'       => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woostify-products-tab-btn'                  => 'color: {{VALUE}};',
					'{{WRAPPER}} .woostify-product-tab-arrows-container span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'heading_hover_color',
			[
				'label'      => __( 'Hover Color', 'woostify-pro' ),
				'type'       => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woostify-products-tab-btn:hover'                  => 'color: {{VALUE}};',
					'{{WRAPPER}} .woostify-products-tab-btn.active'                 => 'color: {{VALUE}};',
					'{{WRAPPER}} .woostify-product-tab-arrows-container span:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'heading_highlight_color',
			[
				'label'     => __( 'Highlight Color', 'woostify-pro' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .woostify-products-tab-btn:hover'  => 'border-bottom-color: {{VALUE}};',
					'{{WRAPPER}} .woostify-products-tab-btn.active' => 'border-bottom-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'heading_typo',
				'label'    => __( 'Typography', 'woostify-pro' ),
				'selector' => '{{WRAPPER}} .woostify-products-tab-btn',
			]
		);

		$this->add_control(
			'heading_item_padding',
			[
				'label'      => __( 'Padding', 'woostify-pro' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .woostify-products-tab-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_item_margin',
			[
				'label'              => __( 'Margin', 'woostify-pro' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'allowed_dimensions' => [ 'left', 'right' ],
				'size_units'         => [ 'px', 'em' ],
				'selectors'          => [
					'{{WRAPPER}} .woostify-products-tab-btn' => 'margin: 0px {{RIGHT}}{{UNIT}} 0px {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'heading_position',
			[
				'type'      => Controls_Manager::CHOOSE,
				'label'     => esc_html__( 'Alignment', 'woostify-pro' ),
				'condition' => [
					'layout' => 'grid',
				],
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'woostify-pro' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'woostify-pro' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'woostify-pro' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .grid-layout .woostify-products-tab-head' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Product tab render
	 */
	public function product_tab_render() {
		$settings = $this->get_settings_for_display();
		$list     = $settings['list'];
		$response = [];

		foreach ( $list as $k ) {
			$args = [
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => $k['total'],
				'order'          => $k['order'],
			];

			// Category ids.
			$cat_ids    = $k['cat_ids'];
			$ex_cat_ids = $k['ex_cat_ids'];

			// Product ids.
			$product_ids    = $k['product_ids'];
			$ex_product_ids = $k['ex_product_ids'];

			switch ( $k['data'] ) {
				case 'select':
				default:
					if ( ! empty( $cat_ids ) ) {
						$args['tax_query'] = [
							[
								'taxonomy' => 'product_cat',
								'field'    => 'term_id',
								'operator' => 'IN',
								'terms'    => $cat_ids,
							],
						];
					}

					if ( ! empty( $product_ids ) ) {
						$args['post__in'] = $product_ids;
					}

					if ( ! empty( $ex_product_ids ) ) {
						$args['post__not_in'] = $ex_product_ids;
					}

					break;
				case 'featured':
					$args['tax_query'] = [
						'relation' => 'AND',
						[
							'taxonomy' => 'product_visibility',
							'field'    => 'name',
							'terms'    => 'featured',
							'operator' => 'IN',
						]
					];

					if ( ! empty( $ex_cat_ids ) ) {
						$args['tax_query'][] = [
							'taxonomy' => 'product_cat',
							'field'    => 'term_id',
							'terms'    => $ex_cat_ids,
							'operator' => 'NOT IN',
						];
					}

					if ( ! empty( $ex_product_ids ) ) {
						$args['post__not_in'] = $ex_product_ids;
					}

					break;
				case 'best-sell':
					$args['meta_key'] = 'total_sales';

					if ( ! empty( $ex_cat_ids ) ) {
						$args['tax_query'][] = [
							'taxonomy' => 'product_cat',
							'field'    => 'term_id',
							'terms'    => $ex_cat_ids,
							'operator' => 'NOT IN',
						];
					}

					if ( ! empty( $ex_product_ids ) ) {
						$args['post__not_in'] = $ex_product_ids;
					}

					break;
				case 'sale':
					$args['meta_query'] = [
						'relation' => 'OR',
						[
							'key'     => '_sale_price',
							'value'   => 0,
							'compare' => '>',
							'type'    => 'numeric',
						],
						[
							'key'     => '_min_variation_sale_price',
							'value'   => 0,
							'compare' => '>',
							'type'    => 'numeric',
						],
					];

					$args['tax_query'] = [
						[
							'taxonomy' => 'product_cat',
							'field'    => 'term_id',
							'terms'    => $ex_cat_ids,
							'operator' => 'NOT IN',
						]
					];

					if ( ! empty( $ex_product_ids ) ) {
						$args['post__not_in'] = $ex_product_ids;
					}

					break;
			}

			switch ( $k['orderby'] ) {
				case 'price':
					$args['orderby']  = 'meta_value_num';
					$args['meta_key'] = '_price';
					break;
				case 'rating':
					$args['orderby']  = 'meta_value_num';
					$args['meta_key'] = '_wc_average_rating';
					break;
				default:
					if ( 'best-sell' == $k['data'] ) {
						$args['orderby'] = 'meta_value_num';
					} else {
						$args['orderby'] = $k['orderby'];
					}
					break;
			}

			array_push( $response, $args );
		}

		return $response;
	}

	/**
	 * Render
	 */
	protected function render() {
		$settings    = $this->get_settings_for_display();
		$list        = $settings['list'];
		$data        = $this->product_tab_render();
		$arrow_left  = apply_filters( 'woostify_product_tab_carousel_arrow_left_icon', 'ti-angle-left' );
		$arrow_right = apply_filters( 'woostify_product_tab_carousel_arrow_right_icon', 'ti-angle-right' );
		?>

		<div class="woostify-products-tab-widget" data-layout="<?php echo esc_attr( $settings['layout'] ); ?>-layout">
			<div class="woostify-products-tab-head">
				<div class="woostify-products-tab-head-buttons">
					<?php foreach ( $list as $v ) { ?>
						<span class="woostify-products-tab-btn" data-id="<?php echo esc_attr( $v['_id'] ); ?>"><?php echo esc_html( $v['title'] ); ?></span>
					<?php } ?>
				</div>

				<?php if ( 'carousel' == $settings['layout'] ) { ?>
					<div class="woostify-product-tab-carousel-arrows">
						<?php foreach ( $list as $v ) { ?>
							<div class="woostify-product-tab-arrows-container" data-id="<?php echo esc_attr( $v['_id'] ); ?>">
								<span class="<?php echo esc_attr( $arrow_left ); ?>"></span>
								<span class="<?php echo esc_attr( $arrow_right ); ?>"></span>
							</div>
						<?php } ?>
					</div>
				<?php } ?>
			</div>

			<div class="woostify-products-tab-body">
				<?php foreach ( $list as $i => $j ) { ?>
					<div class="woostify-products-tab-content" data-columns="<?php echo esc_attr( $j['col'] ); ?>" data-id="<?php echo esc_attr( $j['_id'] ); ?>" data-query='<?php echo json_encode( $data[ $i ] ); ?>'></div>
				<?php } ?>
			</div>
		</div>
		
		<?php
	}
}
Plugin::instance()->widgets_manager->register_widget_type( new Woostify_Elementor_Product_Tab_Widget() );
