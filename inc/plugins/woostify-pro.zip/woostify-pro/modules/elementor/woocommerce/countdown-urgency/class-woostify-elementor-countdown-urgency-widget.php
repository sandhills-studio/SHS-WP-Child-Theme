<?php
/**
 * Elementor Countdown Urgency Widget
 *
 * @package Woostify Pro
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class for woostify elementor Countdown Urgency widget.
 */
class Woostify_Elementor_Countdown_Urgency_Widget extends Widget_Base {
	/**
	 * Category
	 */
	public function get_categories() {
		return [ 'woostify-product' ];
	}

	/**
	 * Name
	 */
	public function get_name() {
		return 'woostify-countdown-urgency';
	}

	/**
	 * Gets the title.
	 */
	public function get_title() {
		return __( 'Woostify - Countdown Urgency', 'woostify-pro' );
	}

	/**
	 * Gets the icon.
	 */
	public function get_icon() {
		return 'eicon-countdown';
	}

	/**
	 * Gets the keywords.
	 */
	public function get_keywords() {
		return [ 'woostify', 'number', 'countdown', 'urgency' ];
	}

	/**
	 * Add a script.
	 */
	public function get_script_depends() {
		return [ 'woostify-countdown-urgency' ];
	}

	/**
	 * General
	 */
	public function general() {
		$this->start_controls_section(
			'general',
			[
				'label' => esc_html__( 'General', 'woostify-pro' ),
			]
		);

		$this->add_control(
			'style',
			[
				'label'   => __( 'Style', 'woostify-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default' => __( 'Default', 'woostify-pro' ),
					'style-1' => __( 'Style 1', 'woostify-pro' ),
				],
			]
		);

		$this->add_control(
			'box_bg_color',
			[
				'label'     => __( 'Background Color', 'woostify-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .woostify-countdown-urgency-widget' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'box_space',
			[
				'label'      => __( 'Padding', 'woostify-pro' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .woostify-countdown-urgency-widget' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Alignment.
		$this->add_responsive_control(
			'alignment',
			[
				'type'    => Controls_Manager::CHOOSE,
				'label'   => esc_html__( 'Alignment', 'woostify-pro' ),
				'options' => [
					'flex-start' => [
						'title' => esc_html__( 'Left', 'woostify-pro' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'woostify-pro' ),
						'icon'  => 'fa fa-align-center',
					],
					'flex-end' => [
						'title' => esc_html__( 'Right', 'woostify-pro' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'selectors'      => [
					'{{WRAPPER}} .woostify-countdown-urgency-timer' => 'justify-content: {{VALUE}};',
				],
				'condition' => [
					'style' => 'style-1',
				],
			]
		);

		$this->add_control(
			'box_border_radius',
			[
				'label'      => __( 'Border Radius', 'woostify-pro' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'default' => [
						'unit' => 'px',
						'size' => 3,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .woostify-countdown-urgency-widget' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'box_border',
				'label'    => __( 'Border', 'woostify-pro' ),
				'selector' => '{{WRAPPER}} .woostify-countdown-urgency-widget',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Message
	 */
	public function text_message() {
		$this->start_controls_section(
			'text_message',
			[
				'label'     => esc_html__( 'Message', 'woostify-pro' ),
				'condition' => [
					'style' => 'default',
				],
			]
		);

		$this->add_control(
			'message',
			[
				'label'   => __( 'Message', 'woostify-pro' ),
				'type'    => Controls_Manager::TEXTAREA,
				'rows'    => 5,
				'default' => __( 'Hurry up! Flash Sale Ends Soon!', 'woostify-pro' ),
			]
		);

		$this->add_control(
			'message_color',
			[
				'label'     => __( 'Color', 'woostify-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .woostify-countdown-urgency-message-text' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'message_bg_color',
			[
				'label'     => __( 'Background Color', 'woostify-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .woostify-countdown-urgency-message-text' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'message_typo',
				'label'    => __( 'Typography', 'woostify-pro' ),
				'selector' => '{{WRAPPER}} .woostify-countdown-urgency-message-text',
			]
		);

		$this->add_control(
			'message_border_radius',
			[
				'label'      => __( 'Border Radius', 'woostify-pro' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'default' => [
						'unit' => 'px',
						'size' => 0,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .woostify-countdown-urgency-message-text' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'message_space',
			[
				'label'      => __( 'Padding', 'woostify-pro' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .woostify-countdown-urgency-message-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Label
	 */
	public function text_label() {
		$this->start_controls_section(
			'text_label',
			[
				'label' => esc_html__( 'Label', 'woostify-pro' ),
			]
		);

		$this->add_control(
			'label_time',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( 'Label Time', 'woostify-pro' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			]
		);

		$this->add_control(
			'label_time_color',
			[
				'label'     => __( 'Color', 'woostify-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .woostify-cc-timer' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'label_time_typo',
				'label'    => __( 'Typography', 'woostify-pro' ),
				'selector' => '{{WRAPPER}} .woostify-cc-timer',
			]
		);

		$this->add_control(
			'label_time_space',
			[
				'label'              => __( 'Margin', 'woostify-pro' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', '%', 'em' ],
				'allowed_dimensions' => [ 'top', 'bottom' ],
				'selectors'          => [
					'{{WRAPPER}} .woostify-cc-timer' => 'margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}};',
				],
			]
		);

		// For label text.
		$this->add_control(
			'label_text',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( 'Label Text', 'woostify-pro' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			]
		);

		$this->add_control(
			'days_text',
			[
				'label'   => __( 'Text Days', 'woostify-pro' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'DAYS', 'woostify-pro' ),
			]
		);

		$this->add_control(
			'hours_text',
			[
				'label'   => __( 'Text Hours', 'woostify-pro' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'HOURS', 'woostify-pro' ),
			]
		);

		$this->add_control(
			'minutes_text',
			[
				'label'   => __( 'Text Mins', 'woostify-pro' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'MINS', 'woostify-pro' ),
			]
		);

		$this->add_control(
			'seconds_text',
			[
				'label'   => __( 'Text Seconds', 'woostify-pro' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'SECS', 'woostify-pro' ),
			]
		);

		$this->add_control(
			'label_text_color',
			[
				'label'     => __( 'Color', 'woostify-pro' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .woostify-cc-timer-label' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'label_text_typo',
				'label'    => __( 'Typography', 'woostify-pro' ),
				'selector' => '{{WRAPPER}} .woostify-cc-timer-label',
			]
		);

		$this->add_control(
			'label_text_space',
			[
				'label'              => __( 'Margin', 'woostify-pro' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', '%', 'em' ],
				'allowed_dimensions' => [ 'top', 'bottom' ],
				'selectors'          => [
					'{{WRAPPER}} .woostify-cc-timer-label' => 'margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Option
	 */
	public function option() {
		$this->start_controls_section(
			'option',
			[
				'label' => esc_html__( 'Options', 'woostify-pro' ),
			]
		);

		$this->add_control(
			'duration',
			[
				'label'   => __( 'Duration', 'woostify-pro' ),
				'type'    => Controls_Manager::NUMBER,
				'step'    => 1,
				'default' => 1,
			]
		);

		$this->add_control(
			'time',
			[
				'label'   => __( 'Time', 'woostify-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'days',
				'options' => [
					'days'    => __( 'Days', 'woostify-pro' ),
					'hours'   => __( 'Hours', 'woostify-pro' ),
					'minutes' => __( 'Minutes', 'woostify-pro' ),
				],
			]
		);

		$this->add_control(
			'hide',
			[
				'label'        => __( 'Hide After Time Up', 'woostify-pro' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'woostify-pro' ),
				'label_off'    => __( 'No', 'woostify-pro' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Controls
	 */
	protected function _register_controls() {
		$this->general();
		$this->text_message();
		$this->text_label();
		$this->option();
	}

	/**
	 * Render
	 */
	public function render() {
		$settings = $this->get_settings_for_display();
		$duration = $settings['duration'] ? abs( $settings['duration'] ) : 1;
		$time_up  = 'yes' == $settings['hide'] ? 'hide' : '';
		$label    = [
			'days'    => $settings['days_text'],
			'hours'   => $settings['hours_text'],
			'minutes' => $settings['minutes_text'],
			'seconds' => $settings['seconds_text'],
		];

		switch ( $settings['time'] ) {
			case 'days':
				$duration = $duration * 86400000;
				break;
			case 'hours':
				$duration = $duration * 3600000;
				break;
			default:
			case 'minutes':
				$duration = $duration * 60000;
				break;
		}
		?>
		<div class="woostify-countdown-urgency-widget woostify-countdown-urgency <?php echo esc_attr( $settings['style'] ); ?>" data-duration="<?php echo esc_attr( $duration ); ?>" data-time-up="<?php echo esc_attr( $time_up ); ?>">
			<?php if ( 'default' == $settings['style'] && $settings['message'] ) { ?>
				<div class="woostify-countdown-urgency-message">
					<div class="woostify-countdown-urgency-message-text">
						<?php echo wp_kses_post( $settings['message'] ); ?>
					</div>
				</div>
			<?php } ?>

			<div class="woostify-countdown-urgency-timer">
				<?php foreach ( $label as $k => $v ) { ?>
					<div class="woostify-cc-timer-item">
						<div class="woostify-cc-timer" data-time="<?php echo esc_attr( $k ); ?>">00</div>

						<?php if ( $v ) { ?>
							<div class="woostify-cc-timer-label"><?php echo esc_html( $v ); ?></div>
						<?php } ?>
					</div>
				<?php } ?>
			</div>
		</div>
		<?php
	}
}
Plugin::instance()->widgets_manager->register_widget_type( new Woostify_Elementor_Countdown_Urgency_Widget() );
