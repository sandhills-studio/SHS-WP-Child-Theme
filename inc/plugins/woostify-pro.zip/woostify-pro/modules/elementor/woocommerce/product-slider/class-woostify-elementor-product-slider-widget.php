<?php
/**
 * Elementor Product Slider Widget
 *
 * @package Woostify Pro
 */

namespace Elementor;

/**
 * Class woostify elementor product slider widget.
 */
class Woostify_Elementor_Product_Slider_Widget extends Woostify_Elementor_Slider_Base {
	/**
	 * Category
	 */
	public function get_categories() {
		return [ 'woostify-theme' ];
	}

	/**
	 * Name
	 */
	public function get_name() {
		return 'woostify-product-slider';
	}

	/**
	 * Title
	 */
	public function get_title() {
		return esc_html__( 'Woostify - Product Slider', 'woostify-pro' );
	}

	/**
	 * Icon
	 */
	public function get_icon() {
		return 'eicon-woocommerce';
	}

	/**
	 * Controls
	 */
	protected function _register_controls() {
		$this->slider_options();
		$this->arrows();
		$this->dots();
		$this->query();
	}

	/**
	 * Query
	 */
	private function query() {
		$this->start_controls_section(
			'product_query',
			[
				'label' => esc_html__( 'Query', 'woostify-pro' ),
			]
		);

		$this->add_control(
			'product_cat_ids',
			[
				'label'     => esc_html__( 'Categories', 'woostify-pro' ),
				'type'      => Controls_Manager::SELECT2,
				'options'   => woostify_narrow_data( 'term', 'product_cat' ),
				'multiple'  => true,
			]
		);

		$this->add_control(
			'product_ids',
			[
				'label'     => esc_html__( 'Products', 'woostify-pro' ),
				'type'      => Controls_Manager::SELECT2,
				'options'   => woostify_narrow_data( 'post', 'product' ),
				'multiple'  => true,
			]
		);

		$this->add_control(
			'exclude_product_ids',
			[
				'label'     => esc_html__( 'Exclude Products', 'woostify-pro' ),
				'type'      => Controls_Manager::SELECT2,
				'options'   => woostify_narrow_data( 'post', 'product' ),
				'multiple'  => true,
			]
		);

		$this->add_control(
			'count',
			[
				'label'     => esc_html__( 'Total Products', 'woostify-pro' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 6,
				'min'       => 1,
				'max'       => 100,
				'step'      => 1,
			]
		);

		$this->add_control(
			'order_by',
			[
				'label'     => esc_html__( 'Order By', 'woostify-pro' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'id',
				'options'   => [
					'id'         => esc_html__( 'ID', 'woostify-pro' ),
					'name'       => esc_html__( 'Name', 'woostify-pro' ),
					'date'       => esc_html__( 'Date', 'woostify-pro' ),
					'price'      => esc_html__( 'Price', 'woostify-pro' ),
					'rating'     => esc_html__( 'Rating', 'woostify-pro' ),
					'popularity' => esc_html__( 'Popularity', 'woostify-pro' ),
					'date'       => esc_html__( 'Date', 'woostify-pro' ),
					'menu_order' => esc_html__( 'Menu Order', 'woostify-pro' ),
					'rand'       => esc_html__( 'Random', 'woostify-pro' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label'     => esc_html__( 'Order', 'woostify-pro' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'ASC',
				'options'   => [
					'ASC'   => esc_html__( 'ASC', 'woostify-pro' ),
					'DESC'  => esc_html__( 'DESC', 'woostify-pro' ),
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render
	 */
	protected function render() {
		$settings            = $this->get_settings_for_display();

		// Category ids.
		$cat_ids             = $settings['product_cat_ids'];

		// Product ids.
		$product_ids         = $settings['product_ids'];
		$exclude_product_ids = $settings['exclude_product_ids'];

		$args                = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => $settings['count'],
			'order'          => $settings['order'],
		];

		if ( ! empty( $cat_ids ) ) {
			$args['tax_query'] = [
				[
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $cat_ids,
				],
			];
		}

		switch ( $settings['order_by'] ) {
			case 'price':
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = '_price';
				break;
			case 'rating':
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = '_wc_average_rating';
				break;
			case 'popularity':
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = 'total_sales';
				break;
			default:
				$args['orderby'] = $settings['order_by'];
				break;
		}

		if ( ! empty( $product_ids ) ) {
			$args['post__in'] = $product_ids;
		}

		if ( ! empty( $exclude_product_ids ) ) {
			$args['post__not_in'] = $exclude_product_ids;
		}

		$products_query = new \WP_Query( $args );
		if ( ! $products_query->have_posts() ) {
			return;
		}

		?>

		<div class="woostify-product-slider-widget">
			<ul class="woostify-product-slider products tns" data-tiny-slider='<?php echo wp_kses_post( $this->get_slider_options() ); ?>'>
				<?php
				while ( $products_query->have_posts() ) :
					$products_query->the_post();
					wc_get_template_part( 'content', 'product' );
				endwhile;

				wp_reset_postdata();
				?>
			</ul>
		</div>
		
		<?php
	}
}
Plugin::instance()->widgets_manager->register_widget_type( new Woostify_Elementor_Product_Slider_Widget() );
