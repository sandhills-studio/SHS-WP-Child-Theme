<?php
/**
 * Elementor Search Form Widget
 *
 * @package Woostify Pro
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class for woostify elementor Search form widget.
 */
class Woostify_Elementor_Search_Form_Widget extends Widget_Base {
	/**
	 * Category
	 */
	public function get_categories() {
		return [ 'woostify-theme' ];
	}

	/**
	 * Name
	 */
	public function get_name() {
		return 'woostify-search-form';
	}

	/**
	 * Gets the title.
	 */
	public function get_title() {
		return __( 'Woostify - Search Form', 'woostify-pro' );
	}

	/**
	 * Gets the icon.
	 */
	public function get_icon() {
		return 'eicon-site-search';
	}

	/**
	 * Gets the keywords.
	 */
	public function get_keywords() {
		return [ 'woostify', 'search', 'form' ];
	}

	/**
	 * General
	 */
	public function general() {
		$this->start_controls_section(
			'general',
			[
				'label' => __( 'General', 'woostify-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		// Background color.
		$this->add_control(
			'bg_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Background Color', 'woostify-pro' ),
				'selectors' => [
					'{{WRAPPER}} .search-field' => 'background-color: {{VALUE}};',
				],
			]
		);

		// Border color.
		$this->add_control(
			'border_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => esc_html__( 'Border Color', 'woostify-pro' ),
				'selectors' => [
					'{{WRAPPER}} .search-field' => 'border-color: {{VALUE}};',
				],
			]
		);

		// Border radius.
		$this->add_responsive_control(
			'padding',
			[
				'type'       => Controls_Manager::DIMENSIONS,
				'label'      => esc_html__( 'Border Radius', 'woostify-pro' ),
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .search-field' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Controls
	 */
	protected function _register_controls() {
		$this->general();
	}

	/**
	 * Render
	 */
	public function render() {
		?>
		<div class="woostify-search-form-widget site-search">
			<?php the_widget( 'WC_Widget_Product_Search', 'title=' ); ?>
			<div class="ajax-search-results"></div>
		</div>
		<?php
	}
}
Plugin::instance()->widgets_manager->register_widget_type( new Woostify_Elementor_Search_Form_Widget() );
