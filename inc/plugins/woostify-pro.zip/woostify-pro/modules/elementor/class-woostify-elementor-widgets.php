<?php
/**
 * Elementor Widgets
 *
 * @package  Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Elementor_Widgets' ) ) :

	/**
	 * Main Elementor Widgets Class
	 */
	class Woostify_Elementor_Widgets {

		/**
		 * Instance
		 *
		 * @var instance
		 */
		private static $instance;

		/**
		 *  Initiator
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Woostify Pro Constructor.
		 */
		public function __construct() {
			$this->define_constants();
			add_action( 'elementor/widgets/widgets_registered', array( $this, 'add_widgets' ) );
			add_action( 'elementor/elements/categories_registered', array( $this, 'woostify_widget_categories' ) );
			add_action( 'elementor/preview/enqueue_scripts', array( $this, 'elementor_preview_register_scripts' ) );
			add_action( 'elementor/frontend/after_register_scripts', array( $this, 'elementor_front_end_register_scripts' ) );
			add_action( 'elementor/widgets/widgets_registered', array( $this, 'remove_widgets' ), 15 );
		}

		/**
		 * Define constant
		 */
		public function define_constants() {
			define( 'WOOSTIFY_PRO_ELEMENTOR_DIR', WOOSTIFY_PRO_PATH . 'modules/elementor/' );
			define( 'WOOSTIFY_PRO_ELEMENTOR_URI', WOOSTIFY_PRO_URI . 'modules/elementor/' );

			if ( ! defined( 'WOOSTIFY_PRO_ELEMENTOR_WIDGETS' ) ) {
				define( 'WOOSTIFY_PRO_ELEMENTOR_WIDGETS', WOOSTIFY_PRO_VERSION );
			}
		}

		/**
		 * Adds widgets.
		 */
		public function add_widgets() {
			// Widgets.
			$widgets = glob( WOOSTIFY_PRO_ELEMENTOR_DIR . '**/class-woostify-*.php' );
			foreach ( $widgets as $widget ) {
				if ( file_exists( $widget ) ) {
					require_once $widget;
				}
			}

			// Woocommerce widgets.
			if ( woostify_is_woocommerce_activated() ) {
				$wc_widgets = glob( WOOSTIFY_PRO_ELEMENTOR_DIR . 'woocommerce/**/class-woostify-*.php' );
				foreach ( $wc_widgets as $wc_widget ) {
					if ( file_exists( $wc_widget ) ) {
						require_once $wc_widget;
					}
				}
			}
		}

		/**
		 * Hide some Elementor Pro widget
		 *
		 * @param      object $widgets_manager  The widgets manager.
		 */
		public function remove_widgets( $widgets_manager ) {
			// Remove only user active Elementor Bundle.
			if ( ! defined( 'WOOSTIFY_PRO_ELEMENTOR_WIDGETS' ) ) {
				return;
			}

			$widgets_manager->unregister_widget_type( 'woocommerce-product-images' );
		}

		/**
		 * Add Elementor Category
		 *
		 * @param      Elements_Manager $elements_manager The elements manager.
		 */
		public function woostify_widget_categories( $elements_manager ) {
			// Woostify theme.
			$elements_manager->add_category(
				'woostify-theme',
				array(
					'title'  => esc_html__( 'Woostify Theme', 'woostify-pro' ),
					'active' => false,
				)
			);

			// Product categorty.
			$elements_manager->add_category(
				'woostify-product',
				array(
					'title'  => esc_html__( 'Woostify Product Single', 'woostify-pro' ),
					'active' => false,
				)
			);

			// Cart page category.
			$elements_manager->add_category(
				'woostify-cart-page',
				array(
					'title'  => esc_html__( 'Woostify Cart', 'woostify-pro' ),
					'active' => false,
				)
			);

			// Checkout page category.
			$elements_manager->add_category(
				'woostify-checkout-page',
				array(
					'title'  => esc_html__( 'Woostify Checkout', 'woostify-pro' ),
					'active' => false,
				)
			);
		}

		/**
		 * Register preview mode scripts
		 */
		public function elementor_preview_register_scripts() {
			// Scripts.
			wp_enqueue_script( 'woostify-elementor-widget' );
			wp_enqueue_script( 'woostify-countdown' );

			// Styles.
			wp_enqueue_style( 'animate' );
		}

		/**
		 * Register elementor scripts
		 */
		public function elementor_front_end_register_scripts() {
			// Countdown.
			wp_register_script(
				'woostify-countdown',
				WOOSTIFY_PRO_ELEMENTOR_URI . 'assets/js/countdown' . woostify_suffix() . '.js',
				array(),
				WOOSTIFY_PRO_VERSION,
				true
			);

			// Elementor widgets js.
			wp_register_script(
				'woostify-elementor-widget',
				WOOSTIFY_PRO_ELEMENTOR_URI . 'assets/js/elementor-widgets' . woostify_suffix() . '.js',
				array( 'tiny-slider', 'woostify-countdown' ),
				WOOSTIFY_PRO_VERSION,
				true
			);

			// Elementor Product List js.
			wp_register_script(
				'woostify-product-list',
				WOOSTIFY_PRO_ELEMENTOR_URI . 'assets/js/product-list' . woostify_suffix() . '.js',
				array( 'slick'),
				WOOSTIFY_PRO_VERSION,
				true
			);

			// Animate animation.
			wp_register_style(
				'animate',
				WOOSTIFY_PRO_ELEMENTOR_URI . 'assets/css/animate.css',
				array(),
				WOOSTIFY_PRO_VERSION
			);

			// Elementor widgets.
			wp_register_style(
				'woostify-elementor-widgets',
				WOOSTIFY_PRO_ELEMENTOR_URI . 'assets/css/woostify-elementor-widgets.css',
				array(),
				WOOSTIFY_PRO_VERSION
			);

			// Load Woostify Pro widget first.
			wp_enqueue_style( 'woostify-elementor-widgets' );
		}
	}

	Woostify_Elementor_Widgets::get_instance();
endif;
