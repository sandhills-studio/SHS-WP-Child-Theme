<?php
/**
 * Elementor Widgets
 *
 * @package  Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Elementor_Widgets' ) ) :

	/**
	 * Main Elementor Widgets Class
	 */
	class Woostify_Elementor_Widgets {

		/**
		 * Instance
		 *
		 * @var instance
		 */
		private static $instance;

		/**
		 *  Initiator
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Woostify Pro Constructor.
		 */
		public function __construct() {
			$this->define_constants();
			add_action( 'elementor/widgets/widgets_registered', array( $this, 'add_widgets' ) );
			add_action( 'elementor/elements/categories_registered', array( $this, 'woostify_widget_categories' ) );
			add_action( 'elementor/preview/enqueue_scripts', array( $this, 'elementor_preview_register_scripts' ) );
			add_action( 'elementor/frontend/after_register_scripts', array( $this, 'elementor_front_end_register_scripts' ) );
			add_action( 'elementor/widgets/widgets_registered', array( $this, 'remove_widgets' ), 15 );
		}

		/**
		 * Define constant
		 */
		public function define_constants() {
			define( 'WOOSTIFY_PRO_ELEMENTOR_DIR', WOOSTIFY_PRO_PATH . 'modules/elementor/' );
			define( 'WOOSTIFY_PRO_ELEMENTOR_URI', WOOSTIFY_PRO_URI . 'modules/elementor/' );

			if ( ! defined( 'WOOSTIFY_PRO_ELEMENTOR_WIDGETS' ) ) {
				define( 'WOOSTIFY_PRO_ELEMENTOR_WIDGETS', WOOSTIFY_PRO_VERSION );
			}
		}

		/**
		 * Adds widgets.
		 */
		public function add_widgets() {
			// Logo Image.
			require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'logo-image/class-woostify-elementor-logo-image-widget.php';

			// Nav Menu.
			require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'nav-menu/class-woostify-elementor-nav-menu-widget.php';

			// Search Icon.
			require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'search-icon/class-woostify-elementor-search-icon-widget.php';

			// Account Icon.
			require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'account-icon/class-woostify-elementor-account-icon-widget.php';

			// Slider Base.
			require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'breadcrumb/class-woostify-breadcrumb.php';

			// Countdown.
			require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'countdown/class-woostify-elementor-countdown-widget.php';

			// Slider Base.
			require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'slider-base/class-woostify-elementor-slider-base.php';

			// Woocommerce.
			if ( woostify_is_woocommerce_activated() ) {
				// Search Form.
				require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'search-form/class-woostify-elementor-search-form-widget.php';

				// Add to cart.
				require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'cart-icon/class-woostify-elementor-cart-icon-widget.php';

				// Products.
				require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'products/class-woostify-base-products-renderer.php';
				require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'products/class-woostify-current-query-renderer.php';
				require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'products/class-woostify-products-renderer.php';
				require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'products/class-woostify-elementor-products-widget.php';

				// Product images.
				require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'product-images/class-woostify-elementor-product-images-widget.php';

				// Product category.
				require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'product-category/class-woostify-elementor-product-category-widget.php';

				// Product slider.
				require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'product-slider/class-woostify-elementor-product-slider-widget.php';

				// Product recently viewed.
				require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'product-recently-viewed/class-woostify-elementor-product-recently-viewed-widget.php';

				// Product tab.
				require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'product-tab/class-woostify-elementor-product-tab-widget.php';

				// Countdown urgency.
				require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'countdown-urgency/class-woostify-elementor-countdown-urgency-widget.php';
			}

			// Posts.
			require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'posts/class-woostify-elementor-posts-widget.php';

			// Slider.
			require_once WOOSTIFY_PRO_ELEMENTOR_DIR . 'slider/class-woostify-elementor-slider-widget.php';
		}

		/**
		 * Hide some Elementor Pro widget
		 *
		 * @param      object $widgets_manager  The widgets manager.
		 */
		public function remove_widgets( $widgets_manager ) {
			// Remove only user active Elementor Bundle.
			if ( ! defined( 'WOOSTIFY_PRO_ELEMENTOR_WIDGETS' ) ) {
				return;
			}

			$widgets_manager->unregister_widget_type( 'woocommerce-product-images' );
		}

		/**
		 * Add Elementor Category
		 *
		 * @param      Elements_Manager $elements_manager The elements manager.
		 */
		public function woostify_widget_categories( $elements_manager ) {
			// Woostify theme.
			$elements_manager->add_category(
				'woostify-theme',
				array(
					'title'  => esc_html__( 'Woostify Theme', 'woostify-pro' ),
					'active' => false,
				)
			);

			// Product categorty.
			$elements_manager->add_category(
				'woostify-product',
				array(
					'title'  => esc_html__( 'Woostify Product Single', 'woostify-pro' ),
					'active' => false,
				)
			);

			// Cart page category.
			$elements_manager->add_category(
				'woostify-cart-page',
				array(
					'title'  => esc_html__( 'Woostify Cart', 'woostify-pro' ),
					'active' => false,
				)
			);

			// Checkout page category.
			$elements_manager->add_category(
				'woostify-checkout-page',
				array(
					'title'  => esc_html__( 'Woostify Checkout', 'woostify-pro' ),
					'active' => false,
				)
			);
		}

		/**
		 * Register preview mode scripts
		 */
		public function elementor_preview_register_scripts() {
			// Scripts.
			wp_enqueue_script( 'woostify-elementor-widget' );
			wp_enqueue_script( 'woostify-countdown' );

			// Styles.
			wp_enqueue_style( 'animate' );
		}

		/**
		 * Register elementor scripts
		 */
		public function elementor_front_end_register_scripts() {
			// Countdown.
			wp_register_script(
				'woostify-countdown',
				WOOSTIFY_PRO_ELEMENTOR_URI . 'assets/js/countdown' . woostify_suffix() . '.js',
				array(),
				WOOSTIFY_PRO_VERSION,
				true
			);

			// Elementor widgets js.
			wp_register_script(
				'woostify-elementor-widget',
				WOOSTIFY_PRO_ELEMENTOR_URI . 'assets/js/elementor-widgets' . woostify_suffix() . '.js',
				array( 'tiny-slider', 'woostify-countdown' ),
				WOOSTIFY_PRO_VERSION,
				true
			);

			// Animate animation.
			wp_register_style(
				'animate',
				WOOSTIFY_PRO_ELEMENTOR_URI . 'assets/css/animate.css',
				array(),
				WOOSTIFY_PRO_VERSION
			);

			// Elementor widgets.
			wp_register_style(
				'woostify-elementor-widgets',
				WOOSTIFY_PRO_ELEMENTOR_URI . 'assets/css/woostify-elementor-widgets.css',
				array(),
				WOOSTIFY_PRO_VERSION
			);

			// Load Woostify Pro widget first.
			wp_enqueue_style( 'woostify-elementor-widgets' );
		}
	}

	Woostify_Elementor_Widgets::get_instance();
endif;
