<?php
/**
 * Woostify template builder for woocommerce
 *
 * @package Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Woo_Builder' ) ) {
	/**
	 * Class for woostify Header Footer builder.
	 */
	class Woostify_Woo_Builder {
		/**
		 * Instance Variable
		 *
		 * @var instance
		 */
		private static $instance;

		/**
		 * Meta Option
		 *
		 * @var $meta_option
		 */
		private static $meta_option;

		/**
		 *  Initiator
		 */
		public static function init() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->define_constants();
			add_action( 'init', array( $this, 'init_action' ), 0 );
			add_action( 'admin_menu', array( $this, 'add_admin_menu' ), 5 );
			add_filter( 'template_include', array( $this, 'single_template' ), 20 );

			// Register WC hooks in preview mode.
			if ( ! empty( $_REQUEST['action'] ) && 'elementor' === $_REQUEST['action'] && is_admin() ) { // phpcs:ignore
				add_action( 'init', array( $this, 'register_wc_hooks' ), 5 );
			}

			// Register product template widget.
			add_action( 'elementor/widgets/widgets_registered', array( $this, 'add_widgets' ) );

			// Script for woobuilder widget.
			add_action( 'elementor/frontend/after_register_scripts', array( $this, 'frontend_scripts' ) );

			// Render template.
			add_action( 'woostify_single_product_template_content', array( $this, 'render_single_product_template' ) );
			add_action( 'woostify_archive_product_template_content', array( $this, 'render_archive_product_template' ) );
			add_action( 'woostify_cart_page_content', array( $this, 'render_cart_page' ) );
			add_action( 'woostify_checkout_page_content', array( $this, 'render_checkout_page' ) );

			// Scripts and styles.
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_assets' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );

			// Print dialog template.
			add_action( 'admin_footer', array( $this, 'add_new_template' ) );

			// Create new template.
			add_action( 'admin_action_woostify_add_new_template_builder', array( $this, 'admin_action_new_post' ) );

			// Add Template Type column on 'woo_builder' list in admin screen.
			add_filter( 'manage_woo_builder_posts_columns', array( $this, 'add_column_head' ), 10 );
			add_action( 'manage_woo_builder_posts_custom_column', array( $this, 'add_column_content' ), 10, 2 );
		}

		/**
		 * Define constant
		 */
		public function define_constants() {
			if ( ! defined( 'WOOSTIFY_PRO_WOO_BUILDER' ) ) {
				define( 'WOOSTIFY_PRO_WOO_BUILDER', WOOSTIFY_PRO_VERSION );
			}
		}

		/**
		 * Is builder preview
		 */
		public function get_product_id() {
			if ( function_exists( 'woostify_get_product_id' ) ) {
				$product_id = woostify_get_product_id();
			} else {
				$product_id = ( is_singular( 'woo_builder' ) || woostify_is_elementor_editor() ) ? woostify_get_last_product_id() : woostify_get_page_id();
			}

			return $product_id;
		}

		/**
		 * Init action
		 */
		public function init_action() {
			// Create custom post type.
			$args = array(
				'label'               => __( 'WooBuilder', 'woostify-pro' ),
				'supports'            => array( 'title', 'editor', 'thumbnail', 'elementor' ),
				'rewrite'             => array( 'slug' => 'woo-builder' ),
				'show_in_rest'        => true,
				'hierarchical'        => false,
				'public'              => true,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_admin_bar'   => true,
				'show_in_nav_menus'   => true,
				'can_export'          => true,
				'has_archive'         => true,
				'exclude_from_search' => false,
				'publicly_queryable'  => true,
				'capability_type'     => 'page',
			);
			register_post_type( 'woo_builder', $args );

			// Product page.
			if ( $this->template_exist() ) {
				remove_action( 'woostify_after_header', 'woostify_content_top', 30 );
			}

			// Cart page.
			if ( $this->template_exist( 'woostify_cart_page' ) ) {
				// Remove Cart page layout class name.
				add_filter( 'woostify_cart_page_layout_class_name', '__return_empty_string' );
			}

			// Checkout page.
			if ( $this->template_exist( 'woostify_checkout_page' ) ) {
				// Remove default coupon form.
				remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );
				// Remove multi step checkout.
				add_filter( 'woostify_disable_multi_step_checkout', '__return_true' );
			}
		}

		/**
		 * Column head
		 *
		 * @param      array $defaults  The defaults.
		 */
		public function add_column_head( $defaults ) {
			$order = array();
			$title = 'title';
			foreach ( $defaults as $key => $value ) {
				$order[ $key ] = $value;

				if ( $key === $title ) {
					$order['woo_builder_type']   = __( 'Type', 'woostify-pro' );
					$order['woo_builder_author'] = __( 'Author', 'woostify-pro' );
				}
			}

			return $order;
		}

		/**
		 * Column content
		 *
		 * @param      string $column_name  The column name.
		 * @param      int    $post_id      The post id.
		 */
		public function add_column_content( $column_name, $post_id ) {
			if ( 'woo_builder_type' === $column_name ) {
				$template = woostify_get_metabox( $post_id, 'woostify_woo_builder_template' );
				$title    = __( 'Unknown', 'woostify-pro' );

				switch ( $template ) {
					case 'woostify_shop_page':
						$title = __( 'Shop Page', 'woostify-pro' );
						break;
					case 'woostify_product_page':
						$title = __( 'Product Single', 'woostify-pro' );
						break;
					case 'woostify_cart_page':
						$title = __( 'Cart Page', 'woostify-pro' );
						break;
					case 'woostify_checkout_page':
						$title = __( 'Checkout Page', 'woostify-pro' );
						break;
				}
				?>
				<span><?php echo esc_html( $title ); ?></span>
				<?php
			} elseif ( 'woo_builder_author' === $column_name ) {
				$author_id   = get_post_field( 'post_author', $post_id );
				$author_name = get_the_author_meta( 'nicename', $author_id );
				echo esc_html( $author_name );
			}
		}

		/**
		 * Add Theme Builder admin menu
		 */
		public function add_admin_menu() {
			add_submenu_page( 'woostify-welcome', 'WooBuilder', 'WooBuilder', 'manage_options', 'edit.php?post_type=woo_builder' );
		}

		/**
		 * Adds widgets.
		 */
		public function add_widgets() {
			$widgets = glob( WOOSTIFY_PRO_MODULES_PATH . 'woo-builder/widget/class-woostify-*.php' );

			foreach ( $widgets as $file ) {
				if ( file_exists( $file ) ) {
					require_once $file;
				}
			}
		}

		/**
		 * Adds scripts.
		 */
		public function frontend_scripts() {
			wp_register_script(
				'woostify-elementor-woobuilder-widget',
				WOOSTIFY_PRO_MODULES_URI . 'woo-builder/assets/js/woo-builder-handle' . woostify_suffix() . '.js',
				array( 'jquery' ),
				WOOSTIFY_PRO_VERSION,
				true
			);
		}

		/**
		 * Check template exist
		 *
		 * @param      string  $template_type  The template type.
		 * @param      boolean $return_query   The return query.
		 */
		public function template_exist( $template_type = 'woostify_product_page', $return_query = false ) {
			$args = array(
				'post_type'      => 'woo_builder',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'meta_query'     => array( // phpcs:ignore
					array(
						'key'   => 'woostify_woo_builder_template',
						'value' => $template_type,
					),
				),
			);

			$query = new WP_Query( $args );

			// Return query only.
			if ( $return_query ) {
				return $query;
			}

			// Check have posts.
			if ( $query->have_posts() ) {
				return true;
			}

			return false;
		}

		/**
		 * Single woo_builder template
		 *
		 * @param string $template The path of the template to include.
		 */
		public function single_template( $template ) {
			if ( is_singular( 'product' ) && $this->template_exist() ) {
				$template = WOOSTIFY_PRO_MODULES_PATH . 'woo-builder/template/product-page.php';
			} elseif ( is_shop() && $this->template_exist( 'woostify_shop_page' ) ) {
				$template = WOOSTIFY_PRO_MODULES_PATH . 'woo-builder/template/shop-page.php';
			} elseif ( is_cart() && $this->template_exist( 'woostify_cart_page' ) ) {
				$template = WOOSTIFY_PRO_MODULES_PATH . 'woo-builder/template/cart-page.php';
			} elseif ( is_checkout() && ! is_wc_endpoint_url( 'order-received' ) && $this->template_exist( 'woostify_checkout_page' ) ) {
				$template = WOOSTIFY_PRO_MODULES_PATH . 'woo-builder/template/checkout-page.php';
			} elseif ( is_singular( 'woo_builder' ) && file_exists( WOOSTIFY_THEME_DIR . 'single-elementor_library.php' ) ) {
				$template = WOOSTIFY_THEME_DIR . 'single-elementor_library.php';
			}

			return $template;
		}

		/**
		 * Register WC hooks.
		 */
		public function register_wc_hooks() {
			wc()->frontend_includes();
		}

		/**
		 * Render Template
		 */
		public function render_single_product_template() {
			$query = $this->template_exist( 'woostify_product_page', true );

			if ( ! $query->have_posts() ) {
				return;
			}

			while ( $query->have_posts() ) {
				$query->the_post();

				the_content();
			}
		}

		/**
		 * Render Template
		 */
		public function render_archive_product_template() {
			$query = $this->template_exist( 'woostify_shop_page', true );

			if ( ! $query->have_posts() ) {
				return;
			}

			while ( $query->have_posts() ) {
				$query->the_post();

				the_content();
			}

			wp_reset_postdata();
		}

		/**
		 * Render cart page
		 */
		public function render_cart_page() {
			$query = $this->template_exist( 'woostify_cart_page', true );

			if ( ! $query->have_posts() ) {
				return;
			}

			while ( $query->have_posts() ) {
				$query->the_post();

				the_content();
			}

			wp_reset_postdata();
		}

		/**
		 * Render checkout page
		 */
		public function render_checkout_page() {
			$query = $this->template_exist( 'woostify_checkout_page', true );

			if ( ! $query->have_posts() ) {
				return;
			}

			while ( $query->have_posts() ) {
				$query->the_post();

				the_content();
			}

			wp_reset_postdata();
		}

		/**
		 * Admin action new post.
		 *
		 * When a new post action is fired the title is set to 'Elementor' and the post ID.
		 *
		 * Fired by `admin_action_elementor_new_post` action.
		 *
		 * @since 1.9.0
		 * @access public
		 */
		public function admin_action_new_post() {
			check_admin_referer( 'woostify_add_new_template_builder' );
			$post_data = array();

			if ( ! \Elementor\User::is_current_user_can_edit_post_type( 'woo_builder' ) ) {
				return;
			}

			$template_type           = isset( $_GET['template_type'] ) ? sanitize_text_field( wp_unslash( $_GET['template_type'] ) ) : '';
			$post_data['post_type']  = 'woo_builder';
			$post_data['post_title'] = isset( $_GET['post_title'] ) ? sanitize_text_field( wp_unslash( $_GET['post_title'] ) ) : 'Woo Builder #1';
			$post_data               = apply_filters( 'woostify_woo_builder_create_new_post_meta', $post_data );
			$new_post_id             = wp_insert_post( $post_data );

			// Update post meta.
			update_post_meta( $new_post_id, 'woostify_woo_builder_template', $template_type );

			$url = add_query_arg(
				array(
					'post'   => $new_post_id,
					'action' => 'elementor',
				),
				admin_url( 'post.php' )
			);

			wp_safe_redirect( $url );
			die();
		}

		/**
		 * Print template
		 */
		public function add_new_template() {
			$screen              = get_current_screen();
			$is_edit_woo_builder = $screen ? 'edit-woo_builder' === $screen->id : false;
			if ( ! $is_edit_woo_builder ) {
				return;
			}
			?>

			<div class="woostify-add-new-template-builder">
				<div class="woostify-add-new-template-inner">
					<div class="woostify-add-new-template-header">
						<span class="woostify-add-new-template-logo">
							<img src="<?php echo esc_url( WOOSTIFY_THEME_URI . 'assets/images/logo.svg' ); ?>" alt="<?php esc_attr_e( 'Admin woostify logo image', 'woostify-pro' ); ?>">
						</span>
						<span class="woostify-add-new-template-title"><?php esc_html_e( 'New Template', 'woostify-pro' ); ?></span>
						<span class="woostify-add-new-template-close-btn dashicons dashicons-no-alt"></span>
					</div>

					<div class="woostify-add-new-template-content">
						<form class="woostify-add-new-template-form">
							<input type="hidden" name="post_type" value="woo_builder">
							<input type="hidden" name="action" value="woostify_add_new_template_builder">
							<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'woostify_add_new_template_builder' ) ); ?>">

							<div class="woostify-add-new-template-form-title"><?php esc_html_e( 'Choose Template Type', 'woostify-pro' ); ?></div>

							<div class="woostify-add-new-template-item">
								<label class="woostify-add-new-template-label"><?php esc_html_e( 'Select the type of template you want to work on', 'woostify-pro' ); ?>:</label>

								<div class="woostify-add-new-template-option-wrapper">
									<select name="template_type" required="required">
										<option value=""><?php esc_html_e( 'Select...', 'woostify-pro' ); ?></option>
										<option value="woostify_shop_page"><?php esc_html_e( 'Shop Page', 'woostify-pro' ); ?></option>
										<option value="woostify_product_page"><?php esc_html_e( 'Product Page', 'woostify-pro' ); ?></option>
										<option value="woostify_cart_page"><?php esc_html_e( 'Cart Page', 'woostify-pro' ); ?></option>
										<option value="woostify_checkout_page"><?php esc_html_e( 'Checkout Page', 'woostify-pro' ); ?></option>
									</select>
								</div>
							</div>

							<div class="woostify-add-new-template-item">
								<label class="woostify-add-new-template-label"><?php esc_html_e( 'Name your template', 'woostify-pro' ); ?>:</label>

								<div class="woostify-add-new-template-option-wrapper">
									<input type="text" placeholder="<?php esc_attr_e( 'Enter template name', 'woostify-pro' ); ?>" name="post_title" required="required">
								</div>
							</div>

							<button class="woostify-add-new-template-form-submit"><?php esc_html_e( 'Create Template', 'woostify-pro' ); ?></button>
						</form>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Admin enqueue styles and scripts.
		 */
		public function admin_enqueue_assets() {
			$screen              = get_current_screen();
			$is_edit_woo_builder = $screen ? 'edit-woo_builder' === $screen->id : false;
			if ( ! $is_edit_woo_builder ) {
				return;
			}

			wp_enqueue_script(
				'woostify-woo-builder-add-new-template',
				WOOSTIFY_PRO_MODULES_URI . 'woo-builder/assets/js/add-new-template' . woostify_suffix() . '.js',
				array(),
				WOOSTIFY_PRO_VERSION,
				true
			);

			wp_enqueue_style(
				'woostify-woo-builder-add-new-template',
				WOOSTIFY_PRO_MODULES_URI . 'woo-builder/assets/css/add-new-template.css',
				array(),
				WOOSTIFY_PRO_VERSION
			);
		}

		/**
		 * Enqueue styles and scripts.
		 */
		public function enqueue_assets() {
			wp_enqueue_style(
				'woostify-woo-builder',
				WOOSTIFY_PRO_MODULES_URI . 'woo-builder/assets/css/style.css',
				array(),
				WOOSTIFY_PRO_VERSION
			);
		}
	}

	Woostify_Woo_Builder::init();
}

