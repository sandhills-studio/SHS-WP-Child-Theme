<?php
/**
 * Single product template
 *
 * @package Woostify Pro
 */

get_header();

$woo_builder = new Woostify_Woo_Builder();
$product_id  = woostify_get_page_id();
$product     = wc_get_product( $product_id );
$product_cat = $product->get_category_ids();
$product_tag = $product->get_tag_ids();
$template_id = $woo_builder->get_template_id( 'woostify_product_page' );
$select_id   = false;

$str_cat = implode( '_', $product_cat );
$str_tag = implode( '_', $product_tag );

if ( empty( $template_id ) ) {
	wc_get_template( 'content-single-product.php' );
} else {
	$include_data = array();
	$exclude_data = array();

	foreach ( $template_id as $k => $v ) {
		$include = $v['include'];
		$exclude = $v['exclude'];

		if ( ! empty( $include ) ) {
			foreach ( $include as $in ) {
				$in_cat_id = false !== strpos( $in, 'in-cat-' );
				$in_tag_id = false !== strpos( $in, 'in-tag-' );
				if ( 'all' === $in ) {
					array_push( $include_data, $k );
				} elseif ( $in_cat_id ) {
					$str_in_cat_id = str_replace( 'in-cat-', '', $in );
					if ( 'in-cat-all' === $in || false !== strpos( $str_cat, $str_in_cat_id ) ) {
						array_push( $include_data, $k );
					}
				} elseif ( $in_tag_id ) {
					$str_in_tag_id = str_replace( 'in-tag-', '', $in );
					if ( 'in-cat-all' === $in || false !== strpos( $str_tag, $str_in_tag_id ) ) {
						array_push( $include_data, $k );
					}
				}
			}
		}

		if ( ! empty( $exclude ) ) {
			foreach ( $exclude as $ex ) {
				$ex_cat_id = false !== strpos( $ex, 'in-cat-' );
				$ex_tag_id = false !== strpos( $ex, 'in-tag-' );
				if ( $ex_cat_id ) {
					$str_ex_cat_id = str_replace( 'in-cat-', '', $ex );
					if ( 'in-cat-all' === $ex || false !== strpos( $str_cat, $str_ex_cat_id ) ) {
						array_push( $exclude_data, $k );
					}
				} elseif ( $ex_tag_id ) {
					$str_ex_tag_id = str_replace( 'in-tag-', '', $ex );
					if ( 'in-tag-all' === $ex || false !== strpos( $str_tag, $str_ex_tag_id ) ) {
						array_push( $exclude_data, $k );
					}
				}
			}
		}
	}

	$output_data = array_diff( array_unique( $include_data ), array_unique( $exclude_data ) );

	if ( ! empty( $output_data ) ) {
		$select_id = array_shift( $output_data );
	}

	if ( $select_id ) {
		$frontend = new \Elementor\Frontend();
		echo $frontend->get_builder_content_for_display( $select_id, true ); // phpcs:ignore
		wp_reset_postdata();
	} else {
		wc_get_template( 'content-single-product.php' );
	}
}

get_footer();
