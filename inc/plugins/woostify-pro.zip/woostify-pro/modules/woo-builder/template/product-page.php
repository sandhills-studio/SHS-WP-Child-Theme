<?php
/**
 * Single product template
 *
 * @package Woostify Pro
 */

get_header();

do_action( 'woostify_single_product_template_content' );

get_footer();
