<?php
/**
 * Archive product template
 *
 * @package Woostify Pro
 */

get_header();

$woo_builder = new Woostify_Woo_Builder();
$template_id = $woo_builder->get_template_id();
$select_id   = false;

if ( empty( $template_id ) ) {
	wc_get_template( 'archive-product.php' );
} else {
	$include_data = array();
	$exclude_data = array();

	foreach ( $template_id as $k => $v ) {
		$include = $v['include'];
		$exclude = $v['exclude'];

		if ( ! empty( $include ) ) {
			foreach ( $include as $in ) {
				if (
					'all' === $in ||
					( is_shop() && 'shop-page' === $in ) ||
					( is_product_category() && false !== strpos( $in, 'in-cat-' ) ) ||
					( is_product_tag() && false !== strpos( $in, 'in-tag-' ) )
				) {
					array_push( $include_data, $k );
				}
			}
		}

		if ( ! empty( $exclude ) ) {
			foreach ( $exclude as $ex ) {
				if (
					( is_shop() && 'shop-page' === $ex ) ||
					( is_product_category() && 'in-cat-all' !== $ex && false !== strpos( $ex, 'in-cat-' ) ) ||
					( is_product_tag() && 'in-tag-all' !== $ex && false !== strpos( $ex, 'in-tag-' ) )
				) {
					array_push( $exclude_data, $k );
				}
			}
		}
	}

	$output_data = array_diff( array_unique( $include_data ), array_unique( $exclude_data ) );

	if ( ! empty( $output_data ) ) {
		$select_id = array_shift( $output_data );
	}

	if ( $select_id ) {
		$frontend = new \Elementor\Frontend();
		echo $frontend->get_builder_content_for_display( $select_id, true ); // phpcs:ignore
		wp_reset_postdata();
	} else {
		wc_get_template( 'archive-product.php' );
	}
}

get_footer();
