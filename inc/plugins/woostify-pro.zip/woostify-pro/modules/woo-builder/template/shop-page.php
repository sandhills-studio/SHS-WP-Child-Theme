<?php
/**
 * Archive product template
 *
 * @package Woostify Pro
 */

get_header();

do_action( 'woostify_archive_product_template_content' );

get_footer();
