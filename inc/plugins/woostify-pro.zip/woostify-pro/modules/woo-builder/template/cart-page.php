<?php
/**
 * Cart page template
 *
 * @package Woostify Pro
 */

get_header();
?>

<div class="woocommerce">
	<?php
	// Start.
	do_action( 'woocommerce_before_cart' );

	do_action( 'woostify_cart_page_content' );

	// End.
	do_action( 'woocommerce_after_cart' );
	?>
</div>

<?php
get_footer();
