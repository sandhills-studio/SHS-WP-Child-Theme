/**
 * Edit Woobuilder
 *
 * @package Woostify Pro
 */

'use strict';

var woostifyAddNewWooBuilder = function() {
	var addNewButton = document.querySelector( '.page-title-action' );
	if ( ! addNewButton ) {
		return;
	}

	addNewButton.onclick = function( e ) {
		var template = document.querySelector( '.woostify-add-new-template-builder' );
		if ( ! template ) {
			return;
		}

		e.preventDefault();

		var closeBtn = template.querySelector( '.woostify-add-new-template-close-btn' );

		// Show dialog template.
		template.classList.add( 'active' );

		// Close via button.
		if ( closeBtn ) {
			closeBtn.onclick = function() {
				template.classList.remove( 'active' );
			}
		}

		// Close via ESC key.
		document.body.addEventListener( 'keyup', function( e ) {
			if ( 27 === e.keyCode ) {
				template.classList.remove( 'active' );
			}
		} );

		// Close via overlay.
		template.onclick = function( e ) {
			if ( this !== e.target ) {
				return;
			}

			template.classList.remove( 'active' );
		}

		return;

		// Ajax.
		var sumbit     = template.querySelector( '.woostify-add-new-template-form-submit' ),
			nonce      = template.querySelector( 'input[name="_wpnonce"]' ),
			nonceValue = nonce ? nonce.value : '';

		if ( ! sumbit ) {
			return;
		}

		/*sumbit.onclick = function( e ) {
			var templateType       = template.querySelector( 'select[name="template_type"]' ),
				templateTypeValue  = templateType ? templateType.value : false,
				templateTitle      = template.querySelector( 'input[name="post_title"]' ),
				templateTitleValue = templateTitle ? templateTitle.value : false;

			if ( ! templateTypeValue || ! templateTitleValue ) {
				return;
			}

			var request = new Request(
					ajaxurl,
					{
						method: 'POST',
						body: 'action=woostify_add_new_template_builder&_wpnonce=' + nonceValue + '&template_type=' + templateTypeValue + '&post_title=' + templateTitleValue,
						credentials: 'same-origin',
						headers: new Headers({
							'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'
						})
					}
				);

			e.preventDefault();

			// Fetch API.
			fetch( request )
				.then( function( res ) {
					if ( 200 !== res.status ) {
						console.log( 'Status Code: ' + res.status );
						return;
					}

					res.json().then( function( r ) {
						console.log( r );
					});
				} )
				.catch( function( err ) {
					console.log( err );
				} )
				.finally( function() {
				} );
		}*/
	}
}

document.addEventListener( 'DOMContentLoaded', function() {
	woostifyAddNewWooBuilder();
} );
