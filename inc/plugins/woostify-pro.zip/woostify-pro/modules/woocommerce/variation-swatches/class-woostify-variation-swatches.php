<?php
/**
 * Woostify Variation Swatches
 *
 * @package  Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Variation_Swatches' ) ) :

	/**
	 * Woostify Variation Swatches
	 */
	class Woostify_Variation_Swatches {
		/**
		 * Instance Variable
		 *
		 * @var instance
		 */
		private static $instance;

		/**
		 * Extra attribute types
		 *
		 * @var array
		 */
		public $types = [];

		/**
		 *  Initiator
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->define_constants();
			$this->types = [
				'color' => esc_html__( 'Color', 'woostify-pro' ),
				'image' => esc_html__( 'Image', 'woostify-pro' ),
				'label' => esc_html__( 'Label', 'woostify-pro' ),
			];

			$this->includes();
			$this->init_hooks();

			// Add Setting url.
			add_action( 'admin_menu', [ $this, 'add_setting_url' ] );
			// Register settings.
			add_action( 'admin_init', [ $this, 'register_settings' ] );
		}

		/**
		 * Define constant
		 */
		public function define_constants() {
			if ( ! defined( 'WOOSTIFY_PRO_VARIATION_SWATCHES' ) ) {
				define( 'WOOSTIFY_PRO_VARIATION_SWATCHES', WOOSTIFY_PRO_VERSION );
			}
		}

		/**
		 * Include required core files used in admin and on the frontend.
		 */
		public function includes() {
			require_once WOOSTIFY_PRO_MODULES_PATH . 'woocommerce/variation-swatches/inc/class-woostify-variation-swatches-frontend.php';

			if ( is_admin() ) {
				require_once WOOSTIFY_PRO_MODULES_PATH . 'woocommerce/variation-swatches/inc/class-woostify-variation-swatches-admin.php';
			}
		}

		/**
		 * Initialize hooks
		 */
		public function init_hooks() {
			add_filter( 'product_attributes_type_selector', [ $this, 'add_attribute_types' ] );
		}

		/**
		 * Add extra attribute types
		 * Add color, image and label type
		 *
		 * @param array $types
		 *
		 * @return array
		 */
		public function add_attribute_types( $types ) {
			$types = array_merge( $types, $this->types );

			return $types;
		}

		/**
		 * Add submenu
		 *
		 * @see  add_submenu_page()
		 */
		public function add_setting_url() {
			$sub_menu = add_submenu_page( 'woostify-welcome', 'Settings', 'Variation Swatches', 'manage_options', 'variation-swatches-settings', [ $this, 'add_settings_page' ] );
		}

		/**
		 * Register settings
		 */
		public function register_settings() {
			register_setting( 'variation-swatches-settings', 'woostify_variation_swatches_style' );
			register_setting( 'variation-swatches-settings', 'woostify_variation_swatches_shop_page' );
			register_setting( 'variation-swatches-settings', 'woostify_variation_swatches_quickview' );
			register_setting( 'variation-swatches-settings', 'woostify_variation_swatches_size' );
			register_setting( 'variation-swatches-settings', 'woostify_variation_swatches_tooltip' );
			register_setting( 'variation-swatches-settings', 'woostify_variation_swatches_tooltip_background' );
			register_setting( 'variation-swatches-settings', 'woostify_variation_swatches_tooltip_color' );
		}

		/**
		 * Get options
		 */
		public function get_options() {
			$options                  = [];
			$options['style']         = get_option( 'woostify_variation_swatches_style', 'circle' );
			$options['shop_page']     = get_option( 'woostify_variation_swatches_shop_page', false );
			$options['quickview']     = get_option( 'woostify_variation_swatches_quickview', true );
			$options['size']          = get_option( 'woostify_variation_swatches_size', 34 );
			$options['tooltip']       = get_option( 'woostify_variation_swatches_tooltip', true );
			$options['tooltip_bg']    = get_option( 'woostify_variation_swatches_tooltip_background', '#333333' );
			$options['tooltip_color'] = get_option( 'woostify_variation_swatches_tooltip_color', '#ffffff' );

			return $options;
		}

		/**
		 * Create Settings page
		 */
		public function add_settings_page() {
			?>
			<div class="woostify-options-wrap woostify-featured-setting woostify-variation-swatches-setting">

				<?php Woostify_Admin::get_instance()->woostify_welcome_screen_header(); ?>

				<div class="woostify-settings-box">
					<div class="woostify-welcome-container">
						<div class="woostify-settings-content">
							<h4 class="woostify-settings-section-title"><?php esc_html_e( 'Variation Swatches', 'woostify-pro' ); ?></h4>
							<div class="woostify-settings-section-content">
								<form method="post" action="options.php">
									<?php
										settings_fields( 'variation-swatches-settings' );
										do_settings_sections( 'variation-swatches-settings' );
										$options = $this->get_options();
									?>
									<table class="form-table woostify-filter-settings">
										<tr>
											<th scope="row"><?php esc_html_e( 'Style', 'woostify-pro' ); ?>:</th>
											<td>
												<select name="woostify_variation_swatches_style">
													<option value ="squares" <?php selected( $options['style'], 'squares' ); ?>><?php esc_html_e( 'Squares', 'woostify-pro' ); ?></option>
													<option value ="circle" <?php selected( $options['style'], 'circle' ); ?>><?php esc_html_e( 'Circle', 'woostify-pro' ); ?></option>
												</select>
											</td>
										</tr>

										<tr>
											<th scope="row"><?php esc_html_e( 'Shop Page', 'woostify-pro' ); ?>:</th>
											<td>
												<label for="woostify_variation_swatches_shop_page">
													<input name="woostify_variation_swatches_shop_page" type="checkbox" id="woostify_variation_swatches_shop_page" value="1" <?php checked( $options['shop_page'], true ); ?> >
													<?php esc_html_e( 'Display swatches under product item on shop page.', 'woostify-pro' ); ?>
												</label>
											</td>
										</tr>

										<tr>
											<th scope="row"><?php esc_html_e( 'Quick View', 'woostify-pro' ); ?>:</th>
											<td>
												<label for="woostify_variation_swatches_quickview">
													<input name="woostify_variation_swatches_quickview" type="checkbox" id="woostify_variation_swatches_quickview" value="1"  <?php checked( $options['quickview'], true ); ?> >
													<?php esc_html_e( 'Display swatches on quick view popup.', 'woostify-pro' ); ?>
												</label>
											</td>
										</tr>

										<tr>
											<th scope="row"><?php esc_html_e( 'Size', 'woostify-pro' ); ?>:</th>
											<td>
												<label for="woostify_variation_swatches_size">
													<input name="woostify_variation_swatches_size" type="number" id="woostify_variation_swatches_size" value="<?php echo esc_attr( $options['size'] ); ?>">
													<code>px</code>
												</label>
												<p class="woostify-setting-description"><?php esc_html_e( 'Size of swatches on product page. Unit pixel.', 'woostify-pro' ); ?></p>
											</td>
										</tr>

										<tr class="woostify-filter-item">
											<th scope="row"><?php esc_html_e( 'Tooltip', 'woostify-pro' ); ?>:</th>
											<td>
												<label for="woostify_variation_swatches_tooltip">
													<input class="woostify-filter-value" name="woostify_variation_swatches_tooltip" type="checkbox" id="woostify_variation_swatches_tooltip" value="1"  <?php checked( $options['tooltip'], true ); ?> >
													<?php esc_html_e( 'Display swatches tooltip.', 'woostify-pro' ); ?>
												</label>
											</td>
										</tr>

										<tr class="woostify-filter-item <?php echo $options['tooltip'] ? '' : 'hidden'; ?>" data-type="1">
											<th scope="row"><?php esc_html_e( 'Tooltip Background', 'woostify-pro' ); ?>:</th>
											<td>
												<input class="woostify-admin-color-picker" name="woostify_variation_swatches_tooltip_background" type="text" id="woostify_variation_swatches_tooltip_background" value="<?php echo esc_attr( $options['tooltip_bg'] ); ?>">
											</td>
										</tr>

										<tr class="woostify-filter-item <?php echo $options['tooltip'] ? '' : 'hidden'; ?>" data-type="1">
											<th scope="row"><?php esc_html_e( 'Tooltip Text Color', 'woostify-pro' ); ?>:</th>
											<td>
												<input class="woostify-admin-color-picker" name="woostify_variation_swatches_tooltip_color" type="text" id="woostify_variation_swatches_tooltip_color" value="<?php echo esc_attr( $options['tooltip_color'] ); ?>">
											</td>
										</tr>
									</table>

									<?php submit_button(); ?>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * Get attribute's properties
		 *
		 * @param string $taxonomy
		 *
		 * @return object
		 */
		public function get_tax_attribute( $taxonomy ) {
			global $wpdb;

			$attr = substr( $taxonomy, 3 );
			$attr = $wpdb->get_row( "SELECT * FROM " . $wpdb->prefix . "woocommerce_attribute_taxonomies WHERE attribute_name = '$attr'" );

			return $attr;
		}
	}

	Woostify_Variation_Swatches::get_instance();
endif;
