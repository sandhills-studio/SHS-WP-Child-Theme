<?php
/**
 * Product Archive Widget
 *
 * @package Woostify Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Woostify_Widget_Product_Archive' ) ) {
	/**
	 * Product Archive class
	 */
	class Woostify_Widget_Product_Archive extends WP_Widget {
		/**
		 * Setup
		 */
		public function __construct() {
			$options = array(
				'classname'   => 'advanced-product-archive',
				'description' => __( 'A monthly archive of your site’s Product.', 'woostify-pro' ),
			);

			parent::__construct(
				'advanced-product-archive',
				__( 'Woostify Product Archive', 'woostify-pro' ),
				$options
			);
		}

		/**
		 * Form
		 *
		 * @param      array $instance The instance.
		 */
		public function form( $instance ) {
			$default = array(
				'title' => __( 'Product Archive', 'woostify-pro' ),
				'count' => '',
			);

			$instance = wp_parse_args( (array) $instance, $default );

			$title = $instance['title'];
			$count = $instance['count'];
			?>

			<p>
				<label for='<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>'><?php esc_html_e( 'Title:', 'woostify-pro' ); ?></label>
				<input
					class="widefat"
					type='text'
					value='<?php echo esc_attr( $title ); ?>'
					name='<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>'
					id='<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>' />
			</p>
			<p>
				<input
					class="widefat"
					type="checkbox"
					<?php echo 'on' === $count ? 'checked' : ''; ?>
					name='<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>'
					id='<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>' />
				<label for='<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>'><?php esc_html_e( ' Show post counts', 'woostify-pro' ); ?></label>
			</p>

			<?php
		}

		/**
		 * Update content
		 *
		 * @param      array $new_instance  The new instance.
		 * @param      array $old_instance  The old instance.
		 *
		 * @return     array  New instance
		 */
		public function update( $new_instance, $old_instance ) {

			parent::update( $new_instance, $old_instance );

			$instance = $old_instance;

			$instance['title']  = strip_tags( $new_instance['title'] );
			$instance['count'] = strip_tags( $new_instance['count'] );

			return $instance;
		}


		/**
		 * View widget on front end
		 *
		 * @param      array $args      The arguments.
		 * @param      array $instance  The instance.
		 */
		public function widget( $args, $instance ) {
			$title           = apply_filters( 'widget_title', $instance['title'] );
			$show_post_count = 'on' === $instance['count'] ? true : false;

			echo wp_kses_post( $args['before_widget'] );

			if ( $title ) {
				echo wp_kses_post( $args['before_title'] . $title . $args['after_title'] );
			}

			$product_archive_query = array(
				'post_type'       => 'product',
				'type'            => 'monthly',
				'echo'            => 0,
				'show_post_count' => $show_post_count,
			);
			?>
			<ul class="adv-product-archive">
				<?php echo wp_get_archives( $product_archive_query ); ?>
			</ul>
			<?php
			echo wp_kses_post( $args['after_widget'] );
		}
	}
}

