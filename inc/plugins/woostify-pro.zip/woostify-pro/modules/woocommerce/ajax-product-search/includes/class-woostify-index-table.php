<?php
/**
 * Woostify Ajax Product Search Class
 *
 * @package  Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Index_Table' ) ) :

	/**
	 * Woostify Ajax Product Search Class
	 */
	class Woostify_Index_Table {

		const DB_VERSION        = '1.1';
		const DB_VERSION_OPTION = 'woostify_db_table';
		const DB_NAME           = 'woostify_product_index';
		const DB_TAX_NAME       = 'woostify_tax_index';
		const DB_SKU_INDEX      = 'woostify_sku_index';

		/**
		 * Instance Variable
		 *
		 * @var instance
		 */
		private static $instance;

		/**
		 * Total Product
		 *
		 * @var total_product
		 */
		public $total_product;

		/**
		 * Last Update
		 *
		 * @var update_time
		 */
		public $update_time;

		/**
		 *  Initiator
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		public function __construct() {
			add_action( 'plugins_loaded', array( $this, 'maybe_install' ) );
			register_activation_hook( WOOSTIFY_PRO_FILE, array( $this, 'install_data' ) );
			register_activation_hook( WOOSTIFY_PRO_FILE, array( $this, 'create_table_tax' ) );
			register_activation_hook( WOOSTIFY_PRO_FILE, array( $this, 'create_table' ) );
			register_activation_hook( WOOSTIFY_PRO_FILE, array( $this, 'sku_table' ) );
		}

		/**
		 * Install DB.
		 */
		public static function maybe_install() {
			if ( get_site_option( self::DB_VERSION_OPTION ) != self::DB_VERSION ) { // phpcs:ignore
				self::create_table();
				self::create_table_tax();
				self::table_sku();
			}
		}

		/**
		 * Create table product index.
		 */
		public static function create_table() {
			global $wpdb;
			$table_name      = $wpdb->prefix . self::DB_NAME;
			$charset_collate = $wpdb->get_charset_collate();
			$sql             = "CREATE TABLE $table_name (
				id         BIGINT(20) UNSIGNED NOT NULL,
				name            TEXT NOT NULL,
				description     TEXT NOT NULL,
				sku             VARCHAR(100) NOT NULL,
				sku_variations  TEXT NOT NULL,
				attributes      LONGTEXT NOT NULL,
				meta            LONGTEXT NOT NULL,
				image           TEXT NOT NULL,
				url             TEXT NOT NULL,
				html_price      TEXT NOT NULL,
				price           DECIMAL(10,2) NOT NULL,
				max_price       DECIMAL(10,2) NOT NULL,
				average_rating  DECIMAL(3,2) NOT NULL,
				review_count    SMALLINT(5) NOT NULL DEFAULT '0',
				total_sales     SMALLINT(5) NOT NULL DEFAULT '0',
				lang            VARCHAR(5) NOT NULL,
				type            VARCHAR(255) NOT NULL,
				created_date    DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
				PRIMARY KEY    (id)
			) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );

			add_option( self::DB_VERSION_OPTION, self::DB_VERSION );
		}

		/**
		 * Create table tax.
		 */
		public static function create_table_tax() {
			global $wpdb;
			$table_name      = $wpdb->prefix . self::DB_TAX_NAME;
			$charset_collate = $wpdb->get_charset_collate();
			$sql             = "CREATE TABLE $table_name (
				id         BIGINT(20) NOT NULL AUTO_INCREMENT,
				cat_id            BIGINT(20) NOT NULL,
				product_id     BIGINT(20) NOT NULL,
				lang            VARCHAR(5) NOT NULL,
				created_date    DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
				PRIMARY KEY    (id)

			) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );

			add_option( self::DB_VERSION_OPTION, self::DB_VERSION );
		}

		/**
		 * Index data.
		 */
		public static function install_data() {
			global $wpdb;
			$products   = self::get_total_product();
			$table_name = $wpdb->prefix . self::DB_NAME;
			$table_tax  = $wpdb->prefix . self::DB_TAX_NAME;
			$table_sku  = $wpdb->prefix . self::DB_SKU_INDEX;

			while ( $products->have_posts() ) {
				$products->the_post();
				$product   = wc_get_product( get_the_ID() );
				$list_term = array();
				$terms     = get_the_terms( get_the_ID(), 'product_cat' );
				$max_price = 0;
				$price     = self::get_price_default( get_the_ID() );
				foreach ( $terms as $term ) {
					$list_term[] = $term->term_id;
					$wpdb->insert( //phpcs:ignore
						$table_tax,
						array(
							'cat_id'       => $term->term_id,
							'product_id'   => get_the_ID(),
							'lang'         => get_locale(),
							'created_date' => current_time( 'mysql' ),
						)
					);
				}

				$image     = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'thumbnail' );
				$image_src = $image ? $image[0] : wc_placeholder_img_src();
				$sku_array = array();
				if ( $product->is_type( 'variable' ) ) {
					$max_price = $product->get_variation_regular_price( 'max' );
					$price     = self::get_price_variable_min( get_the_ID() );
					foreach ( $product->get_visible_children( false ) as $child_id ) {
						$variation = wc_get_product( $child_id );
						if ( $variation && $variation->get_sku() ) {
							$sku_array[] = $variation->get_sku();
							$wpdb->insert( //phpcs:ignore
								$table_sku,
								array(
									'sku'          => $variation->get_sku(),
									'product_id'   => get_the_ID(),
									'lang'         => get_locale(),
									'created_date' => current_time( 'mysql' ),
								)
							);
						}
					}
				}

				$list_sku = implode( ',', $sku_array );
				$wpdb->insert( //phpcs:ignore
					$table_name,
					array(
						'id'             => get_the_ID(),
						'name'           => get_the_title(),
						'description'    => $product->get_short_description(),
						'sku'            => $product->get_sku(),
						'sku_variations' => $list_sku,
						'image'          => $image_src,
						'url'            => get_permalink(),
						'html_price'     => $product->get_price_html(),
						'price'          => $price,
						'max_price'      => $max_price,
						'type'           => $product->get_type(),
						'average_rating' => $product->get_average_rating(),
						'review_count'   => $product->get_review_count(),
						'total_sales'    => $product->get_total_sales(),
						'lang'           => get_locale(),
						'created_date'   => current_time( 'mysql' ),
					)
				);

			}

			wp_reset_postdata();
		}

		/**
		 * Create table sku.
		 */
		public static function sku_table() {
			global $wpdb;
			$table_name      = $wpdb->prefix . self::DB_SKU_INDEX;
			$charset_collate = $wpdb->get_charset_collate();
			$sql             = "CREATE TABLE $table_name (
				id         BIGINT(20) NOT NULL AUTO_INCREMENT,
				product_id     TEXT NOT NULL,
				sku             VARCHAR(100) NOT NULL,
				lang            VARCHAR(5) NOT NULL,
				created_date    DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
				PRIMARY KEY    (id)
			) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );

			add_option( self::DB_VERSION_OPTION, self::DB_VERSION );
		}

		/**
		 * Get Total product index.
		 */
		public static function get_total_product() {
			$args    = array(
				'post_type'           => 'product',
				'post_status'         => 'publish',
				'posts_per_page'      => -1,
				'order'               => 'ASC',
				'orderby'             => 'ID',
				'ignore_sticky_posts' => 1,
			);
			$product = new \WP_Query( $args );

			return $product;
		}

		/**
		 * Get number Total product index.
		 */
		public function total_product() {
			$product = self::get_total_product();
			return $product->found_posts;
		}

		/**
		 * Last index time.
		 */
		public function last_index() {
			global $wpdb;
			$table_name      = $wpdb->prefix . self::DB_NAME;
			$charset_collate = $wpdb->get_charset_collate();
			$sql             = "SELECT MAX(created_date) FROM $table_name";
			$time            = $wpdb->get_var( $sql ); //phpcs:ignore

			return $time;
		}

		/**
		 * Get price default when use dynamic.
		 *
		 * @param (int) $product_id | product id.
		 */
		public static function get_price_default( $product_id ) {
			global $wpdb;
			$sql   = "SELECT * FROM {$wpdb->prefix}postmeta WHERE post_id = $product_id AND meta_key ='_regular_price'"; //phpcs:ignore
			$price = $wpdb->get_results( $sql ); //phpcs:ignore

			if ( ! empty( $price ) ) {
				return $price[0]->meta_value;
			}
			return 0;
		}

		/**
		 * Get price default when use dynamic.
		 *
		 * @param (int) $product_id | product id.
		 */
		public function get_price_variable_max( $product_id ) {
			global $wpdb;
			$sql   = "SELECT MAX( tm.meta_value ) FROM {$wpdb->prefix}posts as tp LEFT JOIN {$wpdb->prefix}postmeta as tm ON tp.ID = tm.post_id WHERE tp.post_type = 'product_variation' AND tp.post_parent = $product_id AND tm.meta_key = '_regular_price' "; //phpcs:ignore
			$price = $wpdb->get_var( $sql ); //phpcs:ignore

			return $price;
		}

		/**
		 * Get price default when use dynamic.
		 *
		 * @param (int) $product_id | product id.
		 */
		public static function get_price_variable_min( $product_id ) {
			global $wpdb;
			$sql   = "SELECT MIN( tm.meta_value ) FROM {$wpdb->prefix}posts as tp LEFT JOIN {$wpdb->prefix}postmeta as tm ON tp.ID = tm.post_id WHERE tp.post_type = 'product_variation' AND tp.post_parent = $product_id AND tm.meta_key = '_regular_price' "; //phpcs:ignore
			$price = $wpdb->get_var( $sql ); //phpcs:ignore

			return $price;
		}

		/**
		 * Init.
		 */
		public static function init() {
			register_activation_hook( WOOSTIFY_PRO_FILE, array( 'Woostify_Index_Table', 'install_data' ) );
			register_activation_hook( WOOSTIFY_PRO_FILE, array( 'Woostify_Index_Table', 'create_table' ) );
			register_activation_hook( WOOSTIFY_PRO_FILE, array( 'Woostify_Index_Table', 'create_table_tax' ) );
			register_activation_hook( WOOSTIFY_PRO_FILE, array( 'Woostify_Index_Table', 'sku_table' ) );
			add_action( 'plugins_loaded', array( 'Woostify_Index_Table', 'maybe_install' ) );
		}
	}

	Woostify_Index_Table::get_instance();
	Woostify_Index_Table::init();
endif;
