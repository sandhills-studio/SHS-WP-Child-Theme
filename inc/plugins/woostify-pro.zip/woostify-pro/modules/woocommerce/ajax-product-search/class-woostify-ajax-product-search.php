<?php
/**
 * Woostify Ajax Product Search Class
 *
 * @package  Woostify Pro
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Woostify_Ajax_Product_Search' ) ) :

	/**
	 * Woostify Ajax Product Search Class
	 */
	class Woostify_Ajax_Product_Search {

		/**
		 * Instance Variable
		 *
		 * @var instance
		 */
		private static $instance;

		/**
		 *  Initiator
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->define_constants();
			$woocommerce_helper = Woostify_Woocommerce_Helper::init();

			add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ) );
			add_filter( 'woostify_options_admin_submenu_label', array( $this, 'woostify_options_admin_submenu_label' ) );

			add_action( 'woostify_dialog_search_content_end', array( $this, 'add_search_results' ) );

			// Save settings.
			add_action( 'wp_ajax_woostify_save_ajax_search_product_options', array( $woocommerce_helper, 'save_options' ) );

			// Ajax for front end.
			add_action( 'wp_ajax_ajax_product_search', array( $this, 'ajax_product_search' ) );
			add_action( 'wp_ajax_nopriv_ajax_product_search', array( $this, 'ajax_product_search' ) );

			// Add Setting url.
			add_action( 'admin_menu', array( $this, 'add_setting_url' ) );
			add_action( 'admin_init', array( $this, 'register_settings' ) );
		}

		/**
		 * Define constant
		 */
		public function define_constants() {
			if ( ! defined( 'WOOSTIFY_AJAX_PRODUCT_SEARCH' ) ) {
				define( 'WOOSTIFY_AJAX_PRODUCT_SEARCH', WOOSTIFY_PRO_VERSION );
			}
		}

		/**
		 * Adds search results.
		 */
		public function add_search_results() {
			?>
			<div class="ajax-search-results"></div>
			<?php
		}

		/**
		 * Sets up.
		 */
		public function scripts() {
			$options = Woostify_Pro::get_instance()->woostify_pro_options();

			// Style.
			wp_enqueue_style(
				'woostify-ajax-product-search',
				WOOSTIFY_PRO_MODULES_URI . 'woocommerce/ajax-product-search/css/style.css',
				array(),
				WOOSTIFY_PRO_VERSION
			);

			/**
			 * Script
			 */
			wp_enqueue_script(
				'woostify-ajax-product-search',
				WOOSTIFY_PRO_MODULES_URI . 'woocommerce/ajax-product-search/js/script' . woostify_suffix() . '.js',
				array(),
				WOOSTIFY_PRO_VERSION,
				true
			);

			$data = array(
				'ajax_url'   => admin_url( 'admin-ajax.php' ),
				'ajax_error' => __( 'Sorry, something went wrong. Please refresh this page and try again!', 'woostify-pro' ),
				'ajax_nonce' => wp_create_nonce( 'ajax_product_search' ),
			);

			$category_filter = get_option( 'woostify_ajax_search_product_category_filter', '0' );
			$term            = get_terms( 'product_cat' );

			if ( '1' === $category_filter && $term ) {
				$select  = '<div class="ajax-category-filter-box">';
				$select .= '<select class="ajax-product-search-category-filter">';
				$select .= '<option value="">' . esc_html__( 'All', 'woostify-pro' ) . '</option>';
				foreach ( $term as $k ) {
					$select .= '<option value="' . esc_attr( $k->term_id ) . '">' . esc_html( $k->name ) . '</option>';
				}
				$select .= '</select>';
				$select .= '</div>';

				$data['select'] = $select;
			}

			wp_localize_script(
				'woostify-ajax-product-search',
				'woostify_ajax_product_search_data',
				$data
			);
		}

		/**
		 * Update First submenu for Welcome screen.
		 */
		public function woostify_options_admin_submenu_label() {
			return true;
		}

		/**
		 * Highlight keyword
		 *
		 * @param      string $str     The string.
		 * @param      string $search  The search.
		 *
		 * @return     string  Highlight string
		 */
		public function highlight_keyword( $str, $search ) {
			$str    = strtolower( trim( $str ) );
			$search = strtolower( $search );
			$search = explode( ' ', $search );

			$highlighted = array();
			foreach ( $search as $key ) {
				$highlighted[] = '<span class="aps-highlight">' . $key . '</span>';
			}

			return strtr( $str, array_combine( $search, $highlighted ) );
		}

		/**
		 * Ajax product search
		 */
		public function ajax_product_search() {
			check_ajax_referer( 'ajax_product_search', 'ajax_nonce', false );

			$response = array();

			if ( ! isset( $_POST['ajax_product_search_keyword'] ) ) {
				wp_send_json_error();
				exit();
			}

			$keyword = sanitize_text_field( wp_unslash( $_POST['ajax_product_search_keyword'] ) );
			$cat_id  = isset( $_POST['cat_id'] ) ? intval( sanitize_text_field( wp_unslash( $_POST['cat_id'] ) ) ) : '';

			$args = array(
				'post_type'           => 'product',
				's'                   => $keyword,
				'ignore_sticky_posts' => 1,
				'post_status'         => 'publish',
			);

			// Query by category id.
			if ( ! empty( $cat_id ) ) {
				$args['tax_query'] = array( // phpcs:ignore
					array(
						'taxonomy' => 'product_cat',
						'field'    => 'term_id',
						'terms'    => $cat_id,
					),
				);
			}

			// Exclude out of stock products.
			$remove_out_stock_product = get_option( 'woostify_ajax_search_product_remove_out_stock_product', '0' );
			if ( '1' === $remove_out_stock_product ) {
				$args['meta_query'] = array( // phpcs:ignore
					array(
						'key'     => '_stock_status',
						'value'   => 'outofstock',
						'compare' => 'NOT IN',
					),
				);
			}

			$query = new WP_Query( $args );

			ob_start();
			?>
			<div class="ajax-product-search-results">
				<?php
				if ( $query->have_posts() ) {
					while ( $query->have_posts() ) {
						$query->the_post();

						$product   = wc_get_product( get_the_ID() );
						$image     = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'thumbnail' );
						$image_src = $image ? $image[0] : wc_placeholder_img_src();
						$title     = $this->highlight_keyword( get_the_title(), $keyword );
						?>
						<div class="aps-item">
							<a class="aps-link" href="<?php echo esc_url( get_permalink() ); ?>"></a>
							<img class="aps-thumbnail" src="<?php echo esc_url( $image_src ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>">
							<div class="asp-content">
								<h4 class="aps-title"><?php echo wp_kses_post( $title ); ?></h4>
								<div class="aps-price"><?php echo wp_kses_post( $product->get_price_html() ); ?></div>
							</div>
						</div>
						<?php
					}
					wp_reset_postdata();
				} else {
					?>
					<div class="aps-no-posts-found">
						<?php esc_html_e( 'No products found!', 'woostify-pro' ); ?>
					</div>
				<?php } ?>
			</div>
			<?php

			$response['content'] = ob_get_clean();

			wp_send_json_success( $response );
		}

		/**
		 * Add submenu
		 *
		 * @see  add_submenu_page()
		 */
		public function add_setting_url() {
			$sub_menu = add_submenu_page( 'woostify-welcome', 'Settings', 'Ajax Product Search', 'manage_options', 'ajax-search-product-settings', array( $this, 'add_settings_page' ) );
		}

		/**
		 * Register settings
		 */
		public function register_settings() {
			register_setting( 'ajax-search-product-settings', 'woostify_ajax_search_product_category_filter' );
		}

		/**
		 * Add Settings page
		 */
		public function add_settings_page() {
			?>
			<div class="woostify-options-wrap woostify-featured-setting woostify-ajax-search-product-setting" data-id="ajax-search-product" data-nonce="<?php echo esc_attr( wp_create_nonce( 'woostify-ajax-search-product-setting-nonce' ) ); ?>">

				<?php Woostify_Admin::get_instance()->woostify_welcome_screen_header(); ?>

				<div class="woostify-settings-box">
					<div class="woostify-welcome-container">
						<div class="woostify-settings-content">
							<h4 class="woostify-settings-section-title"><?php esc_html_e( 'Ajax Product Search', 'woostify-pro' ); ?></h4>

							<div class="woostify-settings-section-content">
								<?php
									$category_filter          = get_option( 'woostify_ajax_search_product_category_filter', '0' );
									$remove_out_stock_product = get_option( 'woostify_ajax_search_product_remove_out_stock_product', '0' );
								?>

								<table class="form-table">
									<tr>
										<th scope="row"><?php esc_html_e( 'Filter', 'woostify-pro' ); ?></th>
										<td>
											<label for="woostify_ajax_search_product_category_filter">
												<input name="woostify_ajax_search_product_category_filter" type="checkbox" id="woostify_ajax_search_product_category_filter" <?php checked( $category_filter, '1' ); ?> value="<?php echo esc_attr( $category_filter ); ?>">
												<?php esc_html_e( 'Display category filter', 'woostify-pro' ); ?>
											</label>
										</td>
									</tr>

									<tr>
										<th scope="row"><?php esc_html_e( 'Out Stock Product', 'woostify-pro' ); ?></th>
										<td>
											<label for="woostify_ajax_search_product_remove_out_stock_product">
												<input name="woostify_ajax_search_product_remove_out_stock_product" type="checkbox" id="woostify_ajax_search_product_remove_out_stock_product" <?php checked( $remove_out_stock_product, '1' ); ?> value="<?php echo esc_attr( $remove_out_stock_product ); ?>">
												<?php esc_html_e( 'Remove Out stock product', 'woostify-pro' ); ?>
											</label>
											<p class="woostify-setting-description"><?php esc_html_e( 'Remove Out of stock products in search results', 'woostify-pro' ); ?></p>
										</td>
									</tr>
								</table>
							</div>

							<div class="woostify-settings-section-footer">
								<span class="save-options button button-primary"><?php esc_html_e( 'Save', 'woostify-pro' ); ?></span>
								<span class="spinner"></span>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php
		}
	}

	Woostify_Ajax_Product_Search::get_instance();
endif;
