/**
 * Woostify Pro Customizer Preview
 *
 * @package Woostify Pro
 */

'use strict';

document.addEventListener(
	'DOMContentLoaded',
	function() {
		// UPDATE ELEMENT CLASS NAME.
		if ( 'function' === typeof( woostify_update_element_class ) ) {
			// Layout 1.
			woostify_update_element_class( 'woostify_pro_options[header_full_width]', '.header-layout-1', 'header-full-width', true );
		}

		// HTML LIVE UPDATE.
		if ( 'function' === typeof( woostify_html_live_update ) ) {
			// Layout 3.
			woostify_html_live_update( 'woostify_pro_options[header_left_content]', '.header-layout-3 .left-content', true );
			// Layout 5.
			woostify_html_live_update( 'woostify_pro_options[header_center_content]', '.header-layout-5 .center-content', true );
			// Layout 8.
			woostify_html_live_update( 'woostify_pro_options[header_8_button_text]', '.header-layout-8 .vertical-menu-button', true );
		}

		// COLOR LIVE UPDATE.
		if ( 'function' === typeof( woostify_colors_live_update ) ) {
			// Layout 6.
			woostify_colors_live_update( 'woostify_pro_options[header_content_bottom_background]', '.header-layout-6 .header-content-bottom', 'background-color', true );
			// Layout 8.
			woostify_colors_live_update( 'woostify_pro_options[header_8_search_bar_background]', '.header-layout-8 .header-content-bottom', 'background-color', true );
			woostify_colors_live_update( 'woostify_pro_options[header_8_button_background]', '.header-layout-8 .vertical-menu-wrapper .vertical-menu-button', 'background-color', true );
			woostify_colors_live_update( 'woostify_pro_options[header_8_button_color]', '.header-layout-8 .vertical-menu-wrapper .vertical-menu-button', 'color', true );
			woostify_colors_live_update( 'woostify_pro_options[header_8_button_hover_background]', '.header-layout-8 .vertical-menu-wrapper .vertical-menu-button:hover', 'background-color', true );
			woostify_colors_live_update( 'woostify_pro_options[header_8_button_hover_color]', '.header-layout-8 .vertical-menu-wrapper .vertical-menu-button:hover', 'color', true );
			woostify_colors_live_update( 'woostify_pro_options[header_8_icon_color]', '.header-layout-8 .woostify-total-price, .header-layout-8 .tools-icon', 'color', true );
			woostify_colors_live_update( 'woostify_pro_options[header_8_icon_hover_color]', '.site-header.header-layout-8 .tools-icon:hover, .header-layout-8 .tools-icon.my-account:hover > a', 'color', true );
			woostify_colors_live_update( 'woostify_pro_options[header_8_content_right_text_color]', '.header-layout-8 .content-top-right *', 'color', true );

			// STICKY HEADER.
			woostify_colors_live_update( 'woostify_pro_options[sticky_header_background_color]', '.has-sticky-header .site-header-inner.fixed', 'background-color', true );
			woostify_colors_live_update( 'woostify_pro_options[sticky_header_border_color]', '.has-sticky-header .site-header-inner.fixed', 'border-bottom-color', true );
		}

		// UNIT LIVE UPDATE.
		if ( 'function' === typeof( woostify_unit_live_update ) ) {
			woostify_unit_live_update( 'woostify_pro_options[sticky_header_border_width]', '.has-sticky-header .site-header-inner.fixed', 'border-bottom-width', 'px', true );
		}
	}
);
