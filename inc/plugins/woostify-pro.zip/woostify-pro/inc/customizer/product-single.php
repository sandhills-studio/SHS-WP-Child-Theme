<?php
/**
 * Woocommerce shop single customizer
 *
 * @package Woostify Pro
 */

// Default values.
$defaults = Woostify_Pro::get_instance()->default_options_value();

if ( ! defined( 'WOOSTIFY_PRO_BUY_NOW_BUTTON' ) && ! defined( 'WOOSTIFY_PRO_STICKY_SINGLE_ADD_TO_CART' ) ) {
	return;
}

// SHOP SINGLE STRUCTURE SECTION.
$wp_customize->add_setting(
	'shop_single_addon_section',
	array(
		'sanitize_callback' => 'sanitize_text_field',
	)
);
$wp_customize->add_control(
	new Woostify_Section_Control(
		$wp_customize,
		'shop_single_addon_section',
		array(
			'label'      => __( 'Advanced Button', 'woostify-pro' ),
			'section'    => 'woostify_shop_single',
			'dependency' => [
				'woostify_pro_options[shop_single_buy_now_button]',
				'woostify_pro_options[sticky_single_add_to_cart_button]',
				'woostify_pro_options[sticky_atc_button_on]',
			]
		)
	)
);

// SINGLE BUY NOW BUTTON.
if ( defined( 'WOOSTIFY_PRO_BUY_NOW_BUTTON' ) ) {
	$wp_customize->add_setting(
		'woostify_pro_options[shop_single_buy_now_button]',
		array(
			'default'           => $defaults['shop_single_buy_now_button'],
			'type'              => 'option',
			'sanitize_callback' => 'woostify_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		new Woostify_Switch_Control(
			$wp_customize,
			'woostify_pro_options[shop_single_buy_now_button]',
			array(
				'label'    => __( 'Add Buy Now Button', 'woostify-pro' ),
				'settings' => 'woostify_pro_options[shop_single_buy_now_button]',
				'section'  => 'woostify_shop_single',
			)
		)
	);
}

// STICKY SINGLE ADD TO CART.
if ( defined( 'WOOSTIFY_PRO_STICKY_SINGLE_ADD_TO_CART' ) ) {
	// Sticky add to cart button.
	$wp_customize->add_setting(
		'woostify_pro_options[sticky_single_add_to_cart_button]',
		array(
			'default'           => $defaults['sticky_single_add_to_cart_button'],
			'type'              => 'option',
			'sanitize_callback' => 'woostify_sanitize_choices',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'woostify_pro_options[sticky_single_add_to_cart_button]',
			array(
				'label'    => __( 'Sticky Add To Cart Button', 'woostify-pro' ),
				'settings' => 'woostify_pro_options[sticky_single_add_to_cart_button]',
				'section'  => 'woostify_shop_single',
				'type'     => 'select',
				'choices'  => apply_filters(
					'woostify_pro_options_sticky_single_add_to_cart_button_choices',
					array(
						'top'    => __( 'Top', 'woostify-pro' ),
						'bottom' => __( 'Bottom', 'woostify-pro' ),
					)
				),
			)
		)
	);

	// Sticky add to cart button on mobile.
	$wp_customize->add_setting(
		'woostify_pro_options[sticky_atc_button_on]',
		array(
			'default'           => $defaults['sticky_atc_button_on'],
			'type'              => 'option',
			'sanitize_callback' => 'woostify_sanitize_choices',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'woostify_pro_options[sticky_atc_button_on]',
			array(
				'label'    => __( 'Sticky On', 'woostify-pro' ),
				'settings' => 'woostify_pro_options[sticky_atc_button_on]',
				'section'  => 'woostify_shop_single',
				'type'     => 'select',
				'choices'  => apply_filters(
					'woostify_pro_options_sticky_single_add_to_cart_on_devices_choices',
					array(
						'desktop' => __( 'Desktop', 'woostify-pro' ),
						'mobile'  => __( 'Mobile', 'woostify-pro' ),
						'both'    => __( 'Desktop + Mobile', 'woostify-pro' ),
					)
				),
			)
		)
	);
}
