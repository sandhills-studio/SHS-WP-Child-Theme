=== HappyFiles - WordPress Media Categories ===
Contributors: codeer
Tags: media categories, media folders, media library, media manager, file manager, image folders, categories, folders, media, organize
Requires at least: 4.6
Tested up to: 5.3.2
Requires PHP: 5.4
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Organize your entire media library via drag & drop in nestable categories.

== Description ==

Organize your entire media library via drag & drop in nestable categories. Arrange thousands of files as you would do on your computer. 

Create, rename, delete, and nest your categories to your liking. 

Drag and drop your files (image, audio, video, etc.) individually or in bulk into any category/sub-category or move file(s) between categories.

Reorder your media categories via drag and drop.

Instant on-the-fly refresh when navigating between categories, and when adding, renaming, and deleting categories or files.

Select any category to directly upload a file into it.

Custom context menu to create, rename and delete any media category with a one click.

Right click any file to navigate directly into its media category.

Assign a file to multiple categories (enable under "Settings > HappyFiles Settings > Assign multiple categories").

Support for RTL languages such as Arabic, Hebrew, etc.

Integrates seamlessly with Gutenberg, the Classic Editor, and the most popular page builders:

* Elementor
* Divi
* Beaver Builder
* Oxygen Builder
* Brizy
* Visual Composer (WP Bakery)

> This free version of HappyFiles let's you manage up to 10 media categories. [Upgrade to HappyFiles PRO](https://happyfiles.io/#download?utm_source=wp&utm_medium=repo) to manage unlimited categories (one time payment).

== Frequently Asked Questions ==

= How many media categories can I create and manage? =

The free version of HappyFiles allows you to categorize unlimited files, but creation and management of categories is limited to 10. If you need to manage more than 10 media categories please [upgrade to HappyFiles Pro](https://happyfiles.io/#download?utm_source=wp&utm_medium=repo). The Pro version also comes with premium support.

= Does HappyFiles modify my files or folders? =

No. HappyFiles does not create any actual folders, but instead takes advantage of taxonomy terms. The relationship between files and categories is set in your database, not on your server.

= Can I use HappyFiles on more than 1 domain? =

Yes. You can use HappyFiles Free & Pro on all your and your client domains.

= Where can I find a live demo of HappyFiles? =

Please visit [https://happyfiles.io](https://happyfiles.io/#video?utm_source=wp&utm_medium=repo) to watch the video walk-through.

= Does the media categorization affect the frontend? =

No. Your files and file paths don't change. HappyFiles does not create any actual folders, but instead takes advantage of taxonomy terms.

= How can I translate HappyFiles into my language? =

You can help translate HappyFiles into your language through [https://translate.wordpress.org](https://translate.wordpress.org/projects/wp-plugins/happyfiles/). Any translation, even if it's just a single word, is much appreciated :)

== Installation ==

Get HappyFiles up and running in less than a minute using the automatic installtion.

= Automatic installation =

1. Log in to your WordPress dashboard, navigate to the **Plugins** menu and click on **Add New**.
2. Type **HappyFiles** into the search field and hit enter.
3. Once you've found our plugin, click **Install Now**. After the installation is complete, click **Activate**.

= Manual installation (via FTP) =

1. Visit [https://wordpress.org/plugins/happyfiles/](https://wordpress.org/plugins/happyfiles/) and click the blue **Download** button.
2. Once downloaded unzip the **happyfiles.zip** file.
3. Log in to your server via FTP and upload the unpacked **happyfiles** folder into the */wp-content/plugins/* directory.
4. Go to your WordPress dashboard, click to the **Plugins** menu and activate the *HappyFiles* plugin.

Once the plugin is activated the category sidebar is added to your media library and all media modals.

HappyFiles does not create any actual folders, but instead takes advantage of taxonomy terms.

== Screenshots ==

1. Media categories sidebar
2. Drag and drop files individually or in bulk
3. Reorder and nest media categories via drag and drop
4. Upload files directly into media categories
5. Direct upload is also avaible from the "Add New" media admin screen
6. Access in posts, pages and on the frontend via page builders like Elementor, Divi, WP Bakery / Visual Composer, Beaver Builder, etc.
7. Resize and toggle the media sidebar visibility
8. Media categorization works in list view, too
9. Custom context menu to quickly create, rename, and delete media categories
10. Restrict media category editing by user role