<?php 
namespace HappyFiles;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Pro {

	public static $settings_post_types = 'happyfiles_post_types';
	public static $settings_license_key = 'happyfiles_license_key';
	public static $enabled_post_types = [];

	public function __construct() {
		self::$enabled_post_types = get_option( self::$settings_post_types, [] );

		if ( ! is_array( self::$enabled_post_types ) ) {
			self::$enabled_post_types = [];
		}

		add_action( 'init', [$this, 'register_taxonomy_for_posts_pages'] );

		add_action( 'admin_init', [$this, 'register_setting_post_types'] );
		add_action( 'happyfiles_admin_settings_top', [$this, 'render_setting_post_types' ] );

		add_action( 'admin_footer-edit.php', [$this, 'render'] );
		add_action( 'admin_enqueue_scripts', [$this, 'enqueue_scripts'] );

		foreach ( self::$enabled_post_types as $post_type ) {
			if ( $post_type === 'post' ) {
				add_filter( 'manage_posts_columns', [$this, 'manage_posts_columns'], 10, 1 );
				add_action( 'manage_posts_custom_column', [$this, 'add_column_move_files'], 10, 2 );
			} else if ( $post_type === 'page' ) {
				add_filter( 'manage_pages_columns', [$this, 'manage_pages_columns'], 10, 1 );
				add_action( 'manage_pages_custom_column', [$this, 'add_column_move_files'], 10, 2 );
			} else {
				add_filter( 'manage_edit-' . $post_type . '_columns', [$this, 'manage_posts_columns'], 10, 1 );

				// Avoid adding move icon twice
				if ( ! in_array( 'post', self::$enabled_post_types ) ) {
					add_action( 'manage_' . $post_type . '_posts_custom_column', [$this, 'add_column_move_files'], 10, 2 );
				}
			}
		}

		// Set tax query on initial page load
		add_action( 'pre_get_posts', [$this, 'pre_get_posts'] );

		// Set tax query on every sequential category change
		add_action( 'parse_tax_query', [$this, 'parse_tax_query'] );

		add_action( 'restrict_manage_posts', [$this, 'add_categories_filter'] );

		add_filter( 'pre_set_site_transient_update_plugins', [$this, 'check_for_update'] );

		add_action( 'wp_ajax_happyfiles_deactivate_license', [$this, 'deactivate_license'] );
	}

	public function manage_posts_columns( $columns ) {
		$columns = ['happyfiles_move' => ''] + $columns;

		return $columns;
	}

	public function add_column_move_files( $column_name, $post_id ) {
		switch ( $column_name ) {
			case 'happyfiles_move':
				echo '<i class="happyfiles-move dashicons dashicons-move" data-id="' . $post_id . '"></i>';
			break;
		}
	}

	public function manage_pages_columns( $columns ) {
		$columns = ['happyfiles_move' => ''] + $columns;

		return $columns;
	}

	/**
	 * Show categories sidebar if post type is enabled
	 */
	public function render() {
		$post_type = Helpers::get_current_post_type();
		
		if ( in_array( $post_type, self::$enabled_post_types ) ) {
			Admin::render();
		}
	}

	public function register_setting_post_types() {
		register_setting( HAPPYFILES_SETTINGS_GROUP, self::$settings_post_types );

		if ( ! get_option( self::$settings_license_key, false ) ) {
			register_setting( HAPPYFILES_SETTINGS_GROUP, self::$settings_license_key );
		}
	}
	
	public function render_setting_post_types() {
		$license_key = get_option( self::$settings_license_key, '' );
		$license_key_encrypted = $license_key ? substr_replace( $license_key, 'XXXXXXXXXXXXXXXXXXXXXXXX', 4, strlen( $license_key ) - 8 ) : '';
		?>
		<tr>
			<th><?php esc_html_e( 'One Click Updates', 'happyfiles' ); ?> (PRO)</th>
			<td>
				<input name="<?php echo ! $license_key_encrypted ? esc_attr( self::$settings_license_key ) : ''; ?>" id="<?php echo ! $license_key_encrypted ? esc_attr( self::$settings_license_key ) : ''; ?>" type="text" placeholder="<?php echo esc_attr( $license_key_encrypted ); ?>" style="width: 320px; font-family: monospace;" spellcheck="false"<?php echo $license_key_encrypted ? ' readonly' : ''; ?>>
				<?php if ( $license_key_encrypted ) { ?> 
				<input type="submit" name="happyfiles_deactivate_license" id="happyfiles_deactivate_license" class="button button-secondary" value="<?php esc_html_e( 'Deactivate License', 'happyfiles' ); ?>">
				<?php } ?>

				<p class="description"><?php echo sprintf( esc_html__( 'Paste your license key from your %s in here to enable one-click plugin updates from your WordPress dashboard.', 'happyfiles' ), '<a href="https://happyfiles.io/account/" target="_blank">' . esc_html__( 'HappyFiles account', 'happyfiles' ) .'</a>' ); ?></p>
			</td>
		</tr>

		<tr>
			<th><?php esc_html_e( 'Post Types', 'happyfiles' ); ?> (PRO)</th>
			<td>
				<fieldset>
					<?php 
					$registered_post_types = get_post_types( ['show_ui' => true], 'objects' );
					
					foreach ( $registered_post_types as $post_type ) { 
						$post_type_name = $post_type->name;
						$post_type_label = $post_type->label;

						if ( in_array( $post_type_name, ['attachment', 'wp_block'] ) ) {
							continue;
						}
						?>
						<label for="<?php echo esc_attr( self::$settings_post_types . '_' . $post_type_name ); ?>">
						<input name="<?php echo esc_attr( self::$settings_post_types ); ?>[]" id="<?php echo esc_attr( self::$settings_post_types . '_' . $post_type_name ); ?>" type="checkbox" <?php checked( in_array( $post_type_name, self::$enabled_post_types ) ); ?> value="<?php echo esc_attr( $post_type_name ); ?>">
						<?php echo $post_type->label; ?>
						</label>
						<br>
					<?php } ?>
				</fieldset>
			</td>
		</tr>
		<?php
	}

	public function register_taxonomy_for_posts_pages() {
		$post_types = is_array( self::$enabled_post_types ) ? self::$enabled_post_types : [];

		foreach ( $post_types as $post_type ) {
			$taxonomy = "hf_cat_$post_type"; // Tax max. length of 32 characters

			register_taxonomy(
				$taxonomy,
				[$post_type],
				[
					'labels' => [
						'name'               => esc_html__( 'Category', 'happyfiles' ),
						'singular_name'      => esc_html__( 'Category', 'happyfiles' ),
						'add_new_item'       => esc_html__( 'Add New Category', 'happyfiles' ),
						'edit_item'          => esc_html__( 'Edit Category', 'happyfiles' ),
						'new_item'           => esc_html__( 'Add New Category', 'happyfiles' ),
						'search_items'       => esc_html__( 'Search Category', 'happyfiles' ),
						'not_found'          => esc_html__( 'Category not found', 'happyfiles' ),
						'not_found_in_trash' => esc_html__( 'Category not found in trash', 'happyfiles' ),
					],
					'public'             => false,
					'publicly_queryable' => false,
					'hierarchical'       => true,
					'show_ui'            => true,
					'show_in_menu'       => false,
					'show_in_nav_menus'  => false,
					'show_in_quick_edit' => false,
					'show_admin_column'  => false,
					'rewrite'            => false,
					'update_count_callback' => '_update_generic_term_count', // Update term count for attachments
				]
			);
		}
	}

	public function enqueue_scripts() {
		$current_screen = get_current_screen();

		if ( 
			in_array( $current_screen->post_type, self::$enabled_post_types ) || // Post type screens
			$current_screen->base === 'settings_page_happyfiles_settings'        // HappyFiles settings page to deactivate license
		) {
			wp_enqueue_style( 'happyfiles-pro', HAPPYFILES_ASSETS_URL . '/css/pro.min.css', [], filemtime( HAPPYFILES_ASSETS_PATH .'/css/pro.min.css' ) );
			wp_enqueue_script( 'happyfiles-pro', HAPPYFILES_ASSETS_URL . '/js/pro.js', ['jquery'], filemtime( HAPPYFILES_ASSETS_PATH .'/js/pro.js' ), true );
		}
	}

	public function pre_get_posts( $query ) {
		if ( ! $query->is_main_query() ) {
			return;
		}

		global $pagenow;

		// Return if we are not editing a post type
    if ( $pagenow !== 'edit.php' ) {
      return;
		}

		$post_type = $query->get( 'post_type' );
		$happyfiles_taxonomy = Helpers::get_taxonomy_by( 'post_type', $post_type );

		if ( ! in_array( $post_type, self::$enabled_post_types ) ) {
			return;
		}

		if ( ! $happyfiles_taxonomy ) {
			return;
		}

		// Get user selected category from stored user meta data
		$user_category_state = get_user_meta( get_current_user_id(), 'happyfiles_category_state', true );
		$open_category = isset( $user_category_state[$happyfiles_taxonomy] ) ? $user_category_state[$happyfiles_taxonomy] : [];

		// No or all categories selected
		if ( ! $open_category || $open_category === 'all' ) {
			return;
		}

		// Uncategorized
		if ( $open_category == '-1' ) {
			$tax_query = [
				[
					'taxonomy' => $happyfiles_taxonomy,
					'operator' => 'NOT EXISTS',
				]
			];
		} 
		
		// Custom taxonomy term
		else {
			$tax_query = [
				[
					'taxonomy' 			   => $happyfiles_taxonomy,
					'field' 			     => 'term_id',
					'terms' 			     => [intval( $open_category )],
					'include_children' => false,
				],
			];
		}

		$query->set( 'tax_query', $tax_query );
	}

  /**
   * Exclude term children for non-AJAX taxonomy requests: List View
   * 
   * https://core.trac.wordpress.org/ticket/18703#comment:10
   *
   * @param object $query Already parsed query object.
   * @return void
   */
  public function parse_tax_query( $query ) {
		global $pagenow, $typenow;

    // Return if we are not editing a post type
    if ( $pagenow !== 'edit.php' ) {
      return;
		}

		$post_type = $query->get( 'post_type' );

		if ( ! in_array( $post_type, self::$enabled_post_types ) ) {
			return;
		}

    if ( ! empty( $query->tax_query->queries ) ) {
      foreach ( $query->tax_query->queries as &$tax_query ) {
				$taxonomy = $tax_query['taxonomy'];

				if ( $taxonomy === Helpers::get_taxonomy_by( 'post_type', $typenow ) ) {
					$term_id = &$query->query_vars[$taxonomy];

          // Uncategorized
          if ( $term_id == '-1' ) {
            $tax_query['operator'] = 'NOT EXISTS';
          }
          
          else {
            $tax_query['include_children'] = false;
            $tax_query['field'] = 'id';
          }
        }
      }
    }
  }

  public function add_categories_filter() {
		global $pagenow, $typenow;

    if ( $pagenow !== 'edit.php' ) {
      return;
		}

		$post_type = get_post_type();

		if ( ! $post_type ) {
			$post_type = $typenow;
		}

		if ( ! in_array( $post_type, self::$enabled_post_types ) ) {
			return;
		}

		$taxonomy = Helpers::get_taxonomy_by( 'post_type', $post_type );
		$open_term_id = Helpers::get_open_category();

		// Check if taxonomy exists
		if ( $taxonomy ) {
			wp_dropdown_categories( [
				'class'            => 'happyfiles-filter',
				'show_option_all'  => sprintf( esc_html__( 'All %s Categories', 'happyfiles' ), ucwords( str_replace( '_', ' ', $post_type ) ) ),
				'show_option_none' => esc_html__( 'Uncategorized', 'happyfiles' ),
				'taxonomy'         => $taxonomy,
				'name'             => $taxonomy,
				'selected'         => $open_term_id,
				'hierarchical'     => false,
				'hide_empty'       => false,
			] );
		}
	}
	
	/**
	 * Check remotely if a newer version is available
	 *
	 * @param $transient Transient for WordPress theme updates.
	 * @return void
	 *
	 * @since 0.1.0
	 */
	public static function check_for_update( $transient ) {
		// 'checked' is an array with all installed plugins and their version numbers
		if ( empty( $transient->checked ) ) {
			return $transient;
		}

		// Get HappyFiles Pro license key from HappyFiles settings
		$license_key = get_option( self::$settings_license_key, '' );

		if ( ! $license_key ) {
			return $transient;
		}

		// Build theme update request URL with license_key and domain parameters
		$get_update_data_url = add_query_arg(
			[
				'license_key' => $license_key,
				'domain'      => get_site_url(),
				'time'        => time(), // Don't cache response
			],
			'https://happyfiles.io/api/happyfiles/get_update_data/'
		);

		$request = wp_remote_get( $get_update_data_url );

		// Check if remote GET request has been successful (better than using is_wp_error)
		if ( wp_remote_retrieve_response_code( $request ) !== 200 ) {
			return $transient;
		}

		$request = json_decode( wp_remote_retrieve_body( $request ), true );

		$installed_version = HAPPYFILES_VERSION;

		// Check remotely if user newer version is available
		$latest_version = isset( $request['new_version'] ) ? $request['new_version'] : $installed_version;
		$newer_version_available = version_compare( $latest_version, $installed_version, '>' );

		if ( ! $newer_version_available ) {
			return $transient;
		}

		$request['icons'] = [
			'1x' => 'https://ps.w.org/happyfiles/assets/icon-256x256.png',
		];

		$request['banners'] = [
			'1x' => 'https://ps.w.org/happyfiles/assets/banner-772x250.jpg',
		];

		$request['slug'] = 'happyfiles-pro';
		$request['plugin'] = 'happyfiles-pro/happyfiles-pro.php';
		$request['tested'] = get_bloginfo( 'version' );

		// Save HappyFiles Pro update data in transient
		$transient->response['happyfiles-pro/happyfiles-pro.php'] = (object) $request;

		return $transient;
	}

	public function deactivate_license() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( ['message' => esc_html__( 'Only the site admin can deactivate the HappyFiles PRO license.', 'happyfiles' )] );
		}

		$license_key_deleted = delete_option( self::$settings_license_key );

		if ( $license_key_deleted ) {
			wp_send_json_success( ['message' => esc_html__( 'License key has been deleted successfully.', 'happyfiles' )] );
		} else {
			wp_send_json_error( ['message' => esc_html__( 'Error: License key could not be deleted.', 'happyfiles' )] );
		}
	}

}

new Pro();