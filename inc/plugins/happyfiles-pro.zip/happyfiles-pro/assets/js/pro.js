jQuery(document).ready(function() {
  // Init happyFiles in media library
  if (!document.body.classList.contains('edit-php')) {
    return
  }

  if (happyFiles.debug) {
    console.warn('pro.js')
	}

	HappyFiles.initSidebar()
})