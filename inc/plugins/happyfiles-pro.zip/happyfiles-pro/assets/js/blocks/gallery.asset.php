<?php return array('dependencies' => array('wp-element'), 'version' => '558027e558249d8505fa');
