<?php

add_filter('swift3_avoid_blob', function($list){
      $list[] = 'html2canvas';
      return $list;
});

?>