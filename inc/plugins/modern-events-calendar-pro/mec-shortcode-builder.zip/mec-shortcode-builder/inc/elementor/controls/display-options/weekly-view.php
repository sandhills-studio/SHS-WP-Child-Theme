<?php
namespace Elementor;

/** no direct access **/
defined('MECEXEC') or die();

/**
 * Webnus MEC elementor weekly View class
 * @author Webnus <info@webnus.biz>
 */
class MEC_elementor_weekly_display_opts
{

    /**
     * Register Elementor weekly View options
     * @author Webnus <info@webnus.biz>
     */
    public static function options($self)
    {
        // Start Date
        $self->add_control(
            // mec_sk_options_
            'weekly_start_date_type',
            array(
                'label'     => __('Start Date', 'mec-shortcode-builder'),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => 'start_current_week',
                'options'   => [
                    'start_current_week'    => __('Current Week', 'mec-shortcode-builder'),
                    'start_next_week'       => __('Next Week', 'mec-shortcode-builder'),
                    'start_current_month'   => __('Start of Current Month', 'mec-shortcode-builder'),
                    'start_next_month'      => __('Start of Next Month', 'mec-shortcode-builder'),
                    'date'                  => __('On a certain date', 'mec-shortcode-builder'),
                ],
                'condition'     => [
                    'skin'  => [
                        'weekly_view'
                    ],
                ]
            )
        );
        // On a certain date
        $self->add_control(
            'weekly_start_date',
            [
                'label'     => __('On a certain date', 'mec-shortcode-builder'),
                'type'      => \Elementor\Controls_Manager::DATE_TIME,
                'picker_options' => [
                    'dateFormat' => 'M d Y'
                ],
                'default'   => date('M d Y', current_time('timestamp')),
                'condition' => [
                    'skin' => [
                        'weekly_view'
                    ],
                    'weekly_start_date_type' => [
                        'date'
                    ],
                ],
            ]
        );
        // Events per day
        $self->add_control(
            'weekly_limit',
            [
                'label'         => __('Events per day', 'mec-shortcode-builder'),
                'type'          => \Elementor\Controls_Manager::NUMBER,
                'placeholder'   => __('eg. 6', 'mec-shortcode-builder'),
                'min'           => 1,
                'max'           => 99999999,
                'step'          => 1,
                'default'       => 6,
                'condition' => [
                    'skin' => [
                        'weekly_view'
                    ],
                ],
            ]
        );
        // Next/Previous Buttons
        $self->add_control(
            'weekly_next_previous_button',
            [
                'label'         => __('Next/Previous Buttons', 'mec-shortcode-builder'),
                'type'          => \Elementor\Controls_Manager::SWITCHER,
                'label_on'      => __('Show', 'mec-shortcode-builder'),
                'label_off'     => __('Hide', 'mec-shortcode-builder'),
                'return_value'  => '1',
                'default'       => '1',
                'condition' => [
                    'skin' => [
                        'weekly_view'
                    ],
                ],
            ]
        );
		// Localtime
		$self->add_control(
			'weekly_include_local_time',
			[
				'label'        => __( 'Include Local Time', 'mec-shortcode-builder' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'mec-shortcode-builder' ),
				'label_off'    => __( 'Hide', 'mec-shortcode-builder' ),
				'return_value' => '1',
				'default'      => '0',
				'condition'    => [
					'skin' => [
						'weekly_view',
					],
				],
			]
		);
		// Normal Label
		$self->add_control(
			'weekly_display_label',
			[
				'label'        => __( 'Display Normal Labels', 'mec-shortcode-builder' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'mec-shortcode-builder' ),
				'label_off'    => __( 'Hide', 'mec-shortcode-builder' ),
				'return_value' => '1',
				'default'      => '0',
				'condition'    => [
					'skin' => [
						'weekly_view',
					],
				],
			]
		);
		// Reason for Cancellation
		$self->add_control(
			'weekly_reason_for_cancellation',
			[
				'label'        => __( 'Display Reason for Cancellation', 'mec-shortcode-builder' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'mec-shortcode-builder' ),
				'label_off'    => __( 'Hide', 'mec-shortcode-builder' ),
				'return_value' => '1',
				'default'      => '0',
				'condition'    => [
					'skin' => [
						'weekly_view',
					],
				],
			]
		);

        $self->add_control(
            // mec_sk_options_
            'weekly_view_custom_data',
            [
                'label'        => __( 'Display Custom Fields', 'mec-shortcode-builder' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'mec-shortcode-builder' ),
                'label_off'    => __( 'Hide', 'mec-shortcode-builder' ),
                'return_value' => '1',
                'default'      => '0',
                'condition'    => [
                    'skin' => [
                        'weekly_view',
                    ],
                ],
            ]
        );

        $self->add_control(
            // mec_sk_options_
            'weekly_booking_button',
            [
                'label'        => __( 'Booking Button / Icon', 'mec-shortcode-builder' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'mec-shortcode-builder' ),
                'label_off'    => __( 'Hide', 'mec-shortcode-builder' ),
                'return_value' => '1',
                'default'      => '0',
                'condition'    => [
                    'skin' => [
                        'weekly_view',
                    ],
                ],
            ]
        );

        $self->add_control(
            'weekly_display_categories',
            [
                'label'        => __( 'Display Categories', 'mec-shortcode-builder' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'mec-shortcode-builder' ),
                'label_off'    => __( 'Hide', 'mec-shortcode-builder' ),
                'return_value' => '1',
                'default'      => '0',
                'condition'    => [
                    'skin' => [
                        'weekly_view',
                    ],
                ],
            ]
        );

        $self->add_control(
            // mec_sk_options_
            'weekly_display_organizer',
            [
                'label'        => __( 'Display Organizers', 'mec-shortcode-builder' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'mec-shortcode-builder' ),
                'label_off'    => __( 'Hide', 'mec-shortcode-builder' ),
                'return_value' => '1',
                'default'      => '0',
                'condition'    => [
                    'skin' => [
                        'weekly_view'
                    ],
                ],
            ]
        );

        $self->add_control(
            // mec_sk_options_
            'weekly_detailed_time',
            [
                'label'        => __( 'Detailed Time', 'mec-shortcode-builder' ),
                'description'  => __( 'For Multiple Day Events', 'mec-shortode-builder' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'mec-shortcode-builder' ),
                'label_off'    => __( 'Hide', 'mec-shortcode-builder' ),
                'return_value' => '1',
                'default'      => '0',
                'condition'    => [
                    'skin' => [
                        'weekly_view'
                    ],
                ],
            ]
        );

        // Single Event Display Method
        $self->add_control(
            'weekly_sed_method',
            [
                'label'     => __('Single Event Display Method', 'mec-shortcode-builder'),
                'type'      => \Elementor\Controls_Manager::SELECT,
                'default'   => '0',
                'label_block' => true,
                'options'   => [
					'0'  => __( 'Current Window', 'mec-shortcode-builder' ),
					'new' => __( 'New Window', 'mec-shortcode-builder' ),
					'm1' => __( 'Modal Popup', 'mec-shortcode-builder' ),
					'no' => __( 'Disable Link', 'mec-shortcode-builder' ),
                ],
                'condition' => [
                    'skin' => [
                        'weekly_view'
                    ],
                ],

            ]
        );

        $self->add_control(
            // mec_sk_options_
            'weekly_image_popup',
            [
                'label'        => __( 'Display content\'s images as Popup', 'mec-shortcode-builder' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'mec-shortcode-builder' ),
                'label_off'    => __( 'Hide', 'mec-shortcode-builder' ),
                'return_value' => '1',
                'default'      => '0',
                'condition'    => [
                    'skin' => [
                        'weekly_view'
                    ],
                    'weekly_sed_method' => [
                        'm1',
                    ]
                ],
            ]
        );
    }
}
