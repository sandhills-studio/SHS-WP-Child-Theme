<?php

namespace Elementor;

/** No direct access */
defined('MECEXEC') or die();

/**
 * Webnus MEC elementor addon shortcode class
 *
 * @author Webnus <info@webnus.biz>
 */
class MEC_addon_elementor_form_builder extends \Elementor\Widget_Base
{

	/**
	 * Retrieve MEC widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name()
	{
		return 'MEC-form';
	}

	/**
	 * Retrieve MEC widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title()
	{
		return __('MEC Form Builder', 'mec-form-builder');
	}

	/**
	 * Retrieve MEC widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon()
	{
		return 'eicon-form-horizontal';
	}

	/**
	 * Set widget category.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget category.
	 */
	public function get_categories()
	{
		return array('mec');
	}

	/**
	 * Set widget style.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget style.
	 */
	public function get_style_depends()
	{
		return ['form-builder'];
	}

	/**
	 * Register MEC widget controls.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls(){

		$this->mec_form_fields( 'reg' );
		$this->mec_form_fields( 'bfixed' );

		$this->register_form_controls();
	}

	public function get_wp_user_fields(){

		return \MEC\Forms\FormFields::getInstance()->get_wp_user_fields();
	}

	public function get_form_fields( $form_type ){

		$e_id = get_the_ID();
		$fields = get_post_meta($e_id, 'mec_'.$form_type.'_fields', true);

		if( !is_array($fields) || empty($fields) ){

			switch( $form_type ){
				case 'reg':

					$fields = \MEC\Base::get_main()->get_reg_fields();
					break;
				case 'bfixed':

					$fields = \MEC\Base::get_main()->get_bfixed_fields();
					break;
			}
		}

		return is_array( $fields ) ? $fields : [];
	}

	public function get_field_types( $form_type ){

		$field_types = [];

		$fields = 'reg' === $form_type ? [
			'name' => [
				'required' => true,
				'type'     => 'name',
				'text'     => __('MEC Name', 'mec-form-builder'),
			]
		] : [];


		switch( $form_type ){

			case 'reg':
			case 'bfixed':

				$fields = array_merge_recursive(
					$fields,
					\MEC\Forms\SettingsForm::getInstance()->get_element_fields( $form_type )
				);

			break;
		}

		unset($fields['first_name']);
		unset($fields['last_name']);

		if( is_array( $fields ) && !empty( $fields ) ){

			foreach( $fields as $key => $fixed_field ){

				$text = isset($fixed_field['text']) ? $fixed_field['text'] : false;
				if( !$text ){

					continue;
				}

				$field_types[ $key ] = $text;
			}
		}

		return $field_types;
	}

	public function mec_form_fields( $form_type ){

		$field_types = $this->get_field_types( $form_type );
		$form_fields = $this->get_form_fields( $form_type );
		$meta_key_fields = array_merge(
			array('none' => __('None', 'mec-form-builder')),
			(array)$this->get_wp_user_fields()
		);


		switch( $form_type ){
			case 'reg':

				$options_key = 'display_options';
				$form_title_option_key = 'form_title';
				$label = __('Attendee Form Options', 'mec-form-builder');
				$default_form_title = __('Attendees Form', 'mec-form-builder');
				break;
			case 'bfixed':

				$options_key = 'fixed_form_options';
				$form_title_option_key = '';
				$label = __('Fixed Form Options', 'mec-form-builder');
				$default_form_title = '';
				break;
		}

		if( is_array( $form_fields ) && 'hide' === current($form_fields) ){

		    $key = key( $form_fields );
		    $form_fields[ $key ] = [];
		}


		$condition = array();

		$this->start_controls_section(
			$options_key,
			array(
				'label' => $label,
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		if( !empty( $form_title_option_key ) ){

			$this->add_control(
				$form_title_option_key,
				[
					'label'       => __('Form Title', 'mec-form-builder'),
					'type'        => \Elementor\Controls_Manager::TEXT,
					'default'     => $default_form_title,
					'label_block' => true,
				]
			);
		}else{

			$this->add_control(
				'hide_fixed_fields',
				[
					'type' => Controls_Manager::SWITCHER,
					'label' => __('Hide fixed fields','mec-form-builder'),
					'label_on' => __('Hide', 'mec-form-fields'),
					'label_off' => __('Show', 'mec-form-fields'),
					'return_value' => 'yes',
					'default' => 'yes',
				]
			);

			$condition = array(
				'hide_fixed_fields!' => 'yes'
			);
		}


		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'type',
			[
				'label'       => __('Field Type', 'mec-form-builder'),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => $field_types,
				'default'     => __('text', 'mec-form-builder'),
				'label_block' => true,
			]
		);


		$repeater->add_control(
			'mapping',
			[
				'label'       => __('Field Map', 'mec-form-builder'),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => $meta_key_fields,
				'default'     => 'none',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'mandatory',
			[
				'label'        => __('Required Field', 'mec-form-builder'),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __('Show', 'mec-form-builder'),
				'label_off'    => __('Hide', 'mec-form-builder'),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => [
					'type!' => [
						'name',
						'mec_email',
						'p'
					],
				],
			]
		);
		$repeater->add_control(
			'label',
			[
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __('Insert a label for this field', 'mec-form-builder'),
				'default' => __('Label', 'mec-form-builder'),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'paragraph',
			[
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __('Insert a label for this field', 'mec-form-builder'),
				'default' => __('Descriptions...', 'mec-form-builder'),
				'label_block' => true,
				'condition'   => [
					'type' => [
						'p',
					],
				],
			]
		);
		$repeater->add_control(
			'placeholder',
			[
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __('Insert a placeholder for this field', 'mec-form-builder'),
				'label_block' => true,
				'condition'   => [
					'type' => [
						'name',
						'mec_email',
						'text',
						'email',
						'tel',
						'textarea',
					],
				],
			]
		);
		$repeater->add_control(
			'agreement_desc',
			[
				'type'        => \Elementor\Controls_Manager::RAW_HTML,
				'raw'         => __('Instead of %s, the page title with a link will be show.', 'mec-form-builder'),
				'label_block' => true,
				'condition'   => [
					'type' => [
						'agreement',
					],
				],
			]
		);
		$repeater->add_control(
			'options',
			[
				'type'        => \Elementor\Controls_Manager::TEXT,
				'title'       => __('Options', 'mec-form-builder'),
				'placeholder' => __('first item,second item, third item', 'mec-form-builder'),
				'description' => __('Please separate with "," for example:<br> first item,second item,third item', 'mec-form-builder'),
				'label_block' => true,
				'default'	=> 'Option1, Option2',
				'condition'   => [
					'type' => [
						'checkbox',
						'radio',
						'select',
					],
				],
			]
		);
		$pages          = get_posts('post_type="page"&numberposts=-1');
		$argument_pages = array();

		foreach ($pages as $page) {
			$argument_pages[$page->ID] = $page->post_title;
		}

		$repeater->add_control(
			'page',
			[
				'label'       => __('Agreement Page', 'mec-form-builder'),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => $argument_pages,
				'label_block' => true,
				'condition'   => [
					'type' => [
						'agreement',
					],
				],
			]
		);
		$repeater->add_control(
			'status',
			[
				'label'       => __('Status', 'mec-form-builder'),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'checked',
				'options'     => [
					'checked'   => __('Checked by default', 'mec-form-builder'),
					'unchecked' => __('Unchecked by default', 'mec-form-builder'),
				],
				'label_block' => true,
				'condition'   => [
					'type' => [
						'agreement',
					],
				],
			]
		);

		$repeater->add_control(
			'inline',
			[
				'label'        => __('Half-Width', 'mec-form-builder'),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __('Enable', 'mec-form-builder'),
				'label_off'    => __('Disable', 'mec-form-builder'),
				'return_value' => 'enable',
				'default'      => 'disable',
				'description'  => __('This option enables your form to have 2 columns and the fields will be placed in pairs next to one another.', 'mec-form-builder'),
				'condition' => [
					'inline_third!' => 'enable'
				]
			]
		);
		$repeater->add_control(
			'inline_third',
			[
				'label'        => __('Third-Width', 'mec-form-builder'),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __('Enable', 'mec-form-builder'),
				'label_off'    => __('Disable', 'mec-form-builder'),
				'return_value' => 'enable',
				'default'      => 'disable',
				'description'  => __('This option enables your form to have 3 columns and the fields will be placed in pairs next to one another.', 'mec-form-builder'),
				'condition' => [
					'inline!' => 'enable'
				]
			]
		);
		$repeater->add_control(
			'single_row',
			[
				'label'        => __('Single-Line', 'mec-form-builder'),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __('Enable', 'mec-form-builder'),
				'label_off'    => __('Disable', 'mec-form-builder'),
				'return_value' => 'enable',
				'default'      => 'disable',
				'description'  => __('This option enables your form to have controls in single row.', 'mec-form-builder'),
			]
		);

		$repeater->add_control(
			'full_width',
			[
				'label'        => __('Full-Width', 'mec-form-builder'),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __('Enable', 'mec-form-builder'),
				'label_off'    => __('Disable', 'mec-form-builder'),
				'condition'    => array(
					'single_row' => 'enable',
					'inline_third' => 'enable'
				),
				'return_value' => 'enable',
				'default'      => 'disable',
			]
		);

		unset($form_fields['form_style_url']);

		$this->add_control(
			$form_type . '_fields',
			[
				'label'         => __('Elements List', 'mec-form-builder'),
				'type'          => \Elementor\Controls_Manager::REPEATER,
				'description'   => __('MEC Name and MEC Email are necessary and your form must contain both of them.', 'mec-form-builder'),
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ type }}}: {{{ label }}}',
				'default'       => $form_fields,
				'prevent_empty' => true,
				'condition' 	=> $condition
			]
		);

		$this->end_controls_section();
	}

	public function mec_update_form_fields(){

		$actions = stripslashes($_POST['actions']);
		if (false === strpos($actions, '"action":"render_widget"')) {

			return;
		}

		$settings = $this->get_settings_for_display();

		$form_types = [
			'reg',
			'bfixed',
		];
		$object_id = get_the_ID(); // elementor

		$actions = wp_unslash($_POST['actions']);
		$actions = json_decode($actions, true);
		$actions = current($actions);


		foreach( $form_types as $form_type ){

			$form_title_option_key = 'form_title';
			$meta_key_form_title = 'mec-booking-attendees-title';
			if( 'reg' !== $form_type ){

				$form_title_option_key = $form_type.'_form_title';
				$meta_key_form_title = 'mec_'.$form_type.'_form_title';
			}

			$form_title = self::search_in_array( $form_title_option_key, $actions );
			update_post_meta( $object_id, $meta_key_form_title, $form_title);

			$form_fields = self::search_in_array( $form_type . '_fields', $actions );

			$i = 0;
			if ($form_fields) {
				$args = [];
				$j = 0;
				foreach ($form_fields as $field) {
					// args
					if (isset($settings['inline']) && $settings['inline'] == 'enable') {
						$inline = 'enable';
					} else {
						$inline = isset($field['inline']) ? $field['inline'] : '';
					}
					if (isset($settings['inline_third']) && $settings['inline_third'] == 'enable') {
						$inline_third = 'enable';
					} else {
						$inline_third = isset($field['inline_third']) ? $field['inline_third'] : '';
					}
					if (isset($settings['single_row']) && $settings['single_row'] == 'enable') {
						$single_row = 'enable';
					} else {
						$single_row = isset($field['single_row']) ? $field['single_row'] : '';
					}


					$paragraph = isset($field['paragraph']) ? $field['paragraph'] : '';
					$label = isset($field['label']) ? $field['label'] : '';
					$args[$i] = array(
						'mandatory' => $field['mandatory'] == 'yes' ? '1' : '0',
						'type'      => isset($field['type']) ? $field['type'] : '',
						'mapping'      => isset($field['mapping']) && 'none' !== $field['mapping'] ? $field['mapping'] : '',
						'label'     => $label,
						'paragraph'     => $paragraph,
						'inline'    => $inline,
						'inline_third'    => $inline_third,
						'single_row'    => $single_row,
						'full_width'    => isset($field['full_width']) ? $field['full_width'] : '',
						'placeholder'    => isset($field['placeholder']) ? $field['placeholder'] : '',
					);

					// checkbox
					if (isset($field['options']) && $field['options']) {
						$options = !is_array( $field['options'] ) ? explode(',', $field['options'] ) : $field['options'];
						foreach ($options as $option) {
							$opts[$j]['label'] = $option;
							$j++;
						}
						$args[$i]['options'] = $opts;
						unset($opts);
					}

					// argument page
					if (isset($field['page']) && $field['page']) {
						$args[$i]['page'] = $field['page'];
					}

					// argument status
					if (isset($field['status']) && $field['status']) {
						$args[$i]['status'] = $field['status'];
					}
					$i++;
				}

				$form_fields = $args;

				if( 'bfixed' === $form_type && 'yes' === $settings['hide_fixed_fields']){
					$form_fields = array('hide');
					update_post_meta( $object_id, 'mec_'.$form_type.'_fields', 'no' );
				}

				$mec_options            = get_option('mec_options');
				$mec_options['form_style_url'] = site_url('wp-content/uploads/elementor/css/post-' . $object_id . '.css');
				$mec_options[ $form_type . '_fields' ] = $form_fields;
				update_post_meta( $object_id, 'mec_'.$form_type.'_fields', $form_fields );
				update_post_meta( $object_id, 'mec_options', $mec_options );

			}

		}
	}

	public function register_form_controls(){

		$base_selector = 'body .mec-events-meta-group-booking';

		$this->start_controls_section(
			'field_options',
			array(
				'label' => __('Form', 'mec-form-builder'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'inline',
			[
				'label'        => __('Half-Width', 'mec-form-builder'),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __('Enable', 'mec-form-builder'),
				'label_off'    => __('Disable', 'mec-form-builder'),
				'return_value' => 'enable',
				'default'      => 'disable',
				'description'  => __('This option enables your form to have 2 columns and the fields will be placed in pairs next to one another.', 'mec-form-builder'),
				'condition' => [
					'inline_third!' => 'enable'
				]
			]
		);
		$this->add_control(
			'inline_third',
			[
				'label'        => __('Third-Width', 'mec-form-builder'),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __('Enable', 'mec-form-builder'),
				'label_off'    => __('Disable', 'mec-form-builder'),
				'return_value' => 'enable',
				'default'      => 'disable',
				'description'  => __('This option enables your form to have 3 columns and the fields will be placed in pairs next to one another.', 'mec-form-builder'),
				'condition' => [
					'inline!' => 'enable',
				]
			]
		);

		$this->end_controls_section();

		// Wrap
		$this->start_controls_section(
			'wrap_options_form',
			array(
				'label' => __('Container', 'mec-form-builder'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'wrap_typography',
				'label'    => __('Typography', 'mec-form-builder'),
				'selector' => $base_selector,
			]
		);
		$this->add_control(
			'wrap_color',
			[
				'label'     => __('Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#424242',
				'selectors' => [
					$base_selector.',body .mec-single-event .mec-event-ticket-name,body .mec-single-event .mec-event-ticket-description,body .mec-single-event .mec-event-ticket-available,'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container label,'.$base_selector.' label' => 'color: {{VALUE}} !important',
				],
			]
		);
		$this->add_control(
			'wrap_bg',
			[
				'label'     => __('Background Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					$base_selector => 'background: {{VALUE}} !important',
				],
			]
		);
		$this->add_responsive_control(
			'wrap_padding',
			[
				'label'      => __('Padding', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$base_selector => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
			]
		);
		$this->add_responsive_control(
			'wrap_margin',
			[
				'label'      => __('Margin', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$base_selector => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'wrap_border',
				'label'    => __('Border', 'mec-form-builder'),
				'selector' => $base_selector,
			]
		);
		$this->add_responsive_control(
			'wrap_width',
			[
				'label'      => __('Width', 'mec-form-builder'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors'  => [
					$base_selector => 'width: {{SIZE}}{{UNIT}} !important;',
				],
			]
		);
		$this->add_responsive_control(
			'wrap_border_radius',
			[
				'label'      => __('Border Radius', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$base_selector => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'wrap_box_shadow',
				'label'    => __('Box Shadow', 'mec-form-builder'),
				'selectors' => [
					$base_selector => 'box-shadow: {{HORIZONTAL}}px {{VERTICAL}}px {{BLUR}}px {{SPREAD}}px {{COLOR}} {{box_shadow_position.VALUE}} !important;'
				]
			]
		);

		$this->end_controls_section();

		// H4 - Title
		$this->start_controls_section(
			'h4_options_form',
			array(
				'label' => __('Title', 'mec-form-builder'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'h4_typography',
				'label'    => __('Typography', 'mec-form-builder'),
				'selector' => $base_selector.' form > h4',
			]
		);
		$this->add_control(
			'h4_color',
			[
				'label'     => __('Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#424242',
				'selectors' => [
					$base_selector.' form > h4' => 'color: {{VALUE}} !important',
				],
			]
		);
		$this->add_control(
			'h4_underline_color',
			[
				'label'     => __('Underline Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#424242',
				'selectors' => [
					$base_selector.' form > h4:before' => 'border-color: {{VALUE}} !important',
				],
			]
		);
		$this->add_control(
			'h4_bg',
			[
				'label'     => __('Background Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					$base_selector.' form > h4' => 'background: {{VALUE}} !important',
				],
			]
		);
		$this->add_responsive_control(
			'h4_padding',
			[
				'label'      => __('Padding', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$base_selector.' form > h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}  !important;',
				],
			]
		);
		$this->add_responsive_control(
			'h4_margin',
			[
				'label'      => __('Margin', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$base_selector.' form > h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}  !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'h4_border',
				'label'    => __('Border', 'mec-form-builder'),
				'selector' => $base_selector.' form > h4',
			]
		);
		$this->add_responsive_control(
			'h4_width',
			[
				'label'      => __('Width', 'mec-form-builder'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors'  => [
					$base_selector.' form > h4' => 'width: {{SIZE}}{{UNIT}}  !important;',
				],
			]
		);
		$this->add_responsive_control(
			'h4_border_radius',
			[
				'label'      => __('Border Radius', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$base_selector.' form > h4' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}  !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'h4_box_shadow',
				'label'    => __('Box Shadow', 'mec-form-builder'),
				'selector' => '.mec-events-meta-group-booking form > h4',
				'selectors' => [
					$base_selector.' form > h4' => 'box-shadow: {{HORIZONTAL}}px {{VERTICAL}}px {{BLUR}}px {{SPREAD}}px {{COLOR}} !important;'
				]
			]
		);

		$this->end_controls_section();

		// H4 - Ticket Title
		$this->start_controls_section(
			'ticket_h4_options_form',
			array(
				'label' => __('Ticket Name', 'mec-form-builder'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'ticket_h4_typography',
				'label'    => __('Typography', 'mec-form-builder'),
				'selector' => $base_selector.' form h4 .mec-ticket-name',
			]
		);
		$this->add_control(
			'ticket_h4_color',
			[
				'label'     => __('Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#424242',
				'selectors' => [
					$base_selector.' form h4 .mec-ticket-name' => 'color: {{VALUE}} !important',
				],
			]
		);

		$this->add_control(
			'ticket_h4_bg',
			[
				'label'     => __('Background Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					$base_selector.' form h4 .mec-ticket-name' => 'background: {{VALUE}} !important',
				],
			]
		);
		$this->add_responsive_control(
			'ticket_h4_padding',
			[
				'label'      => __('Padding', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$base_selector.' form h4 .mec-ticket-name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}  !important;',
				],
			]
		);
		$this->add_responsive_control(
			'ticket_h4_margin',
			[
				'label'      => __('Margin', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$base_selector.' form h4 .mec-ticket-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}  !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ticket_h4_border',
				'label'    => __('Border', 'mec-form-builder'),
				'selector' => $base_selector.' form h4 .mec-ticket-name',
			]
		);
		$this->add_responsive_control(
			'ticket_h4_width',
			[
				'label'      => __('Width', 'mec-form-builder'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors'  => [
					$base_selector.' form h4 .mec-ticket-name' => 'width: {{SIZE}}{{UNIT}}  !important;',
				],
			]
		);
		$this->add_responsive_control(
			'ticket_h4_border_radius',
			[
				'label'      => __('Border Radius', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$base_selector.' form h4 .mec-ticket-name' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}  !important;',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ticket_h4_box_shadow',
				'label'    => __('Box Shadow', 'mec-form-builder'),
				'selector' => $base_selector.' form h4 .mec-ticket-name',
				'selectors' => [
					$base_selector.' form h4 .mec-ticket-name' => 'box-shadow: {{HORIZONTAL}}px {{VERTICAL}}px {{BLUR}}px {{SPREAD}}px {{COLOR}} {{box_shadow_position.VALUE}} !important;'
				]
			]
		);

		$this->end_controls_section();

		// Styling Options
		$this->start_controls_section(
			'label_options',
			array(
				'label' => __('Labels', 'mec-form-builder'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'label_typography',
				'label'    => __('Typography', 'mec-form-builder'),
				'selector' => $base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container .mec-form-fields label,' . $base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container label,' . $base_selector . ' label,body .mec-single-event .mec-booking label,'.$base_selector.' .mec-ticket-variation-name',
			]
		);
		$this->add_control(
			'label_color',
			[
				'label'     => __('Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#424242',
				'selectors' => [
					$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container label,'.$base_selector.' label,body .mec-single-event .mec-booking label,'.$base_selector.' .mec-ticket-variation-name' => 'display: table; color: {{VALUE}} !important',
				],
			]
		);
		$this->add_control(
			'label_bg',
			[
				'label'     => __('Background Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container label,'.$base_selector.' label,body .mec-single-event .mec-booking label,'.$base_selector.' .mec-ticket-variation-name' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'label_padding',
			[
				'label'      => __('Padding', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container label,'.$base_selector.' label,body .mec-single-event .mec-booking label,'.$base_selector.' .mec-ticket-variation-name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'label_margin',
			[
				'label'      => __('Margin', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container label,'.$base_selector.' label,body .mec-single-event .mec-booking label,'.$base_selector.' .mec-ticket-variation-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'checkbox_radiobutton_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'checkbox_radiobutton_typography',
				'label'    => __('Checkbox & Radio Button Typography', 'mec-form-builder'),
				'selector' => $base_selector.' ul.mec-book-tickets-container li .mec-book-reg-field-checkbox label:not(:first-child),'.$base_selector.' ul.mec-book-tickets-container li .mec-book-reg-field-radio label:not(:first-child)',
			]
		);
		$this->add_control(
			'checkbox_radiobutton_color',
			[
				'label'     => __('Checkbox & Radio Button Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#424242',
				'selectors' => [
					$base_selector.' ul.mec-book-tickets-container li .mec-book-reg-field-checkbox label:not(:first-child),'.$base_selector.' ul.mec-book-tickets-container li .mec-book-reg-field-radio label:not(:first-child)' => 'color: {{VALUE}} !important',
				],
			]
		);
		$this->add_control(
			'agreement_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'agreement_typography',
				'label'    => __('Agreement', 'mec-form-builder'),
				'selector' => $base_selector.' ul.mec-book-tickets-container li .mec-book-reg-field-agreement label',
			]
		);
		$this->add_control(
			'paragraph_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'paragraph_typography',
				'label'    => __('Paragraph', 'mec-form-builder'),
				'selector' => $base_selector.' ul.mec-book-tickets-container li .mec-book-reg-field-p p',
			]
		);
		$this->add_control(
			'paragraph_color',
			[
				'label'     => __('Paragraph Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#424242',
				'selectors' => [
					$base_selector.' ul.mec-book-tickets-container li .mec-book-reg-field-p p' => 'color: {{VALUE}} !important',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'field_options_form',
			array(
				'label' => __('Fields', 'mec-form-builder'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$inputs_box_selector = $base_selector.' .mec-booking form div';
		$inputs_selectors =
			$inputs_box_selector.' input[type=date],'
			.$inputs_box_selector.' input[type=email],'
			.$inputs_box_selector.' input[type=number],'
			.$inputs_box_selector.' input[type=password],'
			.$inputs_box_selector.' input[type=tel],'
			.$inputs_box_selector.' input[type=text],'
			.$inputs_box_selector.' select,'
			.$inputs_box_selector.' textarea,'
			.$inputs_box_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input,'
			.$inputs_box_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container textarea,'
			.$inputs_box_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container select';
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'field_typography',
				'label'    => __('Typography', 'mec-form-builder'),
				'selector' => $inputs_selectors,
			]
		);
		$this->add_control(
			'field_color',
			[
				'label'     => __('Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#424242',
				'selectors' => [
					$inputs_selectors => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'field_placeholder_color',
			[
				'label'     => __('PlaceHolder Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#424242',
				'selectors' => [
					$base_selector.' input::placeholder,'.$base_selector.' textarea::placeholder' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'field_bg',
			[
				'label'     => __('Background Color', 'mec-form-builder'),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					$inputs_selectors => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'field_padding',
			[
				'label'      => __('Padding', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$inputs_selectors => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'field_margin',
			[
				'label'      => __('Margin', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$inputs_selectors => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'field_border',
				'label'    => __('Border', 'mec-form-builder'),
				'selector' => $inputs_selectors,
			]
		);
		$this->add_responsive_control(
			'width',
			[
				'label'      => __('Width', 'mec-form-builder'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors'  => [
					$inputs_selectors => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'wrap_max_height',
			[
				'label'      => __('Maximum height for input', 'mec-form-builder'),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 10,
						'max'  => 80,
						'step' => 4,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 46,
				],
				'selectors'  => [
					'body .mec-single-event li.mec-book-ticket-container input, body .mec-single-event li.mec-book-ticket-container select' => 'max-height: {{SIZE}}{{UNIT}} !important;',
				],
			]
		);
		$this->add_responsive_control(
			'field_border_radius',
			[
				'label'      => __('Border Radius', 'mec-form-builder'),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					$inputs_selectors => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'field_box_shadow',
				'label'    => __('Box Shadow', 'mec-form-builder'),
				'selector' => $base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input[type="date"],
				'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input[type="text"],
				'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input[type="file"],
				'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input[type="email"],
				'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input[type="tel"],
				'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input[type="text"],
				'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container textarea',
				'selectors' => [
				$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input[type="date"],
				'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input[type="text"],
				'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input[type="file"],
				'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input[type="email"],
				'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input[type="tel"],
				'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container input[type="text"],
				'.$base_selector.' ul.mec-book-tickets-container li.mec-book-ticket-container textarea' => 'box-shadow: {{HORIZONTAL}}px {{VERTICAL}}px {{BLUR}}px {{SPREAD}}px {{COLOR}} {{box_shadow_position.VALUE}} !important;'
				]
			]
		);

		$this->end_controls_section();
	}

	public static function search_in_array($key, $array, $l = 40)
	{
		foreach ($array as $k => $val) {
			if ($key === $k) {
				return $val;
			} else if (is_array($val)) {
				$d = static::search_in_array($key, $val, $l - 1);
				if ($d) {
					return $d;
				}
			}
		}
		if ($l === 0) {
			return false;
		}
	}

	/**
	 * Render MEC widget output on the frontend.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render()
	{
		// Requirements
		$settings        = $this->get_settings_for_display();
		$e_id       	 = get_the_ID();
		$args            = $opts = array();
		$i               = $j = 1;
		$mec_email_count = $mec_name_count  = 0;
		$me              = $mn = false;

		// Update options
		if ($_POST) {

			$this->mec_update_form_fields();
		}

		$reg_fields = $this->get_form_fields( 'reg' );

		if (!is_array($reg_fields) || !is_array( current( $reg_fields ) )) {
			$reg_fields = array();
		}

		foreach ($reg_fields as $field) {

			if (empty($field) || !isset($field['type'])) {
				continue;
			}

			if ($me) {
				if ($field['type'] == 'mec_email') {
					$mec_email_count++;
					continue;
				}
			}

			if ($mn) {
				if ($field['type'] == 'name') {
					$mec_name_count++;
					continue;
				}
			}

			if ($field['type'] == 'mec_email') {
				$me = true;
				$mec_email_count++;
			}

			if ($field['type'] == 'name') {
				$mn = true;
				$mec_name_count++;
			}

			// // args
			// $args[$i] = array(
			// 	'mandatory' => $field['mandatory'] == 'yes' ? '1' : '0',
			// 	'type'      => $field['type'],
			// 	'label'     => $field['label'],
			// 	'paragraph'     => isset($field['paragraph']) ? $field['paragraph'] : '',
			// 	'placeholder'     => $field['placeholder'],
			// 	'inline'    => $field['inline'],
			// 	'inline_third'    => $field['inline_third'],
			// 	'single_row'    => $field['single_row'],
			// 	'full_width'    => isset($field['full_width']) ? $field['full_width'] : '',
			// );
			// if (isset($field['paragraph'])) {
			// 	$args[$i]['label'] = $field['paragraph'];
			// }

			// // checkbox
			// if (isset($field['options']) && $field['options']) {
			// 	$options = '';
			// 	if (isset($field['options']) && !is_array($field['options'])) {
			// 		$options = explode(',', $field['options']);
			// 	}

			// 	if (!$options || !is_array($field['options'])) {
			// 		$options = [
			// 			'Option1',
			// 			'Option2'
			// 		];
			// 	}
			// 	foreach ($options as $option) {
			// 		$opts[$j]['label'] = $option;
			// 		$j++;
			// 	}
			// 	$args[$i]['options'] = $opts;
			// 	unset($opts);
			// }

			// // argument page
			// if (isset($field['page']) && $field['page']) {
			// 	$args[$i]['page'] = $field['page'];
			// }

			// // argument page
			// if ($field['status']) {
			// 	$args[$i]['status'] = $field['status'];
			// }

			$i++;
		}

		$bfixed_fields = $this->get_form_fields( 'bfixed' );

		$global_inheritance = get_post_meta($e_id, 'mec_reg_fields_global_inheritance', true);
		if (trim($global_inheritance) == '') {
			$global_inheritance = 1;
		}
		$uniqueid = (isset($uniqueid) ? $uniqueid : ''); ?>

		<div class="mec-single-event">
			<div class="mec-events-meta-group-booking">
				<form id="mec_book_form<?php echo $uniqueid; ?>" class="mec-booking-form-container" novalidate="novalidate">
					<h4><?php echo esc_html($settings['form_title'], 'mec-form-builder'); ?></h4>

					<?php self::display_fixed_fields( $bfixed_fields, $settings ); ?>
					<ul class="mec-book-tickets-container">

						<li class="mec-book-ticket-container">
							<h4><span class="mec-ticket-name"><?php echo esc_html('Ticket Name', 'mec-form-builder'); ?></span><span class="mec-ticket-price"></span></h4>
							<!-- Custom fields -->
							<?php
							echo '<div class="mec-wrap"><div class="row">';
							if ($settings['inline'] == 'enable') {
							}
							?>
							<?php
							if (count($reg_fields)) :
								$mec_email = false;
								$mec_name  = false;

								foreach ($reg_fields as $reg_field_id => $reg_field) :
									if (isset($reg_field['type'])) {
										if ($reg_field['type'] == 'mec_email') {
											$mec_email = true;
										}
										if ($reg_field['type'] == 'name') {
											$mec_name = true;
										}
									}
								endforeach;

								if (!$mec_email) {
									echo '<h4 style="color:red">' . esc_html__('Please add MEC Email field in your form.', 'mec-form-builder') . '</h3>';
								}

								if (!$mec_name) {
									echo '<h4 style="color:red">' . esc_html__('Please add MEC Name field in your form.', 'mec-form-builder') . '</h3>';
								}

								if ($mec_email_count > 1) {
									echo '<h4 style="color:red">' . esc_html__('Duplicate Error! Please add just one MEC Email field in your form.', 'mec-form-builder') . '</h3>';
								}

								if ($mec_name_count > 1) {
									echo '<h4 style="color:red">' . esc_html__('Duplicate Error! Please add just one MEC Name field in your form.', 'mec-form-builder') . '</h3>';
								}

								foreach ($reg_fields as $reg_field_id => $reg_field) :
									if (!is_numeric($reg_field_id) or !isset($reg_field['type'])) {
										continue;
									}

							?>
									<?php
									$single_row = isset($reg_field['single_row']) && $reg_field['single_row'] == 'enable';
									$full_width = isset($reg_field['full_width']) && $reg_field['full_width'] == 'enable';

									if ($single_row) : ?>
										<div class="clearfix"></div>
									<?php endif; ?>

									<div class="<?php if (!$full_width && (isset($reg_field['inline']) && $reg_field['inline'] == 'enable' || $settings['inline'] == 'enable')) {
													echo 'col-md-6';
												} else if (!$full_width && (isset($reg_field['inline_third']) && $reg_field['inline_third'] == 'enable' || $settings['inline_third'] == 'enable')) {
													echo 'col-md-4';
												} else {
													echo 'col-md-12';
												} ?> mec-form-fields mec-book-reg-field-<?php echo $reg_field['type']; ?> <?php echo ((isset($reg_field['mandatory']) and $reg_field['mandatory']) ? 'mec-reg-mandatory' : ''); ?>" data-ticket-id="<?php echo $j; ?>" data-field-id="<?php echo $reg_field_id; ?>">
										<?php if (isset($reg_field['label']) and $reg_field['type'] != 'agreement' and $reg_field['type'] != 'mec_email' and $reg_field['type'] != 'name') : ?>
											<label for="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id; ?>"><?php _e($reg_field['label'], 'mec-form-builder'); ?><?php echo ((isset($reg_field['mandatory']) and $reg_field['mandatory']) ? '<span class="wbmec-mandatory">*</span>' : ''); ?></label>
										<?php elseif ($reg_field['type'] == 'mec_email') : ?>
											<label for="mec_book_reg_field_email<?php echo $j . '_' . $reg_field_id; ?>"><?php _e($reg_field['label'], 'mec-form-builder'); ?><?php echo ((isset($reg_field['mandatory']) and $reg_field['mandatory']) ? '<span class="wbmec-mandatory">*</span>' : ''); ?></label>
										<?php elseif ($reg_field['type'] == 'name') : ?>
											<label for="mec_book_reg_field_name<?php echo $j . '_' . $reg_field_id; ?>"><?php _e($reg_field['label'], 'mec-form-builder'); ?><?php echo ((isset($reg_field['mandatory']) and $reg_field['mandatory']) ? '<span class="wbmec-mandatory">*</span>' : ''); ?></label>
										<?php endif; ?>

										<?php /** Text **/ if ($reg_field['type'] == 'text') :
										?>
											<input id="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id; ?>" type="text" name="book[tickets][<?php echo $j; ?>][reg][<?php echo $reg_field_id; ?>]" value="" placeholder="<?php _e($reg_field['placeholder'], 'mec-form-builder'); ?>" <?php
											if (isset($reg_field['mandatory']) and $reg_field['mandatory']) {
												echo 'required';
											}
											?> />
										<?php /** Date **/ elseif ($reg_field['type'] == 'date') : ?>
											<input id="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id; ?>" class="mec-date-picker" type="date" name="book[tickets][<?php echo $j; ?>][reg][<?php echo $reg_field_id; ?>]" value="" placeholder="<?php _e($reg_field['placeholder'], 'mec-form-builder'); ?>" <?php
											if (isset($reg_field['mandatory']) and $reg_field['mandatory']) {
												echo 'required';
											}
											?> />
										<?php /** File **/ elseif ($reg_field['type'] == 'file') : ?>
											<input id="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id; ?>" type="file" name="book[tickets][<?php echo $j; ?>][reg][<?php echo $reg_field_id; ?>]" value="" placeholder="<?php _e($reg_field['placeholder'], 'mec-form-builder'); ?>" <?php
											if (isset($reg_field['mandatory']) and $reg_field['mandatory']) {
												echo 'required';
											}
											?> />
										<?php /** MEC Email **/ elseif ($reg_field['type'] == 'mec_email') : ?>
											<?php $reg_field['label'] = ($reg_field['label']) ? $reg_field['label'] : ''; ?>

											<input id="mec_book_reg_field_email<?php echo $j . '_' . $reg_field_id; ?>" type="email" name="book[tickets][<?php echo $j; ?>][email]" value="" placeholder="<?php _e($reg_field['placeholder'], 'mec-form-builder'); ?>" required />
										<?php /** MEC Name **/ elseif ($reg_field['type'] == 'name') : ?>
											<?php $reg_field['label'] = ($reg_field['label']) ? $reg_field['label'] : ''; ?>

											<input id="mec_book_reg_field_name<?php echo $j . '_' . $reg_field_id; ?>" type="text" name="book[tickets][<?php echo $j; ?>][name]" value="" placeholder="<?php _e($reg_field['placeholder'], 'mec-form-builder'); ?>" required />
										<?php /** Email **/ elseif ($reg_field['type'] == 'email') : ?>
											<input id="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id; ?>" type="email" name="book[tickets][<?php echo $j; ?>][reg][<?php echo $reg_field_id; ?>]" value="" placeholder="<?php _e($reg_field['placeholder'], 'mec-form-builder'); ?>" <?php
											if (isset($reg_field['mandatory']) and $reg_field['mandatory']) {
												echo 'required';
											}
											?> />
										<?php /** Tel **/ elseif ($reg_field['type'] == 'tel') : ?>
											<input id="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id; ?>" type="tel" oninput="this.value=this.value.replace(/(?![0-9])./gmi,'')" name="book[tickets][<?php echo $j; ?>][reg][<?php echo $reg_field_id; ?>]" value="" placeholder="<?php _e($reg_field['placeholder'], 'mec-form-builder'); ?>" <?php
											if (isset($reg_field['mandatory']) and $reg_field['mandatory']) {
												echo 'required';
											}
											?> />
										<?php /** Textarea **/ elseif ($reg_field['type'] == 'textarea') : ?>
											<textarea id="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id; ?>" name="book[tickets][<?php echo $j; ?>][reg][<?php echo $reg_field_id; ?>]" placeholder="<?php _e($reg_field['placeholder'], 'mec-form-builder'); ?>" <?php
											if (isset($reg_field['mandatory']) and $reg_field['mandatory']) {
												echo 'required';
											}
											?>></textarea>
										<?php /** Dropdown **/ elseif ($reg_field['type'] == 'select') : ?>
											<select id="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id; ?>" name="book[tickets][<?php echo $j; ?>][reg][<?php echo $reg_field_id; ?>]" placeholder="<?php _e($reg_field['placeholder'], 'mec-form-builder'); ?>" <?php
												if (isset($reg_field['mandatory']) and $reg_field['mandatory']) {
													echo 'required';
												}
												?>>
												<?php foreach ($reg_field['options'] as $reg_field_option) : ?>
													<option value="<?php esc_attr_e($reg_field_option['label'], 'mec-form-builder'); ?>"><?php _e($reg_field_option['label'], 'mec-form-builder'); ?></option>
												<?php endforeach; ?>
											</select>
										<?php /** Radio **/ elseif ($reg_field['type'] == 'radio') : ?>
											<?php foreach ($reg_field['options'] as $reg_field_option) : ?>
												<label for="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id . '_' . strtolower(str_replace(' ', '_', $reg_field_option['label'])); ?>">
													<input type="radio" id="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id . '_' . strtolower(str_replace(' ', '_', $reg_field_option['label'])); ?>" name="book[tickets][<?php echo $j; ?>][reg][<?php echo $reg_field_id; ?>]" value="<?php _e($reg_field_option['label'], 'mec-form-builder'); ?>" />
													<?php _e($reg_field_option['label'], 'mec-form-builder'); ?>
												</label>
											<?php endforeach; ?>
										<?php /** Checkbox **/ elseif ($reg_field['type'] == 'checkbox') :
											if (!isset($reg_field['options']) || empty($reg_field['options'])) {
												$reg_field['options'] = [];
											}
										?>
											<?php foreach ($reg_field['options'] as $reg_field_option) : ?>
												<label for="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id . '_' . strtolower(str_replace(' ', '_', $reg_field_option['label'])); ?>">
													<input type="checkbox" id="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id . '_' . strtolower(str_replace(' ', '_', $reg_field_option['label'])); ?>" name="book[tickets][<?php echo $j; ?>][reg][<?php echo $reg_field_id; ?>][]" value="<?php _e($reg_field_option['label'], 'mec-form-builder'); ?>" />
													<?php _e($reg_field_option['label'], 'mec-form-builder'); ?>
												</label>
											<?php endforeach; ?>
										<?php /** Agreement **/ elseif ($reg_field['type'] == 'agreement') : ?>
											<label for="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id; ?>">
												<?php echo ((isset($reg_field['mandatory']) and $reg_field['mandatory']) ? '<span class="wbmec-mandatory">*</span>' : ''); ?>
												<input type="checkbox" id="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id; ?>" name="book[tickets][<?php echo $j; ?>][reg][<?php echo $reg_field_id; ?>]" value="1" <?php echo (!isset($reg_field['status']) or (isset($reg_field['status']) and $reg_field['status'] == 'checked')) ? 'checked="checked"' : ''; ?> <?php
												if (isset($reg_field['mandatory']) and $reg_field['mandatory']) {
													echo 'required';
												}
												?> />
												<?php echo sprintf(__($reg_field['label'], 'mec-form-builder'), '<a href="' . get_the_permalink($reg_field['page']) . '" target="_blank">' . get_the_title($reg_field['page']) . '</a>'); ?>

											</label>
										<?php /** paragraph **/ elseif ($reg_field['type'] == 'p') : ?>
											<p for="mec_book_reg_field_reg<?php echo $j . '_' . $reg_field_id; ?>">
												<?php echo @$reg_field['paragraph']; ?>
											</p>
										<?php endif; ?>
									</div>

									<?php if ($single_row) : ?>
										<div class="clearfix"></div>
									<?php endif; ?>
							<?php endforeach;
							endif; ?>
							<?php echo '</div></div>';
							if ($settings['inline'] == 'enable') {
							} ?>
						</li>
					</ul>
				</form>
			</div>
		</div>
	 <?php
	}

	public static function display_fixed_fields( $bfixed_fields, $settings ){

		if( isset( $settings['hide_fixed_fields'] ) && 'yes' === $settings['hide_fixed_fields'] ){
			return;
		}

		if (is_array($bfixed_fields) and count($bfixed_fields)) : ?>
			<ul class="mec-book-bfixed-fields-container">
				<li class="mec-book-bfixed-field">
					<!-- Custom fields -->
					<?php
					echo '<div class="mec-wrap"><div class="row">';
					?>
					<?php

					foreach ($bfixed_fields as $bfixed_field_id => $bfixed_field) :

						if (!is_numeric($bfixed_field_id) or !isset($bfixed_field['type'])) {
							continue;
						}

						if( !isset($bfixed_field['placeholder']) ){
							$bfixed_field['placeholder'] = '';
						}

						$single_row = isset($bfixed_field['single_row']) && $bfixed_field['single_row'] == 'enable';
						$full_width = isset($bfixed_field['full_width']) && $bfixed_field['full_width'] == 'enable';

						if ($single_row) : ?>
							<div class="clearfix"></div>
						<?php endif; ?>

						<div class="<?php if (!$full_width && (isset($bfixed_field['inline']) && $bfixed_field['inline'] == 'enable' || $settings['inline'] == 'enable')) {
										echo 'col-md-6';
									} else if (!$full_width && (isset($bfixed_field['inline_third']) && $bfixed_field['inline_third'] == 'enable' || $settings['inline_third'] == 'enable')) {
										echo 'col-md-4';
									} else {
										echo 'col-md-12';
									} ?> mec-form-fields mec-book-reg-field-<?php echo $bfixed_field['type']; ?> <?php echo ((isset($bfixed_field['mandatory']) and $bfixed_field['mandatory']) ? 'mec-reg-mandatory' : ''); ?>" data-field-id="<?php echo $bfixed_field_id; ?>">
							<?php if (isset($bfixed_field['label']) and $bfixed_field['type'] != 'agreement') : ?>
								<label for="mec_book_reg_field_reg<?php echo $j . '_' . $bfixed_field_id; ?>"><?php _e($bfixed_field['label'], 'mec-form-builder'); ?><?php echo ((isset($reg_field['mandatory']) and $reg_field['mandatory']) ? '<span class="wbmec-mandatory">*</span>' : ''); ?></label>
							<?php endif; ?>

							<?php /** Text **/ if ($bfixed_field['type'] == 'text') :
							?>
								<input id="mec_book_bfixed_field_reg<?php echo $bfixed_field_id; ?>" type="text" name="book[fields][<?php echo $bfixed_field_id; ?>]" value="" placeholder="<?php _e($bfixed_field['placeholder'], 'mec'); ?>" <?php
								if (isset($bfixed_field['mandatory']) and $bfixed_field['mandatory']) {
									echo 'required';
								}
								?> />
							<?php /** Date **/ elseif ($bfixed_field['type'] == 'date') : ?>
								<input id="mec_book_bfixed_field_reg<?php echo $bfixed_field_id; ?>" class="mec-date-picker" type="date" name="book[fields][<?php echo $bfixed_field_id; ?>]" value="" placeholder="<?php _e($bfixed_field['placeholder'], 'mec'); ?>" <?php
								if (isset($bfixed_field['mandatory']) and $bfixed_field['mandatory']) {
									echo 'required';
								}
								?> />
							<?php /** File **/ elseif ($bfixed_field['type'] == 'file') : ?>
								<input id="mec_book_bfixed_field_reg<?php echo $bfixed_field_id; ?>" type="file" name="book[fields][<?php echo $bfixed_field_id; ?>]" value="" placeholder="<?php _e($bfixed_field['placeholder'], 'mec'); ?>" <?php
								if (isset($bfixed_field['mandatory']) and $bfixed_field['mandatory']) {
									echo 'required';
								}
								?> />
							<?php /** MEC Email **/ elseif ($bfixed_field['type'] == 'mec_email') : ?>
								<?php $bfixed_field['label'] = ($bfixed_field['label']) ? $bfixed_field['label'] : ''; ?>

								<input id="mec_book_bfixed_field_email<?php echo $bfixed_field_id; ?>" type="email" name="book[fields][<?php echo $j; ?>][email]" value="" placeholder="<?php _e($bfixed_field['placeholder'], 'mec'); ?>" required />
							<?php /** MEC Name **/ elseif ($bfixed_field['type'] == 'name') : ?>
								<?php $bfixed_field['label'] = ($bfixed_field['label']) ? $bfixed_field['label'] : ''; ?>

								<input id="mec_book_bfixed_field_name<?php echo $bfixed_field_id; ?>" type="text" name="book[fields][<?php echo $j; ?>][name]" value="" placeholder="<?php _e($bfixed_field['placeholder'], 'mec'); ?>" required />
							<?php /** Email **/ elseif ($bfixed_field['type'] == 'email') : ?>
								<input id="mec_book_bfixed_field_reg<?php echo $bfixed_field_id; ?>" type="email" name="book[fields][<?php echo $bfixed_field_id; ?>]" value="" placeholder="<?php _e($bfixed_field['placeholder'], 'mec'); ?>" <?php
								if (isset($bfixed_field['mandatory']) and $bfixed_field['mandatory']) {
									echo 'required';
								}
								?> />

							<?php /** Tel **/ elseif ($bfixed_field['type'] == 'tel') : ?>
								<input id="mec_book_bfixed_field_reg<?php echo $bfixed_field_id; ?>" type="tel" oninput="this.value=this.value.replace(/(?![0-9])./gmi,'')" name="book[fields][<?php echo $bfixed_field_id; ?>]" value="" placeholder="<?php _e($bfixed_field['placeholder'], 'mec'); ?>" <?php
								if (isset($bfixed_field['mandatory']) and $bfixed_field['mandatory']) {
									echo 'required';
								}
								?> />

							<?php /** Textarea **/ elseif ($bfixed_field['type'] == 'textarea') : ?>
								<textarea id="mec_book_bfixed_field_reg<?php echo $bfixed_field_id; ?>" name="book[fields][<?php echo $bfixed_field_id; ?>]" placeholder="<?php _e($bfixed_field['placeholder'], 'mec'); ?>" <?php
								if (isset($bfixed_field['mandatory']) and $bfixed_field['mandatory']) {
									echo 'required';
								}
								?>></textarea>
							<?php /** Dropdown **/ elseif ($bfixed_field['type'] == 'select') : ?>
								<select id="mec_book_bfixed_field_reg<?php echo $bfixed_field_id; ?>" name="book[fields][<?php echo $bfixed_field_id; ?>]" placeholder="<?php _e($bfixed_field['placeholder'], 'mec'); ?>" <?php
									if (isset($bfixed_field['mandatory']) and $bfixed_field['mandatory']) {
										echo 'required';
									}
									?>>
									<?php foreach ($bfixed_field['options'] as $bfixed_field_option) : ?>
										<option value="<?php esc_attr_e($bfixed_field_option['label'], 'mec'); ?>"><?php _e($bfixed_field_option['label'], 'mec'); ?></option>
									<?php endforeach; ?>
								</select>

							<?php /** Radio **/ elseif ($bfixed_field['type'] == 'radio') : ?>
							<?php foreach ($bfixed_field['options'] as $bfixed_field_option) : ?>
								<label for="mec_book_bfixed_field_reg<?php echo $bfixed_field_id . '_' . strtolower(str_replace(' ', '_', $bfixed_field_option['label'])); ?>">
									<input type="radio" id="mec_book_bfixed_field_reg<?php echo $bfixed_field_id . '_' . strtolower(str_replace(' ', '_', $bfixed_field_option['label'])); ?>" name="book[fields][<?php echo $bfixed_field_id; ?>]" value="<?php _e($bfixed_field_option['label'], 'mec'); ?>" />
									<?php _e($bfixed_field_option['label'], 'mec'); ?>
								</label>
							<?php endforeach; ?>

							<?php /** Checkbox **/ elseif ($bfixed_field['type'] == 'checkbox') :
								if (!isset($bfixed_field['options']) || empty($bfixed_field['options'])) {
									$bfixed_field['options'] = [];
								}
							?>
									<?php /** Checkbox **/ elseif ($bfixed_field['type'] == 'checkbox') : ?>
							<?php foreach ($bfixed_field['options'] as $bfixed_field_option) : ?>
								<label for="mec_book_bfixed_field_reg<?php echo $bfixed_field_id . '_' . strtolower(str_replace(' ', '_', $bfixed_field_option['label'])); ?>">
									<input type="checkbox" id="mec_book_bfixed_field_reg<?php echo $bfixed_field_id . '_' . strtolower(str_replace(' ', '_', $bfixed_field_option['label'])); ?>" name="book[fields][<?php echo $bfixed_field_id; ?>][]" value="<?php _e($bfixed_field_option['label'], 'mec'); ?>" />
									<?php _e($bfixed_field_option['label'], 'mec'); ?>
										</label>
									<?php endforeach; ?>

									<?php /** Agreement **/ elseif ($bfixed_field['type'] == 'agreement') : ?>
							<label for="mec_book_bfixed_field_reg<?php echo $bfixed_field_id; ?>">
								<input type="checkbox" id="mec_book_bfixed_field_reg<?php echo $bfixed_field_id; ?>" name="book[fields][<?php echo $bfixed_field_id; ?>]" value="1" <?php echo (!isset($bfixed_field['status']) or (isset($bfixed_field['status']) and $bfixed_field['status'] == 'checked')) ? 'checked="checked"' : ''; ?> onchange="mec_agreement_change(this);" />
								<?php echo ((isset($bfixed_field['mandatory']) and $bfixed_field['mandatory']) ? '<span class="wbmec-mandatory">*</span>' : ''); ?>
								<?php echo sprintf(__(stripslashes($bfixed_field['label']), 'mec'), '<a href="' . get_the_permalink($bfixed_field['page']) . '" target="_blank">' . get_the_title($bfixed_field['page']) . '</a>'); ?>
							</label>

							<?php /** Paragraph **/ elseif ($bfixed_field['type'] == 'p') : ?>
								<p><?php echo do_shortcode(stripslashes($bfixed_field['content'])); ?></p>
							<?php endif; ?>
						</div>

						<?php if ($single_row) : ?>
							<div class="clearfix"></div>
						<?php endif; ?>

					<?php endforeach;?>
					<?php echo '</div></div>'; ?>
				</li>
			</ul>
		<?php endif;
	}
}
