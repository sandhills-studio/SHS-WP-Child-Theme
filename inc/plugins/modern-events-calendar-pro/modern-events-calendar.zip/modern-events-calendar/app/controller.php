<?php
/** no direct access **/
defined('MECEXEC') or die();

/**
 * Webnus MEC controller class.
 * @author Webnus <info@webnus.net>
 */
class MEC_controller extends MEC_base
{
    /**
     * Constructor method
     * @author Webnus <info@webnus.net>
     */
    public function __construct()
    {
    }
}