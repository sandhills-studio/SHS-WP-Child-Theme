<div class="fl-example-text">
    <?php echo do_shortcode('[MEC id="'.$settings->mec_shortcode.'"]')  ?>
</div>
