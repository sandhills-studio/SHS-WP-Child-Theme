<?php

namespace MEC\FES;

use MEC\Singleton;

class FormBuilder extends Singleton {

    /**
     * Return title html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function title( $post, $atts = array() ){
        ?>
            <div class="mec-form-row mec-fes-title">
                <label for="mec_fes_title"><?php esc_html_e('Title', 'mec'); ?> <span class="mec-required">*</span></label>
                <input type="text" name="mec[title]" id="mec_fes_title" value="<?php echo (isset($post->post_title) ? esc_attr($post->post_title) : ''); ?>" required="required" />
            </div>
        <?php
    }

    /**
     * Return editor html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function editor( $post, $atts = array() ){
        ?>
            <div class="mec-form-row mec-fes-editor">
                <?php wp_editor(
                    (isset($post->post_content) ? $post->post_content : ''),
                    'mec_fes_content',
                    array(
                        'textarea_name'=>'mec[content]'
                    )
                ); ?>
            </div>
        <?php
    }

    /**
     * Return excerpt html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function excerpt( $post, $atts = array() ){

        $required = isset( $atts['required'] ) && $atts['required'] ? true : false;
        $excerpt = isset($post->post_excerpt) ? esc_textarea($post->post_excerpt) : '';
        ?>
            <div class="mec-meta-box-fields mec-fes-excerpt" id="mec-excerpt">
                <h4><?php esc_html_e('Excerpt', 'mec'); ?> <?php echo ( $required ? '<span class="mec-required">*</span>' : ''); ?></h4>
                <div class="mec-form-row">
                    <div class="mec-col-12">
                        <textarea name="mec[excerpt]" id="mec_fes_excerpt" class="widefat" rows="10" title="<?php esc_attr_e('Optional Event Excerpt', 'mec'); ?>" placeholder="<?php esc_attr_e('Optional Event Excerpt', 'mec'); ?>" <?php echo ( $required ? 'required' : ''); ?>><?php echo $excerpt; ?></textarea>
                    </div>
                </div>
            </div>
        <?php
    }

    /**
     * Return datetime html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function datetime( $post, $atts = array() ){

        $post_id = $post->ID;

        // This date format used for datepicker
        $datepicker_format = $atts['datepicker_format'] ?? 'Y-m-d';
        $time_format = $atts['time_format'] ?? 12;

        $allday = get_post_meta($post_id, 'mec_allday', true);
        $one_occurrence = get_post_meta($post_id, 'one_occurrence', true);
        $comment = get_post_meta($post_id, 'mec_comment', true);
        $hide_time = get_post_meta($post_id, 'mec_hide_time', true);
        $hide_end_time = get_post_meta($post_id, 'mec_hide_end_time', true);

        $start_date = get_post_meta($post_id, 'mec_start_date', true);

        // Advanced Repeating Day
        $advanced_days = get_post_meta( $post->ID, 'mec_advanced_days', true );
        $advanced_days = (is_array($advanced_days)) ? $advanced_days : array();
        $advanced_str = (count($advanced_days)) ? implode('-', $advanced_days) : '';

        $start_time_hour = get_post_meta($post_id, 'mec_start_time_hour', true);
        if(trim($start_time_hour) == '') $start_time_hour = 8;

        $start_time_minutes = get_post_meta($post_id, 'mec_start_time_minutes', true);
        if(trim($start_time_minutes) == '') $start_time_minutes = 0;

        $start_time_ampm = get_post_meta($post_id, 'mec_start_time_ampm', true);
        if(trim($start_time_ampm) == '') $start_time_ampm = 'AM';

        $end_date = get_post_meta($post_id, 'mec_end_date', true);

        $end_time_hour = get_post_meta($post_id, 'mec_end_time_hour', true);
        if(trim($end_time_hour) == '') $end_time_hour = 6;

        $end_time_minutes = get_post_meta($post_id, 'mec_end_time_minutes', true);
        if(trim($end_time_minutes) == '') $end_time_minutes = 0;

        $end_time_ampm = get_post_meta($post_id, 'mec_end_time_ampm', true);
        if(trim($end_time_ampm) == '') $end_time_ampm = 'PM';

        $repeat_status = get_post_meta($post_id, 'mec_repeat_status', true);
        $repeat_type = get_post_meta($post_id, 'mec_repeat_type', true);
        if(trim($repeat_type) == '') $repeat_type = 'daily';

        $repeat_interval = get_post_meta($post_id, 'mec_repeat_interval', true);
        if(trim($repeat_interval) == '' and in_array($repeat_type, array('daily', 'weekly'))) $repeat_interval = 1;

        $certain_weekdays = get_post_meta($post_id, 'mec_certain_weekdays', true);
        if($repeat_type != 'certain_weekdays') $certain_weekdays = array();

        $in_days_str = get_post_meta($post_id, 'mec_in_days', true);
        $in_days = trim($in_days_str) ? explode(',', $in_days_str) : array();

        $mec_repeat_end = get_post_meta($post_id, 'mec_repeat_end', true);
        if(trim($mec_repeat_end) == '') $mec_repeat_end = 'never';

        $repeat_end_at_occurrences = get_post_meta($post_id, 'mec_repeat_end_at_occurrences', true);
        if(trim($repeat_end_at_occurrences) == '') $repeat_end_at_occurrences = 9;

        $repeat_end_at_date = get_post_meta($post_id, 'mec_repeat_end_at_date', true);

        ?>
            <div class="mec-meta-box-fields mec-fes-datetime" id="mec-date-time">
                <h4><?php esc_html_e('Date and Time', 'mec'); ?></h4>
                <div id="mec_meta_box_date_form">
                    <div class="mec-title">
                        <span class="mec-dashicons dashicons dashicons-calendar-alt"></span>
                        <label for="mec_start_date"><?php esc_html_e('Start Date', 'mec'); ?></label>
                    </div>
                    <div class="mec-form-row">
                        <div class="mec-col-4">
                            <input type="text" name="mec[date][start][date]" id="mec_start_date" value="<?php echo esc_attr(\MEC\Base::get_main()->standardize_format($start_date, $datepicker_format)); ?>" placeholder="<?php esc_html_e('Start Date', 'mec'); ?>" autocomplete="off" />
                        </div>
                        <div class="mec-col-6 mec-time-picker <?php echo ($allday == 1) ? 'mec-util-hidden' : ''; ?>">
                            <?php \MEC\Base::get_main()->timepicker(array(
                                'method' => $time_format,
                                'time_hour' => $start_time_hour,
                                'time_minutes' => $start_time_minutes,
                                'time_ampm' => $start_time_ampm,
                                'name' => 'mec[date][start]',
                                'id_key' => 'start_',
                                'include_h0' => true,
                            )); ?>
                        </div>
                    </div>
                    <div class="mec-title">
                        <span class="mec-dashicons dashicons dashicons-calendar-alt"></span>
                        <label for="mec_end_date"><?php esc_html_e('End Date', 'mec'); ?></label>
                    </div>
                    <div class="mec-form-row">
                        <div class="mec-col-4">
                            <input type="text" name="mec[date][end][date]" id="mec_end_date" value="<?php echo esc_attr(\MEC\Base::get_main()->standardize_format($end_date, $datepicker_format)); ?>" placeholder="<?php esc_html_e('End Date', 'mec'); ?>" autocomplete="off" />
                        </div>
                        <div class="mec-col-6 mec-time-picker <?php echo ($allday == 1) ? 'mec-util-hidden' : ''; ?>">
                            <?php \MEC\Base::get_main()->timepicker(array(
                                'method' => $time_format,
                                'time_hour' => $end_time_hour,
                                'time_minutes' => $end_time_minutes,
                                'time_ampm' => $end_time_ampm,
                                'name' => 'mec[date][end]',
                                'id_key' => 'end_',
                            )); ?>
                        </div>
                    </div>
                    <div class="mec-form-row">
                        <input <?php if($allday == '1') echo 'checked="checked"'; ?> type="checkbox" name="mec[date][allday]" id="mec_allday" value="1" onchange="jQuery('.mec-time-picker').toggle();" /><label for="mec_allday"><?php esc_html_e('All-day Event', 'mec'); ?></label>
                    </div>
                    <div class="mec-form-row">
                        <input <?php if($hide_time == '1') echo 'checked="checked"'; ?> type="checkbox" name="mec[date][hide_time]" id="mec_hide_time" value="1" /><label for="mec_hide_time"><?php esc_html_e('Hide Event Time', 'mec'); ?></label>
                    </div>
                    <div class="mec-form-row">
                        <input <?php if($hide_end_time == '1') echo 'checked="checked"'; ?> type="checkbox" name="mec[date][hide_end_time]" id="mec_hide_end_time" value="1" /><label for="mec_hide_end_time"><?php esc_html_e('Hide Event End Time', 'mec'); ?></label>
                    </div>
                    <div class="mec-form-row">
                        <div class="mec-col-4">
                            <input type="text" class="" name="mec[date][comment]" id="mec_comment" placeholder="<?php esc_html_e('Notes on the time', 'mec'); ?>" value="<?php echo esc_attr($comment); ?>" />
                            <p class="description"><?php esc_html_e('It shows next to event time on the Single Event Page. You can enter notes such as timezone in this field.', 'mec'); ?></p>
                        </div>
                    </div>
                </div>
                <div id="mec_meta_box_repeat_form">
                    <h4><?php esc_html_e('Repeating', 'mec'); ?></h4>
                    <div class="mec-form-row">
                        <input <?php if($repeat_status == '1') echo 'checked="checked"'; ?> type="checkbox" name="mec[date][repeat][status]" id="mec_repeat" value="1" /><label for="mec_repeat"><?php esc_html_e('Event Repeating', 'mec'); ?></label>
                    </div>
                    <div class="mec-form-repeating-event-row">
                        <div class="mec-form-row">
                            <label class="mec-col-3" for="mec_repeat_type"><?php esc_html_e('Repeats', 'mec'); ?></label>
                            <select class="mec-col-2" name="mec[date][repeat][type]" id="mec_repeat_type">
                                <option <?php if($repeat_type == 'daily') echo 'selected="selected"'; ?> value="daily"><?php esc_html_e('Daily', 'mec'); ?></option>
                                <option <?php if($repeat_type == 'weekday') echo 'selected="selected"'; ?> value="weekday"><?php esc_html_e('Every Weekday', 'mec'); ?></option>
                                <option <?php if($repeat_type == 'weekend') echo 'selected="selected"'; ?> value="weekend"><?php esc_html_e('Every Weekend', 'mec'); ?></option>
                                <option <?php if($repeat_type == 'certain_weekdays') echo 'selected="selected"'; ?> value="certain_weekdays"><?php esc_html_e('Certain Weekdays', 'mec'); ?></option>
                                <option <?php if($repeat_type == 'weekly') echo 'selected="selected"'; ?> value="weekly"><?php esc_html_e('Weekly', 'mec'); ?></option>
                                <option <?php if($repeat_type == 'monthly') echo 'selected="selected"'; ?> value="monthly"><?php esc_html_e('Monthly', 'mec'); ?></option>
                                <option <?php if($repeat_type == 'yearly') echo 'selected="selected"'; ?> value="yearly"><?php esc_html_e('Yearly', 'mec'); ?></option>
                                <option <?php if($repeat_type == 'custom_days') echo 'selected="selected"'; ?> value="custom_days"><?php esc_html_e('Custom Days', 'mec'); ?></option>
                                <option <?php if($repeat_type == 'advanced') echo 'selected="selected"'; ?> value="advanced"><?php esc_html_e('Advanced', 'mec'); ?></option>
                            </select>
                        </div>
                        <div class="mec-form-row" id="mec_repeat_interval_container">
                            <label class="mec-col-3" for="mec_repeat_interval"><?php esc_html_e('Repeat Interval', 'mec'); ?></label>
                            <input class="mec-col-2" type="text" name="mec[date][repeat][interval]" id="mec_repeat_interval" placeholder="<?php esc_html_e('Repeat interval', 'mec'); ?>" value="<?php echo ($repeat_type == 'weekly' ? ($repeat_interval/7) : $repeat_interval); ?>" />
                        </div>
                        <div class="mec-form-row" id="mec_repeat_certain_weekdays_container">
                            <label class="mec-col-3"><?php esc_html_e('Week Days', 'mec'); ?></label>
                            <label><input type="checkbox" name="mec[date][repeat][certain_weekdays][]" value="1" <?php echo (in_array(1, $certain_weekdays) ? 'checked="checked"' : ''); ?> /><?php esc_html_e('Monday', 'mec'); ?></label>
                            <label>&nbsp;<input type="checkbox" name="mec[date][repeat][certain_weekdays][]" value="2" <?php echo (in_array(2, $certain_weekdays) ? 'checked="checked"' : ''); ?> /><?php esc_html_e('Tuesday', 'mec'); ?></label>
                            <label>&nbsp;<input type="checkbox" name="mec[date][repeat][certain_weekdays][]" value="3" <?php echo (in_array(3, $certain_weekdays) ? 'checked="checked"' : ''); ?> /><?php esc_html_e('Wednesday', 'mec'); ?></label>
                            <label>&nbsp;<input type="checkbox" name="mec[date][repeat][certain_weekdays][]" value="4" <?php echo (in_array(4, $certain_weekdays) ? 'checked="checked"' : ''); ?> /><?php esc_html_e('Thursday', 'mec'); ?></label>
                            <label>&nbsp;<input type="checkbox" name="mec[date][repeat][certain_weekdays][]" value="5" <?php echo (in_array(5, $certain_weekdays) ? 'checked="checked"' : ''); ?> /><?php esc_html_e('Friday', 'mec'); ?></label>
                            <label>&nbsp;<input type="checkbox" name="mec[date][repeat][certain_weekdays][]" value="6" <?php echo (in_array(6, $certain_weekdays) ? 'checked="checked"' : ''); ?> /><?php esc_html_e('Saturday', 'mec'); ?></label>
                            <label>&nbsp;<input type="checkbox" name="mec[date][repeat][certain_weekdays][]" value="7" <?php echo (in_array(7, $certain_weekdays) ? 'checked="checked"' : ''); ?> /><?php esc_html_e('Sunday', 'mec'); ?></label>
                        </div>
                        <div class="mec-form-row" id="mec_exceptions_in_days_container">
                            <div class="mec-form-row">
                                <div class="mec-col-12">
                                    <div class="mec-form-row">
                                        <div class="mec-col-4">
                                            <input type="text" id="mec_exceptions_in_days_start_date" value="" placeholder="<?php esc_html_e('Start', 'mec'); ?>" title="<?php esc_html_e('Start', 'mec'); ?>" class="mec_date_picker_dynamic_format widefat" autocomplete="off"/>
                                        </div>
                                        <div class="mec-col-8">
                                            <?php \MEC\Base::get_main()->timepicker(array(
                                                'method' => $time_format,
                                                'time_hour' => $start_time_hour,
                                                'time_minutes' => $start_time_minutes,
                                                'time_ampm' => $start_time_ampm,
                                                'name' => 'mec[exceptionsdays][start]',
                                                'id_key' => 'exceptions_in_days_start_',
                                                'include_h0' => true,
                                            )); ?>
                                        </div>
                                    </div>
                                    <div class="mec-form-row">
                                        <div class="mec-col-4">
                                            <input type="text" id="mec_exceptions_in_days_end_date" value="" placeholder="<?php esc_html_e('End', 'mec'); ?>" title="<?php esc_html_e('End', 'mec'); ?>" class="mec_date_picker_dynamic_format" autocomplete="off"/>
                                        </div>
                                        <div class="mec-col-8">
                                            <?php \MEC\Base::get_main()->timepicker(array(
                                                'method' => $time_format,
                                                'time_hour' => $end_time_hour,
                                                'time_minutes' => $end_time_minutes,
                                                'time_ampm' => $end_time_ampm,
                                                'name' => 'mec[exceptionsdays][end]',
                                                'id_key' => 'exceptions_in_days_end_',
                                            )); ?>
                                        </div>
                                    </div>
                                    <div class="mec-form-row">
                                        <div class="mec-col-12">
                                            <button class="button" type="button" id="mec_add_in_days"><?php esc_html_e('Add', 'mec'); ?></button>
                                            <span class="mec-tooltip">
                                                <div class="box top">
                                                    <h5 class="title"><?php esc_html_e('Custom Days Repeating', 'mec'); ?></h5>
                                                    <div class="content">
                                                        <p>
                                                            <?php esc_attr_e('Add certain days to event occurrence dates. If you have a single day event, start and end dates should be the same, If you have a multiple day event, the start and end dates must be commensurate with the initial date.', 'mec'); ?>
                                                            <a href="https://webnus.net/dox/modern-events-calendar/date-and-time/" target="_blank"><?php esc_html_e('Read More', 'mec'); ?></a>
                                                        </p>
                                                    </div>
                                                </div>
                                                <i title="" class="dashicons-before dashicons-editor-help"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mec-form-row" id="mec_in_days">
                                <?php $i = 1; foreach($in_days as $in_day): ?>
                                    <?php
                                    $in_day = explode(':', $in_day);
                                    $first_date = \MEC\Base::get_main()->standardize_format($in_day[0], $datepicker_format);
                                    $second_date = \MEC\Base::get_main()->standardize_format($in_day[1], $datepicker_format);

                                    $in_day_start_time = '';
                                    $in_day_start_time_label = '';
                                    $in_day_end_time = '';
                                    $in_day_end_time_label = '';

                                    if(isset($in_day[2]) and isset($in_day[3]))
                                    {
                                        $in_day_start_time = $in_day[2];
                                        $in_day_end_time = $in_day[3];

                                        // If 24 hours format is enabled then convert it back to 12 hours
                                        if( $time_format == 24 )
                                        {
                                            $in_day_ex_start = explode('-', $in_day_start_time);
                                            $in_day_ex_end = explode('-', $in_day_end_time);

                                            $in_day_start_time_label = \MEC\Base::get_main()->to_24hours($in_day_ex_start[0], $in_day_ex_start[2]).':'.$in_day_ex_start[1];
                                            $in_day_end_time_label = \MEC\Base::get_main()->to_24hours($in_day_ex_end[0], $in_day_ex_end[2]).':'.$in_day_ex_end[1];
                                        }
                                        else
                                        {
                                            $pos = strpos($in_day_start_time, '-');
                                            if($pos !== false) $in_day_start_time_label = substr_replace($in_day_start_time, ':', $pos, 1);

                                            $pos = strpos($in_day_end_time, '-');
                                            if($pos !== false) $in_day_end_time_label = substr_replace($in_day_end_time, ':', $pos, 1);

                                            $in_day_start_time_label = str_replace('-', ' ', $in_day_start_time_label);
                                            $in_day_end_time_label = str_replace('-', ' ', $in_day_end_time_label);
                                        }
                                    }

                                    $in_day = $first_date . ':' . $second_date.(trim($in_day_start_time) ? ':'.$in_day_start_time : '').(trim($in_day_end_time) ? ':'.$in_day_end_time : '');
                                    $in_day_label = $first_date. (trim($in_day_start_time_label) ? ' '.$in_day_start_time_label : '') . ' - ' . $second_date. (trim($in_day_end_time_label) ? ' '.$in_day_end_time_label : '');
                                    ?>
                                    <div class="mec-form-row" id="mec_in_days_row<?php echo esc_attr($i); ?>">
                                        <input type="hidden" name="mec[in_days][<?php echo esc_attr($i); ?>]" value="<?php echo esc_attr($in_day); ?>"/>
                                        <span class="mec-not-in-days-day"><?php echo \MEC_kses::element($in_day_label); ?></span>
                                        <span class="mec-not-in-days-remove" onclick="mec_in_days_remove(<?php echo esc_attr($i); ?>);">x</span>
                                    </div>
                                <?php $i++; endforeach; ?>
                            </div>
                            <input type="hidden" id="mec_new_in_days_key" value="<?php echo ($i+1); ?>" />
                            <div class="mec-util-hidden" id="mec_new_in_days_raw">
                                <div class="mec-form-row" id="mec_in_days_row:i:">
                                    <input type="hidden" name="mec[in_days][:i:]" value=":val:" />
                                    <span class="mec-not-in-days-day">:label:</span>
                                    <span class="mec-not-in-days-remove" onclick="mec_in_days_remove(:i:);">x</span>
                                </div>
                            </div>
                        </div>
                        <div id="mec-advanced-wraper">
                            <div class="mec-form-row">
                                <ul>
                                    <li>
                                        <?php esc_html_e('First', 'mec'); ?>
                                    </li>
                                    <ul>
                                        <?php $day_1th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 1); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_1th}.1"); ?>">
                                            <?php esc_html_e($day_1th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_1th); ?>.1-</span>
                                        </li>
                                        <?php $day_2th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 2); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_2th}.1"); ?>">
                                            <?php esc_html_e($day_2th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_2th); ?>.1-</span>
                                        </li>
                                        <?php $day_3th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 3); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_3th}.1"); ?>">
                                            <?php esc_html_e($day_3th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_3th); ?>.1-</span>
                                        </li>
                                        <?php $day_4th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 4); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_4th}.1"); ?>">
                                            <?php esc_html_e($day_4th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_4th); ?>.1-</span>
                                        </li>
                                        <?php $day_5th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 5); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_5th}.1"); ?>">
                                            <?php esc_html_e($day_5th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_5th); ?>.1-</span>
                                        </li>
                                        <?php $day_6th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 6); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_6th}.1"); ?>">
                                            <?php esc_html_e($day_6th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_6th); ?>.1-</span>
                                        </li>
                                        <?php $day_7th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 7); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_7th}.1"); ?>">
                                            <?php esc_html_e($day_7th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_7th); ?>.1-</span>
                                        </li>
                                    </ul>
                                </ul>
                                <ul>
                                    <li>
                                        <?php esc_html_e('Second', 'mec'); ?>
                                    </li>
                                    <ul>
                                        <?php $day_1th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 1); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_1th}.2"); ?>">
                                            <?php esc_html_e($day_1th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_1th); ?>.2-</span>
                                        </li>
                                        <?php $day_2th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 2); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_2th}.2"); ?>">
                                            <?php esc_html_e($day_2th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_2th); ?>.2-</span>
                                        </li>
                                        <?php $day_3th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 3); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_3th}.2"); ?>">
                                            <?php esc_html_e($day_3th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_3th); ?>.2-</span>
                                        </li>
                                        <?php $day_4th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 4); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_4th}.2"); ?>">
                                            <?php esc_html_e($day_4th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_4th); ?>.2-</span>
                                        </li>
                                        <?php $day_5th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 5); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_5th}.2"); ?>">
                                            <?php esc_html_e($day_5th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_5th); ?>.2-</span>
                                        </li>
                                        <?php $day_6th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 6); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_6th}.2"); ?>">
                                            <?php esc_html_e($day_6th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_6th); ?>.2-</span>
                                        </li>
                                        <?php $day_7th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 7); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_7th}.2"); ?>">
                                            <?php esc_html_e($day_7th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_7th); ?>.2-</span>
                                        </li>
                                    </ul>
                                </ul>
                                <ul>
                                    <li>
                                        <?php esc_html_e('Third', 'mec'); ?>
                                    </li>
                                    <ul>
                                        <?php $day_1th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 1); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_1th}.3"); ?>">
                                            <?php esc_html_e($day_1th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_1th); ?>.3-</span>
                                        </li>
                                        <?php $day_2th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 2); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_2th}.3"); ?>">
                                            <?php esc_html_e($day_2th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_2th); ?>.3-</span>
                                        </li>
                                        <?php $day_3th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 3); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_3th}.3"); ?>">
                                            <?php esc_html_e($day_3th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_3th); ?>.3-</span>
                                        </li>
                                        <?php $day_4th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 4); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_4th}.3"); ?>">
                                            <?php esc_html_e($day_4th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_4th); ?>.3-</span>
                                        </li>
                                        <?php $day_5th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 5); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_5th}.3"); ?>">
                                            <?php esc_html_e($day_5th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_5th); ?>.3-</span>
                                        </li>
                                        <?php $day_6th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 6); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_6th}.3"); ?>">
                                            <?php esc_html_e($day_6th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_6th); ?>.3-</span>
                                        </li>
                                        <?php $day_7th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 7); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_7th}.3"); ?>">
                                            <?php esc_html_e($day_7th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_7th); ?>.3-</span>
                                        </li>
                                    </ul>
                                </ul>
                                <ul>
                                    <li>
                                        <?php esc_html_e('Fourth', 'mec'); ?>
                                    </li>
                                    <ul>
                                        <?php $day_1th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 1); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_1th}.4"); ?>">
                                            <?php esc_html_e($day_1th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_1th); ?>.4-</span>
                                        </li>
                                        <?php $day_2th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 2); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_2th}.4"); ?>">
                                            <?php esc_html_e($day_2th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_2th); ?>.4-</span>
                                        </li>
                                        <?php $day_3th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 3); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_3th}.4"); ?>">
                                            <?php esc_html_e($day_3th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_3th); ?>.4-</span>
                                        </li>
                                        <?php $day_4th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 4); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_4th}.4"); ?>">
                                            <?php esc_html_e($day_4th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_4th); ?>.4-</span>
                                        </li>
                                        <?php $day_5th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 5); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_5th}.4"); ?>">
                                            <?php esc_html_e($day_5th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_5th); ?>.4-</span>
                                        </li>
                                        <?php $day_6th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 6); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_6th}.4"); ?>">
                                            <?php esc_html_e($day_6th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_6th); ?>.4-</span>
                                        </li>
                                        <?php $day_7th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 7); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_7th}.4"); ?>">
                                            <?php esc_html_e($day_7th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_7th); ?>.4-</span>
                                        </li>
                                    </ul>
                                </ul>
                                <ul>
                                    <li>
                                        <?php esc_html_e('Last', 'mec'); ?>
                                    </li>
                                    <ul>
                                        <?php $day_1th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 1); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_1th}.l"); ?>">
                                            <?php esc_html_e($day_1th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_1th); ?>.l-</span>
                                        </li>
                                        <?php $day_2th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 2); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_2th}.l"); ?>">
                                            <?php esc_html_e($day_2th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_2th); ?>.l-</span>
                                        </li>
                                        <?php $day_3th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 3); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_3th}.l"); ?>">
                                            <?php esc_html_e($day_3th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_3th); ?>.l-</span>
                                        </li>
                                        <?php $day_4th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 4); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_4th}.l"); ?>">
                                            <?php esc_html_e($day_4th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_4th); ?>.l-</span>
                                        </li>
                                        <?php $day_5th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 5); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_5th}.l"); ?>">
                                            <?php esc_html_e($day_5th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_5th); ?>.l-</span>
                                        </li>
                                        <?php $day_6th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 6); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_6th}.l"); ?>">
                                            <?php esc_html_e($day_6th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_6th); ?>.l-</span>
                                        </li>
                                        <?php $day_7th = \MEC\Base::get_main()->advanced_repeating_sort_day(\MEC\Base::get_main()->get_first_day_of_week(), 7); ?>
                                        <li class="<?php \MEC\Base::get_main()->mec_active($advanced_days, "{$day_7th}.l"); ?>">
                                            <?php esc_html_e($day_7th, 'mec'); ?>
                                            <span class="key"><?php echo esc_attr($day_7th); ?>.l-</span>
                                        </li>
                                    </ul>
                                </ul>
                                <input class="mec-col-2" type="hidden" name="mec[date][repeat][advanced]"
                                 id="mec_date_repeat_advanced"  value="<?php echo esc_attr($advanced_str); ?>" />
                            </div>
                        </div>
                        <div id="mec_end_wrapper">
                            <div class="mec-form-row">
                                <label for="mec_repeat_ends_never"><h5 class="mec-title"><?php esc_html_e('Ends Repeat', 'mec'); ?></h5></label>
                            </div>
                            <div class="mec-form-row">
                                <input <?php if($mec_repeat_end == 'never') echo 'checked="checked"'; ?> type="radio" value="never" name="mec[date][repeat][end]" id="mec_repeat_ends_never" />
                                <label for="mec_repeat_ends_never"><?php esc_html_e('Never', 'mec'); ?></label>
                            </div>
                            <div class="mec-form-row">
                                <div class="mec-col-3">
                                    <input <?php if($mec_repeat_end == 'date') echo 'checked="checked"'; ?> type="radio" value="date" name="mec[date][repeat][end]" id="mec_repeat_ends_date" />
                                    <label for="mec_repeat_ends_date"><?php esc_html_e('On', 'mec'); ?></label>
                                </div>
                                <input class="mec-col-2" type="text" name="mec[date][repeat][end_at_date]" id="mec_date_repeat_end_at_date" autocomplete="off" value="<?php echo esc_attr( \MEC\Base::get_main()->standardize_format( $repeat_end_at_date, $datepicker_format ) ); ?>" />
                            </div>
                            <div class="mec-form-row">
                                <div class="mec-col-3">
                                    <input <?php if($mec_repeat_end == 'occurrences') echo 'checked="checked"'; ?> type="radio" value="occurrences" name="mec[date][repeat][end]" id="mec_repeat_ends_occurrences" />
                                    <label for="mec_repeat_ends_occurrences"><?php esc_html_e('After', 'mec'); ?></label>
                                </div>
                                <input class="mec-col-2" type="text" name="mec[date][repeat][end_at_occurrences]" id="mec_date_repeat_end_at_occurrences" autocomplete="off" placeholder="<?php esc_html_e('Occurrences times', 'mec'); ?>"  value="<?php echo esc_attr(($repeat_end_at_occurrences+1)); ?>" />
                                <span class="mec-tooltip">
                                    <div class="box">
                                        <h5 class="title"><?php esc_html_e('Occurrences times', 'mec'); ?></h5>
                                        <div class="content"><p><?php esc_attr_e('The event will finish after certain repeats. For example if you set it to 10, the event will finish after 10 repeats.', 'mec'); ?><a href="https://webnus.net/dox/modern-events-calendar/event-detailssingle-event-page/" target="_blank"><?php esc_html_e('Read More', 'mec'); ?></a></p></div>
                                    </div>
                                    <i title="" class="dashicons-before dashicons-editor-help"></i>
                                </span>
                            </div>
                            <div class="mec-form-row">
                                <input
                                    <?php
                                    if ($one_occurrence == '1') {
                                        echo 'checked="checked"';
                                    }
                                    ?>
                                        type="checkbox" name="mec[date][one_occurrence]" id="mec-one-occurrence" value="1"/><label
                                        for="mec-one-occurrence"><?php esc_html_e('Show only one occurrence of this event', 'mec'); ?></label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php
    }

    /**
     * Return countdown status html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function countdown_status( $post, $atts = array() ){

        $countdown_method = get_post_meta($post->ID, 'mec_countdown_method', true);
        if(trim($countdown_method) == '') {

            $countdown_method = 'global';
        }

        ?>
            <div id="mec-fes-countdown-status" class="mec-meta-box-fields">
                <h4><?php esc_html_e('Countdown Method', 'mec'); ?></h4>
                <div class="mec-form-row">
                    <div class="mec-col-4">
                        <select name="mec[countdown_method]" id="mec_countdown_method" title="<?php esc_attr_e('Countdown Method', 'mec'); ?>">
                            <option value="global" <?php if('global' == $countdown_method) echo 'selected="selected"'; ?>><?php esc_html_e('Inherit from global options', 'mec'); ?></option>
                            <option value="start" <?php if('start' == $countdown_method) echo 'selected="selected"'; ?>><?php esc_html_e('Count to Event Start', 'mec'); ?></option>
                            <option value="end" <?php if('end' == $countdown_method) echo 'selected="selected"'; ?>><?php esc_html_e('Count to Event End', 'mec'); ?></option>
                        </select>
                    </div>
                </div>
            </div>
        <?php
    }

    /**
     * Return visibility html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function visibility( $post, $atts = array() ){

        // Public Event
        $public = get_post_meta($post->ID, 'mec_public', true);
        if(trim($public) === '') {

            $public = 1;
        }
        ?>
            <div id="mec-fes-visibility" class="mec-meta-box-fields">
                <h4><?php esc_html_e('Visibility', 'mec'); ?></h4>
                <div class="mec-form-row">
                    <div class="mec-col-4">
                        <select name="mec[public]" id="mec_public" title="<?php esc_attr_e('Event Visibility', 'mec'); ?>">
                            <option value="1" <?php if('1' == $public) echo 'selected="selected"'; ?>><?php esc_html_e('Show on Shortcodes', 'mec'); ?></option>
                            <option value="0" <?php if('0' == $public) echo 'selected="selected"'; ?>><?php esc_html_e('Hide on Shortcodes', 'mec'); ?></option>
                        </select>
                    </div>
                </div>
            </div>
        <?php
    }

    /**
     * Return timezone html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function timezone( $post, $atts = array() ){

        $event_timezone = get_post_meta($post->ID, 'mec_timezone', true);
        if(trim($event_timezone) == '') {

            $event_timezone = 'global';
        }
        ?>
        <div id="mec-fes-timezone" class="mec-meta-box-fields">
            <h4><?php esc_html_e('Timezone', 'mec'); ?></h4>
            <div class="mec-form-row mec-timezone-event">
                <div class="mec-col-4">
                    <select name="mec[timezone]" id="mec_event_timezone">
                        <option value="global"><?php esc_html_e('Inherit from global options'); ?></option>
                        <?php echo \MEC_kses::form(\MEC\Base::get_main()->timezones($event_timezone)); ?>
                    </select>
                </div>

            </div>
        </div>
        <?php
    }

    /**
     * Return note html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function note( $post, $atts = array() ){

        if( !\MEC\Base::get_main()->is_note_visible(get_post_status($post->ID)) ){

            return;
        }

        $note = get_post_meta($post->ID, 'mec_note', true);
        ?>
            <div class="mec-meta-box-fields mec-fes-note" id="mec-event-note">
                <h4><?php esc_html_e('Note to reviewer', 'mec'); ?></h4>
                <div class="mec-form-row" id="mec_meta_box_event_note">
                    <textarea name="mec[note]"><?php echo esc_textarea($note); ?></textarea>
                </div>
            </div>

        <?php
    }

    /**
     * Return guest html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function guest( $post, $atts = array() ){

        $is_demo = $atts['is_demo'] ?? false;
        if( is_user_logged_in() && !$is_demo ){

            return;
        }

        $required = isset( $atts['required'] ) && $atts['required'] ? true : false;

        $guest_email = get_post_meta($post->ID, 'fes_guest_email', true);
        $guest_name = get_post_meta($post->ID, 'fes_guest_name', true);
        ?>
            <!-- Guest Email and Name -->
            <div class="mec-meta-box-fields mec-fes-user-data" id="mec-guest-email-link">
                <h4><?php esc_html_e('User Data', 'mec'); ?></h4>
                <div class="mec-form-row">
                    <label class="mec-col-2" for="mec_guest_email"><?php esc_html_e('Email', 'mec'); ?><span>*</span></label>
                    <input class="mec-col-7" type="email" required="required" name="mec[fes_guest_email]" id="mec_guest_email" value="<?php echo esc_attr($guest_email); ?>" placeholder="<?php esc_html_e('eg. yourname@gmail.com', 'mec'); ?>" />
                </div>
                <div class="mec-form-row">
                    <label class="mec-col-2" for="mec_guest_name"><?php esc_html_e('Name', 'mec'); ?><span>*</span></label>
                    <input class="mec-col-7" type="text" required="required" name="mec[fes_guest_name]" id="mec_guest_name" value="<?php echo esc_attr($guest_name); ?>" placeholder="<?php esc_html_e('eg. John Smith', 'mec'); ?>" />
                </div>
            </div>
        <?php
    }

    /**
     * Return event links html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function event_links( $post, $atts = array() ){

        $required = isset( $atts['required'] ) && $atts['required'] ? true : false;

        $read_more = get_post_meta($post->ID, 'mec_read_more', true);
        $more_info = get_post_meta($post->ID, 'mec_more_info', true);
        $more_info_title = get_post_meta($post->ID, 'mec_more_info_title', true);
        $more_info_target = get_post_meta($post->ID, 'mec_more_info_target', true);
        ?>
        <!-- Event Links Section -->
        <div class="mec-meta-box-fields mec-fes-event-links" id="mec-event-links">
            <h4><?php esc_html_e('Event Links', 'mec'); ?></h4>
            <div class="mec-form-row">
                <label class="mec-col-2" for="mec_read_more_link"><?php echo esc_html(\MEC\Base::get_main()->m('read_more_link', esc_html__('Event Link', 'mec'))); ?> <?php echo ($required ? '<span class="mec-required">*</span>' : ''); ?></label>
                <input class="mec-col-9" type="text" name="mec[read_more]" id="mec_read_more_link" value="<?php echo esc_attr($read_more); ?>" placeholder="<?php esc_html_e('eg. http://yoursite.com/your-event', 'mec'); ?>" <?php echo ($required ? 'required' : ''); ?> />
                <p class="description"><?php esc_html_e('If you fill it, it will replace the default event page link. Insert full link including http(s)://', 'mec'); ?></p>
            </div>
            <div class="mec-form-row">
                <label class="mec-col-2" for="mec_more_info_link"><?php echo esc_html(\MEC\Base::get_main()->m('more_info_link', esc_html__('More Info', 'mec'))); ?> <?php echo $required ? '<span class="mec-required">*</span>' : ''; ?></label>
                <input class="mec-col-5" type="text" name="mec[more_info]" id="mec_more_info_link" value="<?php echo esc_attr($more_info); ?>" placeholder="<?php esc_html_e('eg. http://yoursite.com/your-event', 'mec'); ?>" <?php echo ( $required ? 'required' : ''); ?> />
                <input class="mec-col-2" type="text" name="mec[more_info_title]" id="mec_more_info_title" value="<?php echo esc_attr($more_info_title); ?>" placeholder="<?php esc_html_e('More Information', 'mec'); ?>" />
                <select class="mec-col-2" name="mec[more_info_target]" id="mec_more_info_target">
                    <option value="_self" <?php echo ($more_info_target == '_self' ? 'selected="selected"' : ''); ?>><?php esc_html_e('Current Window', 'mec'); ?></option>
                    <option value="_blank" <?php echo ($more_info_target == '_blank' ? 'selected="selected"' : ''); ?>><?php esc_html_e('New Window', 'mec'); ?></option>
                </select>
                <p class="description"><?php esc_html_e('If you fill it, it will be shown in event details page as an optional link. Insert full link including http(s)://', 'mec'); ?></p>
            </div>
        </div>

        <?php
    }

    /**
     * Return cost html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function cost( $post, $atts = array() ){

        $required = isset( $atts['required'] ) && $atts['required'] ? true : false;

        $settings = \MEC\Settings\Settings::getInstance()->get_settings();

        $cost = get_post_meta($post->ID, 'mec_cost', true);
        $cost_type = ((isset($settings['single_cost_type']) and trim($settings['single_cost_type'])) ? $settings['single_cost_type'] : 'numeric');

        $cost_auto_calculate = get_post_meta($post->ID, 'mec_cost_auto_calculate', true);

        $currency = get_post_meta($post->ID, 'mec_currency', true);
        if(!is_array($currency)) $currency = array();

        $currency_per_event = ((isset($settings['currency_per_event']) and trim($settings['currency_per_event'])) ? $settings['currency_per_event'] : 0);

        $currencies = \MEC\Base::get_main()->get_currencies();
        $current_currency = (isset($currency['currency']) ? $currency['currency'] : (isset($settings['currency']) ? $settings['currency'] : NULL));
        ?>
            <!-- Event Cost Section -->
            <div class="mec-meta-box-fields mec-fes-cost" id="mec-event-cost">
                <h4><?php echo esc_html(\MEC\Base::get_main()->m('event_cost', esc_html__('Event Cost', 'mec'))); ?> <?php echo $required ? '<span class="mec-required">*</span>' : ''; ?></h4>
                <div id="mec_meta_box_cost_form" class="<?php echo ($cost_auto_calculate ? 'mec-util-hidden' : ''); ?>">
                    <div class="mec-form-row">
                        <input type="<?php echo ($cost_type === 'alphabetic' ? 'text' : 'number'); ?>" <?php echo ($cost_type === 'numeric' ? 'min="0" step="any"' : ''); ?> class="mec-col-3" name="mec[cost]" id="mec_cost" value="<?php echo esc_attr($cost); ?>" placeholder="<?php esc_html_e('Cost', 'mec'); ?>" <?php echo ($required ? 'required' : ''); ?> />
                    </div>
                </div>

                <div class="mec-form-row">
                    <div class="mec-col-12">
                        <label for="mec_cost_auto_calculate">
                            <input type="hidden" name="mec[cost_auto_calculate]" value="0" />
                            <input type="checkbox" name="mec[cost_auto_calculate]" id="mec_cost_auto_calculate" <?php echo ($cost_auto_calculate == 1) ? 'checked="checked"' : ''; ?> value="1" onchange="jQuery('#mec_meta_box_cost_form').toggleClass('mec-util-hidden');">
                            <?php esc_html_e('Show the minimum price based on tickets', 'mec'); ?>
                        </label>
                    </div>
                </div>

                <?php if($currency_per_event): ?>
                <h4><?php echo esc_html__('Currency Options', 'mec'); ?></h4>
                <div class="mec-form-row">
                    <label class="mec-col-2" for="mec_currency_currency"><?php esc_html_e('Currency', 'mec'); ?></label>
                    <div class="mec-col-4">
                        <select name="mec[currency][currency]" id="mec_currency_currency">
                            <?php foreach($currencies as $c=>$currency_name): ?>
                                <option value="<?php echo esc_attr($c); ?>" <?php echo (($current_currency == $c) ? 'selected="selected"' : ''); ?>><?php echo esc_html($currency_name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="mec-form-row">
                    <label class="mec-col-2" for="mec_currency_currency_symptom"><?php esc_html_e('Currency Sign', 'mec'); ?></label>
                    <div class="mec-col-4">
                        <input type="text" name="mec[currency][currency_symptom]" id="mec_currency_currency_symptom" value="<?php echo (isset($currency['currency_symptom']) ? esc_attr($currency['currency_symptom']) : ''); ?>" />
                        <span class="mec-tooltip">
                            <div class="box left">
                                <h5 class="title"><?php esc_html_e('Currency Sign', 'mec'); ?></h5>
                                <div class="content"><p><?php esc_attr_e("Default value will be \"currency\" if you leave it empty.", 'mec'); ?><a href="https://webnus.net/dox/modern-events-calendar/currency-options/" target="_blank"><?php esc_html_e('Read More', 'mec'); ?></a></p></div>
                            </div>
                            <i title="" class="dashicons-before dashicons-editor-help"></i>
                        </span>
                    </div>
                </div>
                <div class="mec-form-row">
                    <label class="mec-col-2" for="mec_currency_currency_sign"><?php esc_html_e('Currency Position', 'mec'); ?></label>
                    <div class="mec-col-4">
                        <select name="mec[currency][currency_sign]" id="mec_currency_currency_sign">
                            <option value="before" <?php echo ((isset($currency['currency_sign']) and $currency['currency_sign'] == 'before') ? 'selected="selected"' : ''); ?>><?php esc_html_e('$10 (Before)', 'mec'); ?></option>
                            <option value="before_space" <?php echo ((isset($currency['currency_sign']) and $currency['currency_sign'] == 'before_space') ? 'selected="selected"' : ''); ?>><?php esc_html_e('$ 10 (Before with Space)', 'mec'); ?></option>
                            <option value="after" <?php echo ((isset($currency['currency_sign']) and $currency['currency_sign'] == 'after') ? 'selected="selected"' : ''); ?>><?php esc_html_e('10$ (After)', 'mec'); ?></option>
                            <option value="after_space" <?php echo ((isset($currency['currency_sign']) and $currency['currency_sign'] == 'after_space') ? 'selected="selected"' : ''); ?>><?php esc_html_e('10 $ (After with Space)', 'mec'); ?></option>
                        </select>
                    </div>
                </div>
                <div class="mec-form-row">
                    <label class="mec-col-2" for="mec_currency_thousand_separator"><?php esc_html_e('Thousand Separator', 'mec'); ?></label>
                    <div class="mec-col-4">
                        <input type="text" name="mec[currency][thousand_separator]" id="mec_currency_thousand_separator" value="<?php echo (isset($currency['thousand_separator']) ? esc_attr($currency['thousand_separator']) : ','); ?>" />
                    </div>
                </div>
                <div class="mec-form-row">
                    <label class="mec-col-2" for="mec_currency_decimal_separator"><?php esc_html_e('Decimal Separator', 'mec'); ?></label>
                    <div class="mec-col-4">
                        <input type="text" name="mec[currency][decimal_separator]" id="mec_currency_decimal_separator" value="<?php echo (isset($currency['decimal_separator']) ? esc_attr($currency['decimal_separator']) : '.'); ?>" />
                    </div>
                </div>
                <div class="mec-form-row">
                    <div class="mec-col-12">
                        <label for="mec_currency_decimal_separator_status">
                            <input type="hidden" name="mec[currency][decimal_separator_status]" value="1" />
                            <input type="checkbox" name="mec[currency][decimal_separator_status]" id="mec_currency_decimal_separator_status" <?php echo ((isset($currency['decimal_separator_status']) and $currency['decimal_separator_status'] == '0') ? 'checked="checked"' : ''); ?> value="0" />
                            <?php esc_html_e('No decimal', 'mec'); ?>
                        </label>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        <?php
    }

    /**
     * Return thumbnail html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function thumbnail( $post, $atts = array() ){

        $required = isset( $atts['required'] ) && $atts['required'] ? true : false;

        $attachment_id = get_post_thumbnail_id($post->ID);
        $featured_image = wp_get_attachment_image_src($attachment_id, 'large');
        if(isset($featured_image[0])) {

            $featured_image = $featured_image[0];
        }

        $featured_image_caption = $atts['featured_image_caption'] ?? false;
        ?>
        <!-- Event Featured Image Section -->
        <div class="mec-meta-box-fields mec-fes-featured-image" id="mec-featured-image">
            <h4><?php esc_html_e('Featured Image', 'mec'); ?> <?php echo ( $required ? '<span class="mec-required">*</span>' : ''); ?></h4>
            <div class="mec-form-row">
                <span id="mec_fes_thumbnail_img"><?php echo (trim($featured_image) ? '<img src="'.esc_attr($featured_image).'" />' : ''); ?></span>
                <input type="hidden" id="mec_fes_thumbnail" name="mec[featured_image]" value="<?php if(isset($attachment_id) and intval($attachment_id)) the_guid($attachment_id); ?>" />
                <input type="file" id="mec_featured_image_file" onchange="mec_fes_upload_featured_image();" />
                <span id="mec_fes_remove_image_button" class="<?php echo (trim($featured_image) ? '' : 'mec-util-hidden'); ?>"><?php esc_html_e('Remove Image', 'mec'); ?></span>

                <div class="mec-error mec-util-hidden" id="mec_fes_thumbnail_error"></div>
            </div>

            <?php if( $featured_image_caption ): ?>
            <div class="mec-form-row">
                <input type="text" id="mec_fes_thumbnail_caption" name="mec[featured_image_caption]" value="<?php if(isset($attachment_id) and intval($attachment_id)) echo wp_get_attachment_caption($attachment_id); ?>" />
            </div>
            <?php endif; ?>
        </div>

        <?php
    }

    /**
     * Return categories html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function categories( $post, $atts = array() ){

        $required = isset( $atts['required'] ) && $atts['required'] ? true : false;

        ?>
        <div class="mec-meta-box-fields mec-fes-category" id="mec-categories">
            <h4><?php echo esc_html(\MEC\Base::get_main()->m('taxonomy_categories', esc_html__('Categories', 'mec'))); ?> <?php echo ( $required ? '<span class="mec-required">*</span>' : ''); ?></h4>
            <div class="mec-form-row">
                <?php
                    wp_list_categories(array(
                        'taxonomy' => 'mec_category',
                        'hide_empty' => false,
                        'title_li' => '',
                        'walker' => new \FES_Custom_Walker($post->ID),
                    ));
                ?>
            </div>
        </div>

        <?php
    }

    /**
     * Return labels html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function labels( $post, $atts = array() ){

        $required = isset( $atts['required'] ) && $atts['required'] ? true : false;

        $post_labels = get_the_terms($post->ID, 'mec_label');

        $labels = array();
        if($post_labels) {

            foreach($post_labels as $post_label){

                $labels[] = $post_label->term_id;
            }
        }

        $label_terms = get_terms(
            array(
                'taxonomy'=>'mec_label',
                'hide_empty'=>false
            )
        );
        ?>
            <!-- Event Label Section -->
            <?php if(count($label_terms)): ?>
                <div class="mec-meta-box-fields mec-fes-labels" id="mec-labels">
                    <h4><?php echo esc_html(\MEC\Base::get_main()->m('taxonomy_labels', esc_html__('Labels', 'mec'))); ?> <?php echo ($required ? '<span class="mec-required">*</span>' : ''); ?></h4>
                    <div class="mec-form-row">
                        <?php foreach($label_terms as $label_term): ?>
                        <label for="mec_fes_labels<?php echo esc_attr($label_term->term_id); ?>">
                            <input type="checkbox" name="mec[labels][<?php echo esc_attr($label_term->term_id); ?>]" id="mec_fes_labels<?php echo esc_attr($label_term->term_id); ?>" value="1" <?php echo (in_array($label_term->term_id, $labels) ? 'checked="checked"' : ''); ?> />
                            <?php do_action('mec_label_to_checkbox_frontend', $label_term, $labels) ?>
                            <?php echo esc_html($label_term->name); ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

        <?php
    }

    /**
     * Return color html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function color( $post, $atts = array() ){

        $color = get_post_meta($post->ID, 'mec_color', true);
        $available_colors = \MEC\Base::get_main()->get_available_colors();

        if(!trim($color)) {

            $color = $available_colors[0];
        }
        ?>

        <!-- Event Color Section -->
        <?php if(count($available_colors)): ?>
            <div class="mec-meta-box-fields mec-fes-color" id="mec-event-color">
                <h4><?php esc_html_e('Event Color', 'mec'); ?></h4>
                <div class="mec-form-row">
                    <div class="mec-form-row mec-available-color-row">
                        <input type="hidden" id="mec_event_color" name="mec[color]" value="#<?php echo esc_attr($color); ?>" />
                        <?php foreach($available_colors as $available_color): ?>
                        <span class="mec-color <?php echo ($available_color == $color ? 'color-selected' : ''); ?>" onclick="mec_set_event_color('<?php echo esc_attr($available_color); ?>');" style="background-color: #<?php echo esc_attr($available_color); ?>"></span>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php
    }

    /**
     * Return tags html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function tags( $post, $atts = array() ){

        $post_tags = wp_get_post_terms($post->ID, apply_filters('mec_taxonomy_tag', ''));

        $tags = '';
        foreach($post_tags as $post_tag) {

            $tags .= $post_tag->name.',';
        }
        ?>
            <!-- Event Tags Section -->
            <div class="mec-meta-box-fields mec-fes-tags" id="mec-tags">
                <h4><?php esc_html_e('Tags', 'mec'); ?></h4>
                <div class="mec-form-row">
                    <textarea name="mec[tags]" id="mec_fes_tags" placeholder="<?php esc_attr_e('Insert your desired tags, comma separated.', 'mec'); ?>"><?php echo (trim($tags) ? trim($tags, ', ') : ''); ?></textarea>
                </div>
            </div>

        <?php
    }

    /**
     * Return speakers html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function speakers( $post, $atts = array() ){

        $post_speakers = get_the_terms($post->ID, 'mec_speaker');

        $speakers = array();
        if($post_speakers) foreach($post_speakers as $post_speaker){

            if(!isset($post_speaker->term_id)) continue;
            $speakers[] = $post_speaker->term_id;
        }

        $speaker_terms = get_terms(array(
            'taxonomy'=>'mec_speaker',
            'hide_empty'=>false
        ));
        ?>
        <!-- Event Speakers Section -->
        <div class="mec-meta-box-fields mec-fes-speakers" id="mec-speakers">
            <h4><?php echo esc_html(\MEC\Base::get_main()->m('taxonomy_speakers', esc_html__('Speakers', 'mec'))); ?></h4>
            <div class="mec-form-row">
                <input type="text" name="mec[speakers][datas][names]" id="mec_speaker_input_names" placeholder="<?php esc_html_e('Speaker Name', 'mec'); ?>" class="" />
                <p><?php esc_html_e('Insert name of one speaker: Chris Taylor', 'mec'); ?></p>
                <button class="button" type="button" id="mec_add_speaker_button"><?php esc_html_e('Add', 'mec'); ?></button>
            </div>
            <div class="mec-form-row" id="mec-fes-speakers-list">
            <?php if(count($speaker_terms)): ?>
                <?php foreach($speaker_terms as $speaker_term): ?>
                    <label for="mec_fes_speakers<?php echo esc_attr($speaker_term->term_id); ?>">
                        <input type="checkbox" name="mec[speakers][<?php echo esc_attr($speaker_term->term_id); ?>]" id="mec_fes_speakers<?php echo esc_attr($speaker_term->term_id); ?>" value="1" <?php echo (in_array($speaker_term->term_id, $speakers) ? 'checked="checked"' : ''); ?> />
                        <?php echo esc_html($speaker_term->name); ?>
                    </label>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <?php
    }

    /**
     * Return sponsors html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function sponsors( $post, $atts = array() ){

        $post_sponsors = get_the_terms($post->ID, 'mec_sponsor');
        if( is_wp_error( $post_sponsors ) ){

            error_log( print_r($post_sponsors) );
            return;
        }

        $sponsors = array();
        if( is_array( $post_sponsors ) ) {
            foreach($post_sponsors as $post_sponsor){

                if(!isset($post_sponsor->term_id)) continue;

                $sponsors[] = $post_sponsor->term_id;
            }
        }

        $sponsor_terms = get_terms(array(
            'taxonomy'=>'mec_sponsor',
            'hide_empty'=>false
        ));

        ?>
        <!-- Event Sponsors Section -->
        <div class="mec-meta-box-fields mec-fes-sponsors" id="mec-sponsors">
            <h4><?php echo esc_html(\MEC\Base::get_main()->m('taxonomy_sponsors', esc_html__('Sponsors', 'mec'))); ?></h4>
            <div class="mec-form-row" id="mec-fes-sponsors-list">
                <?php if(count($sponsor_terms)): ?>
                    <?php foreach($sponsor_terms as $sponsor_term): ?>
                        <label for="mec_fes_sponsors<?php echo esc_attr($sponsor_term->term_id); ?>">
                            <input type="checkbox" name="mec[sponsors][<?php echo esc_attr($sponsor_term->term_id); ?>]" id="mec_fes_sponsors<?php echo esc_attr($sponsor_term->term_id); ?>" value="1" <?php echo (in_array($sponsor_term->term_id, $sponsors) ? 'checked="checked"' : ''); ?> />
                            <?php echo esc_html($sponsor_term->name); ?>
                        </label>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <?php
    }

    /**
     * Return agreement html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function agreement( $post, $atts = array() ){

        $agreement_page = $atts['agreement_page'] ?? false;
        $checked = $atts['checked'] ?? false;

        ?>
        <div id="mec-fes-agreement">
            <div class="mec-form-row">
                <!-- Agreement Section -->
                <label>
                    <input type="hidden" name="mec[agreement]" value="0">
                    <input type="checkbox" name="mec[agreement]" required value="1" <?php echo $checked ? 'checked="checked"' : ''; ?>>

                    <?php if( $agreement_page ): ?>
                    <span><?php echo sprintf(esc_html__('I accept the %s in order to submit an event.', 'mec'), '<a href="'.get_permalink( $agreement_page ).'" target="_blank">'.esc_html__('Privacy Policy', 'mec').'</a>'); ?> <span class="mec-required">*</span></span>
                    <?php else: ?>
                    <span><?php esc_html_e('I accept the Privacy Policy in order to submit an event.', 'mec'); ?> <span class="mec-required">*</span></span>
                    <?php endif; ?>
                </label>
            </div>
        </div>
        <?php
    }

    /**
     * Return event data html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function event_data( $post, $atts = array() ){

        $fields = \MEC\Base::get_main()->getEventFields();
        $fields->form(array(
            'id' => 'mec-event-data',
            'class' => 'mec-meta-box-fields mec-event-tab-content mec-fes-event-fields',
            'post' => $post,
            'data' => get_post_meta($post->ID, 'mec_fields', true),
            'name_prefix' => 'mec',
            'id_prefix' => 'mec_event_fields_',
            'mandatory_status' => true,
        ));
    }

    /**
     * Return hourly schedules html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function hourly_schedule( $post, $atts = array() ){

        $settings = \MEC\Settings\Settings::getInstance()->get_settings();

        $meta_hourly_schedules = get_post_meta($post->ID, 'mec_hourly_schedules', true);
        if(is_array($meta_hourly_schedules) and count($meta_hourly_schedules))
        {
            $first_key = key($meta_hourly_schedules);

            $hourly_schedules = array();
            if(!isset($meta_hourly_schedules[$first_key]['schedules']))
            {
                $hourly_schedules[] = array(
                    'title' => esc_html__('Day 1', 'mec'),
                    'schedules' => $meta_hourly_schedules,
                );
            }
            else $hourly_schedules = $meta_hourly_schedules;
        }
        else $hourly_schedules = array();

        // Status of Speakers Feature
        $speakers_status = (!isset($settings['speakers_status']) or (isset($settings['speakers_status']) and !$settings['speakers_status'])) ? false : true;
        $speakers = get_terms('mec_speaker', array(
            'orderby' => 'name',
            'order' => 'ASC',
            'hide_empty' => '0',
        ));

        $hourly_schedule = \MEC\Base::get_main()->getHourlySchedule();
        $hourly_schedule->form(array(
            'hourly_schedules' => $hourly_schedules,
            'speakers_status' => $speakers_status,
            'speakers' => $speakers,
        ));
    }

    /**
     * Return info html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function info( $post, $atts = array() ){

        $imported_from_google = get_post_meta( $post->ID, 'mec_imported_from_google', true );
        if( $imported_from_google ): ?>
            <p class="info-msg"><?php esc_html_e("This event is imported from Google calendar so if you modify it would overwrite in the next import from Google.", 'mec'); ?></p>
        <?php endif;
    }

    /**
     * Return actions html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function actions( $post, $atts = array() ){


        if( !is_user_logged_in() ){

            return;
        }

        $url = $atts['url'] ?? '';

        do_action('mec_fes_form_top_actions');

        ?>
        <a class="mec-fes-form-back-to" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html__('Go back to events list', 'mec'); ?></a>

        <?php $status = \MEC\Base::get_main()->get_event_label_status(get_post_status($post->ID)); ?>
        <?php if(trim($status['label']) != "Empty"): ?>
            <span class="post-status <?php echo esc_attr($status['status_class']); ?>"><?php echo esc_html($status['label']);  ?></span>
        <?php endif;

    }

    /**
     * Return recaptcha html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function recaptcha( $post, $atts = array() ){

        $google_recaptcha_sitekey = \MEC\Settings\Settings::getInstance()->get_settings('google_recaptcha_sitekey');
        if( \MEC\Base::get_main()->get_recaptcha_status('fes') ): ?>
            <div class="mec-form-row mec-google-recaptcha"><div class="g-recaptcha" data-sitekey="<?php echo esc_attr( $google_recaptcha_sitekey ); ?>"></div></div>
        <?php endif;
    }

    /**
     * Return submit button html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function submit_button( $post, $atts = array() ){

        ?>
        <button class="mec-fes-sub-button" type="submit"><?php esc_html_e('Submit Event', 'mec'); ?></button>
        <div class="mec-util-hidden">
            <input type="hidden" name="mec[post_id]" value="<?php echo esc_attr($post->ID); ?>" id="mec_fes_post_id" class="mec-fes-post-id" />
            <input type="hidden" name="action" value="mec_fes_form" />
            <?php wp_nonce_field('mec_fes_form'); ?>
            <?php wp_nonce_field('mec_event_data', 'mec_event_nonce'); ?>
        </div>

        <?php
    }

    /**
     * Return virtual html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function virtual( $post, $atts = array() ){

        ?>
        <!-- Virtual Section -->
        <?php

        if($post->ID != -1 && $post == "") {

            $post = get_post_meta($post->ID, 'meta_box_virtual', true);
        }

        do_action('mec_virtual_event_form', $post);
    }

    /**
     * Return zoom html field
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function zoom( $post, $atts = array() ){

        ?>
        <!-- Zoom Event Section -->
        <?php

        if($post->ID != -1 && $post == "") {

            $post = get_post_meta($post->ID, 'meta_box_virtual', true);
        }

        do_action('mec_zoom_event_form', $post);
    }

    /**
     * Return other html fields
     *
     * @param \WP_Post $post
     * @param array $atts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function other_fields( $post, $atts = array() ){

        do_action('mec_fes_metabox_details', $post);
    }

    /**
     * Register style and scripts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function register_style_and_scripts(){

        wp_register_script( 'mec-fes-form-builder', plugin_dir_url( __FILE__ ) . 'scripts.js', array( 'jquery' ), MEC_VERSION );
    }

    /**
     * Enqueue style and scripts
     *
     * @since 1.0.0
     *
     * @return void
     */
    public static function enqueue(){

        static::register_style_and_scripts();

        wp_enqueue_script( 'mec-fes-form-builder' );
    }

    /**
     * Return html
     *
     * @return string
     */
    public function output( $event ){

        $html = '';

        return $html;
    }
}