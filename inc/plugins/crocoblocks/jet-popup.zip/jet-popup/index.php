<?php
/**
 * Silence is golden
 *
 * @package  jet-popup
 * @category Core
 * @author   Zemez
 * @license  GPL-2.0+
 */
