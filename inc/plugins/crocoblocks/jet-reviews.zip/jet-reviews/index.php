<?php
/**
 * Silence is golden
 *
 * @package  jet-reviews
 * @category Core
 * @author   Zemez
 * @license  GPL-2.0+
 */
