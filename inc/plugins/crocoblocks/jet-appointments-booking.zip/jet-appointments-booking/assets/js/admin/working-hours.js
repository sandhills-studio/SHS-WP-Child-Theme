(function () {

	"use strict";

	Vue.component( 'jet-apb-settings-working-hours', {
		template: '#jet-apb-settings-working-hours',
		props: {
			settings: {
				type: Object,
				default: {},
			}
		},
		components: {
			vuejsDatepicker: window.vuejsDatepicker,
		},
		data: function() {
			return {
				weekdays: window.JetAPBConfig.weekdays,
				timeSlots: window.JetAPBConfig.time_slots,
				workingHours: {},
				daysOff: {},
				isNewSlot: false,
				currentDay: null,
				currentFrom: null,
				currentTo: null,
				currentIndex: null,
				deleteSlotTrigger: null,
				editDayOff: false,
				dayOffName: null,
				dayOffDate: null,
				dayOffDateBkp: null,
				deleteDayOffTrigger: null,
			};
		},
		mounted: function() {

			if ( this.settings.working_hours ) {
				this.workingHours = this.settings.working_hours;
			}

			if ( this.settings.days_off ) {
				this.daysOff = this.settings.days_off;
			}

		},
		methods: {
			handleDayOffCancel: function() {
				this.editDayOff    = false;
				this.dayOffName    = null;
				this.dayOffDate    = null;
				this.dayOffDateBkp = null;
			},
			handleDayOffOk: function() {

				var newDate = this.formatDate( this.dayOffDate );

				this.$set( this.daysOff, newDate, {
					date: newDate,
					name: this.dayOffName,
				} );

				if ( this.dayOffDateBkp && this.dayOffDateBkp !== newDate ) {

					console.log( this.daysOff );
					console.log( this.dayOffDateBkp );

					this.$delete( this.daysOff, this.dayOffDateBkp );
				}

				this.$nextTick( function() {

					this.handleDayOffCancel();

					this.$emit( 'force-update', {
						key: 'days_off',
						value: this.daysOff,
					} );

				} );

			},
			formatDate: function( date ) {
				return moment( date ).format( 'MMMM D, YYYY' );
			},
			confirmDeleteDayOff: function( date ) {
				this.deleteDayOffTrigger = date;
			},
			deleteDayOff: function( date ) {

				this.$delete( this.daysOff, date );

				this.$nextTick( function() {

					this.$emit( 'force-update', {
						key: 'days_off',
						value: this.daysOff,
					} );

				} );
			},
			showEditDayOff: function( date ) {
				date = date || false;

				if ( date && this.daysOff[ date ] ) {
					this.dayOffName    = this.daysOff[ date ].name;
					this.dayOffDateBkp = this.daysOff[ date ].date;
					this.dayOffDate    = this.daysOff[ date ].date;
				}

				this.editDayOff = true;
			},
			newSlot: function( day ) {
				this.isNewSlot  = true;
				this.currentDay = day;
			},
			editSlot: function( day, slotIndex, daySlot ) {
				this.isNewSlot    = true;
				this.currentDay   = day;
				this.currentFrom  = daySlot.from;
				this.currentTo    = daySlot.to;
				this.currentIndex = slotIndex;
			},
			confirmDeleteSlot: function( day, slotIndex ) {
				this.deleteSlotTrigger = day + '-' + slotIndex;
			},
			deleteSlot: function( day, slotIndex ) {

				var dayData = this.workingHours[ day ] || [];

				this.deleteSlotTrigger = null;

				dayData.splice( slotIndex, 1 );
				this.$set( this.workingHours, day, dayData );

				this.$nextTick( function() {

					this.$emit( 'force-update', {
						key: 'working_hours',
						value: this.workingHours,
					} );

				} );

			},
			handleCancel: function() {
				this.currentDay   = null;
				this.currentFrom  = null;
				this.currentTo    = null;
				this.currentIndex = null;
			},
			handleOk: function() {

				var dayData = this.workingHours[ this.currentDay ] || [];

				if ( null === this.currentIndex ) {
					dayData.push( {
						from: this.currentFrom,
						to: this.currentTo,
					} );
				} else {
					dayData.splice( this.currentIndex, 1, {
						from: this.currentFrom,
						to: this.currentTo,
					} );
				}

				this.$set( this.workingHours, this.currentDay, dayData );

				this.$nextTick( function() {
					this.handleCancel();
					this.$emit( 'force-update', {
						key: 'working_hours',
						value: this.workingHours,
					} );

				} );

			},
		}
	} );

})();
