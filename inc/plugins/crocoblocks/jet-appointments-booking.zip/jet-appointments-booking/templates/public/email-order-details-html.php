<?php
/**
 * WooCommerce order details
 */
?>
<h2 style="color:#96588a;display:block;font-family:'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;font-size:18px;font-weight:bold;line-height:130%;margin:0 0 18px;text-align:left"><?php
	_e( 'Appointment Details', 'jet-appointments-booking' );
?></h2>
<ul>
	<li>
		<em><?php echo $service_label; ?>: <strong><?php echo $service; ?></strong></em>
	</li>
	<?php if ( $provider ) : ?>
	<li>
		<em><?php echo $provider_label; ?>: <strong><?php echo $provider; ?></strong></em>
	</li>
	<?php endif; ?>
	<li>
		<em><?php _e( 'Time', 'jet-appointments-booking' ); ?>: <strong><?php echo $slot; ?></strong></em>
	</li>
</ul>
