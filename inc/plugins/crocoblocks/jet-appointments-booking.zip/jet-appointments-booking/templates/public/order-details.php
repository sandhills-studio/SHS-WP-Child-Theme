<?php
/**
 * WooCommerce order details
 */
?>
<h2 class="woocommerce-order-details__title"><?php _e( 'Appointment Details', 'jet-appointments-booking' ); ?></h2>
<ul class="woocommerce-order-overview woocommerce-thankyou-order-details order_details">
	<li>
		<?php echo $service_label; ?>: <strong><?php echo $service; ?></strong>
	</li>
	<?php if ( $provider ) : ?>
	<li>
		<?php echo $provider_label; ?>: <strong><?php echo $provider; ?></strong>
	</li>
	<?php endif; ?>
	<li>
		<?php _e( 'Time', 'jet-appointments-booking' ); ?>: <strong><?php echo $slot; ?></strong>
	</li>
</ul>
