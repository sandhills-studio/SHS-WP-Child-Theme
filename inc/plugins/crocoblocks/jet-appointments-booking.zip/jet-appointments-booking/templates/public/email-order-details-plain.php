<?php
/**
 * WooCommerce order details
 */
?>
<?php _e( 'Appointment Details', 'jet-appointments-booking' ); ?>

- <?php echo $service_label; ?>: <strong><?php echo $service; ?>
<?php if ( $provider ) : ?>
- <?php echo $provider_label; ?>: <?php echo $provider; ?>
<?php endif; ?>
- <?php _e( 'Time', 'jet-appointments-booking' ); ?>: <?php echo $slot; ?>
