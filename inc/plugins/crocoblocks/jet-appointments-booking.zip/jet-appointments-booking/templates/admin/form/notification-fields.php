<?php
/**
 * Notifications fields template
 */
?>
<div class="jet-form-editor__row" v-if="'insert_appointment' === currentItem.type">
	<div class="jet-form-editor__row-label"><?php
		_e( 'Service ID field:', 'jet-engine' );
	?></div>
	<div class="jet-form-editor__row-control">
		<select v-model="currentItem.appointment_service_field">
			<option value="">--</option>
			<option v-for="field in availableFields" :value="field">{{ field }}</option>
			<option value="_manual_input"><?php _e( 'Manual Input', 'jet-appointments-booking' ); ?></option>
		</select>
		<input v-if="'_manual_input' === currentItem.appointment_service_field" type="text" v-model="currentItem.appointment_service_id" placeholder="<?php _e( 'Service ID', 'jet-appintments-booking' ); ?>" style="margin: 0 0 0px 5px;">
	</div>
</div>
<div class="jet-form-editor__row" v-if="'insert_appointment' === currentItem.type">
	<div class="jet-form-editor__row-label"><?php
		_e( 'Provider ID field:', 'jet-engine' );
	?></div>
	<div class="jet-form-editor__row-control">
		<select v-model="currentItem.appointment_provider_field">
			<option value="">--</option>
			<option v-for="field in availableFields" :value="field">{{ field }}</option>
			<option value="_manual_input"><?php _e( 'Manual Input', 'jet-appointments-booking' ); ?></option>
		</select>
		<input v-if="'_manual_input' === currentItem.appointment_provider_field" type="text" v-model="currentItem.appointment_provider_id" placeholder="<?php _e( 'Provider ID', 'jet-appintments-booking' ); ?>" style="margin: 0 0 0px 5px;">
	</div>
</div>
<div class="jet-form-editor__row" v-if="'insert_appointment' === currentItem.type">
	<div class="jet-form-editor__row-label"><?php
		_e( 'Appointment date field:', 'jet-engine' );
	?></div>
	<div class="jet-form-editor__row-control">
		<select v-model="currentItem.appointment_date_field">
			<option value="">--</option>
			<option v-for="field in availableFields" :value="field">{{ field }}</option>
		</select>
	</div>
</div>
<div class="jet-form-editor__row" v-if="'insert_appointment' === currentItem.type">
	<div class="jet-form-editor__row-label"><?php
		_e( 'User e-mail field:', 'jet-engine' );
	?></div>
	<div class="jet-form-editor__row-control">
		<select v-model="currentItem.appointment_email_field">
			<option value="">--</option>
			<option v-for="field in availableFields" :value="field">{{ field }}</option>
		</select>
	</div>
</div>
<?php if ( ! empty( $additional_db_columns ) ) : ?>
	<?php foreach ( $additional_db_columns as $column ) : ?>
		<div class="jet-form-editor__row" v-if="'insert_appointment' === currentItem.type">
			<div class="jet-form-editor__row-label"><?php
				echo '<b>' . $column . '</b>' . __( ' field:', 'jet-engine' );
			?></div>
			<div class="jet-form-editor__row-control">
				<select v-model="currentItem.appointment_custom_field_<?php echo $column; ?>">
					<option value="">--</option>
					<option v-for="field in availableFields" :value="field">{{ field }}</option>
				</select>
			</div>
		</div>
	<?php endforeach; ?>
<?php endif;

if ( $wc_integration ) {
	?>
	<div class="jet-form-editor__row" v-if="'insert_appointment' === currentItem.type">
		<div class="jet-form-editor__row-label">
			<?php _e( 'WooCommerce Price field:', 'jet-engine' ); ?>
			<div class="jet-form-editor__row-notice"><?php
				_e( 'Select field to get total price from. If not selected price will be get from post meta value.', 'jet-enegine' );
			?></div>
		</div>
		<div class="jet-form-editor__row-control">
			<select v-model="currentItem.appointment_wc_price">
				<option value="">--</option>
				<option v-for="field in availableFields" :value="field">{{ field }}</option>
			</select>
		</div>
	</div>
	<?php
}
