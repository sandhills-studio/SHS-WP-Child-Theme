<div class="jet-apb-working-hours">
	<div class="jet-apb-week-days">
		<div class="jet-apb-week-day" v-for="( label, day ) in weekdays" :key="day">
			<div class="jet-apb-week-day__head">
				<div class="jet-apb-week-day__head-name">{{ label }}</div>
				<div class="jet-apb-week-day__head-actions">
					<cx-vui-button
						size="mini"
						button-style="accent"
						@click="newSlot( day )"
					>
						<span slot="label">+ Add</span>
					</cx-vui-button>
				</div>
			</div>
			<div class="jet-apb-week-day__body">
				<div
					class="jet-apb-week-day__slot"
					v-for="( daySlot, slotIndex ) in workingHours[ day ]"
				>
					<div class="jet-apb-week-day__slot-name">
						{{ daySlot.from }}-{{ daySlot.to }}
					</div>
					<div class="jet-apb-week-day__slot-actions">
						<span
							class="dashicons dashicons-edit"
							@click="editSlot( day, slotIndex, daySlot )"
						></span>
						<div class="jet-apb-week-day__slot-delete" style="position:relative;">
							<span
								class="dashicons dashicons-trash"
								@click="confirmDeleteSlot( day, slotIndex )"
							></span>
							<div
								class="cx-vui-tooltip"
								v-if="deleteSlotTrigger === day + '-' + slotIndex"
							>
								<?php _e( 'Are you sure?', 'jet-appointments-booking' ); ?>
								<br> <span
									class="cx-vui-repeater-item__confrim-del"
									@click="deleteSlot( day, slotIndex, daySlot )"
								><?php
									_e( 'Yes', 'jet-appointments-booking' );
								?></span>
								/
								<span
									class="cx-vui-repeater-item__cancel-del"
									@click="deleteSlotTrigger = null"
								><?php
									_e( 'No', 'jet-appointments-booking' );
								?></span></div>
							</div>
						</div>
				</div>
			</div>
		</div>
	</div>
	<div class="jet-apb-days-off">
		<div class="jet-apb-days-off__heading">
			<h4 class="cx-vui-subtitle"><?php _e( 'Days Off', 'jet-appointments-booking' ); ?></h4>
			<cx-vui-button
				size="mini"
				button-style="accent"
				@click="showEditDayOff"
			>
				<span slot="label">+ New Day Off</span>
			</cx-vui-button>
		</div>
		<div class="jet-apb-days-off__body">
			<div
				class="jet-apb-days-off__slot"
				v-for="( dateData, date ) in daysOff"
			>
				<div class="jet-apb-days-off__slot-name">
					{{ dateData.date }} — {{ dateData.name }}
				</div>
				<div class="jet-apb-days-off__slot-actions">
					<span
						class="dashicons dashicons-edit"
						@click="showEditDayOff( date )"
					></span>
					<div class="jet-apb-days-off__slot-delete" style="position:relative;">
						<span
							class="dashicons dashicons-trash"
							@click="confirmDeleteDayOff( date )"
						></span>
						<div
							class="cx-vui-tooltip"
							v-if="deleteDayOffTrigger === date"
						>
							<?php _e( 'Are you sure?', 'jet-appointments-booking' ); ?>
							<br> <span
								class="cx-vui-repeater-item__confrim-del"
								@click="deleteDayOff( date )"
							><?php
								_e( 'Yes', 'jet-appointments-booking' );
							?></span>
							/
							<span
								class="cx-vui-repeater-item__cancel-del"
								@click="deleteDayOffTrigger = null"
							><?php
								_e( 'No', 'jet-appointments-booking' );
							?></span></div>
						</div>
					</div>
			</div>
		</div>
	</div>
	<cx-vui-popup
		v-model="isNewSlot"
		body-width="600px"
		ok-label="<?php _e( 'Save', 'jet-engine' ) ?>"
		cancel-label="<?php _e( 'Cancel', 'jet-engine' ) ?>"
		@on-cancel="handleCancel"
		@on-ok="handleOk"
	>
		<div class="cx-vui-subtitle" slot="title"><?php
			_e( 'Work Hours', 'jet-engine' );
		?></div>
		<cx-vui-select
			slot="content"
			label="<?php _e( 'From', 'jet-appointments-booking' ); ?>"
			description="<?php _e( 'Starts from time', 'jet-appointments-booking' ); ?>"
			size="fullwidth"
			:wrapper-css="[ 'equalwidth' ]"
			:options-list="timeSlots"
			v-model="currentFrom"
		></cx-vui-select>
		<cx-vui-select
			slot="content"
			label="<?php _e( 'To', 'jet-appointments-booking' ); ?>"
			description="<?php _e( 'Work to time', 'jet-appointments-booking' ); ?>"
			size="fullwidth"
			:wrapper-css="[ 'equalwidth' ]"
			:options-list="timeSlots"
			v-model="currentTo"
		></cx-vui-select>
	</cx-vui-popup>
	<cx-vui-popup
		v-model="editDayOff"
		body-width="600px"
		ok-label="<?php _e( 'Save', 'jet-engine' ) ?>"
		cancel-label="<?php _e( 'Cancel', 'jet-engine' ) ?>"
		@on-cancel="handleDayOffCancel"
		@on-ok="handleDayOffOk"
	>
		<div class="cx-vui-subtitle" slot="title"><?php
			_e( 'Day Off', 'jet-engine' );
		?></div>
		<cx-vui-input
			label="<?php _e( 'Day Off Name', 'jet-engine' ); ?>"
			description="<?php _e( 'Name of the current day off (eg. name of the holiday)', 'jet-engine' ); ?>"
			:wrapper-css="[ 'equalwidth' ]"
			size="fullwidth"
			v-model="dayOffName"
			slot="content"
		></cx-vui-input>
		<cx-vui-component-wrapper
			:wrapper-css="[ 'equalwidth' ]"
			label="<?php _e( 'Select Date', 'jet-engine' ); ?>"
			description="<?php _e( 'Pick a day off date', 'jet-engine' ); ?>"
			slot="content"
		>
			<vuejs-datepicker
				input-class="cx-vui-input size-fullwidth"
				:format="formatDate"
				v-model="dayOffDate"
			></vuejs-datepicker>
		</cx-vui-component-wrapper>
	</cx-vui-popup>
</div>