<div>
	<h3 class="cx-vui-subtitle"><?php _e( 'Appointments Booking Settings', 'jet-appointments-booking' ); ?></h3>
	<br>
	<div class="cx-vui-panel">
		<cx-vui-tabs
			:in-panel="false"
			value="general"
			layout="vertical"
		>
			<cx-vui-tabs-panel
				name="general"
				label="<?php _e( 'General', 'jet-appointments-booking' ); ?>"
				key="general"
			>
				<keep-alive>
					<jet-apb-settings-general
						:settings="settings"
						@force-update="onUpdateSettings( $event, true )"
					></jet-apb-settings-general>
				</keep-alive>
			</cx-vui-tabs-panel>
			<cx-vui-tabs-panel
				name="working-hours"
				label="<?php _e( 'Working Hours', 'jet-appointments-booking' ); ?>"
				key="working-hours"
			>
				<keep-alive>
					<div>
						<cx-vui-select
							style="max-width: calc( 47% - 20px );"
							label="<?php _e( 'Default time slot length', 'jet-appointments-booking' ); ?>"
							description="<?php _e( 'Select the default duration for each service time slot', 'jet-appointments-booking' ); ?>"
							:options-list="[
								{
									value: '',
									label: 'Not set...'
								},
								{
									value: 1800,
									label: '30 minutes'
								},
								{
									value: 3600,
									label: '1 hour'
								},
								{
									value: 5400,
									label: '1 hour 30 minutes'
								},
								{
									value: 7200,
									label: '2 hours'
								},
							]"
							:wrapper-css="[ 'equalwidth' ]"
							:size="'fullwidth'"
							:value="settings.default_slot"
							@input="onUpdateSettings( {
								key: 'default_slot',
								value: $event
							}, true )"
						></cx-vui-select>
						<jet-apb-settings-working-hours
							:settings="settings"
							@force-update="onUpdateSettings( $event, true )"
						></jet-apb-settings-working-hours>
					</div>
				</keep-alive>
			</cx-vui-tabs-panel>
			<cx-vui-tabs-panel
				name="labels"
				label="<?php _e( 'Labels', 'jet-appointments-booking' ); ?>"
				key="labels"
			>
				<keep-alive>
					<jet-apb-settings-labels
						:settings="settings"
						@force-update="onUpdateSettings( $event, true )"
					></jet-apb-settings-labels>
				</keep-alive>
			</cx-vui-tabs-panel>
			<cx-vui-tabs-panel
				name="advanced"
				label="<?php _e( 'Advanced', 'jet-appointments-booking' ); ?>"
				key="advanced"
			>
				<keep-alive>
					<jet-apb-settings-advanced
						:settings="settings"
						@force-update="onUpdateSettings( $event, true )"
					></jet-apb-settings-advanced>
				</keep-alive>
			</cx-vui-tabs-panel>
			<cx-vui-tabs-panel
				name="tools"
				label="<?php _e( 'Tools', 'jet-appointments-booking' ); ?>"
				key="tools"
			>
				<div class="cx-vui-component cx-vui-component--equalwidth">
					<div class="cx-vui-component__meta">
						<label class="cx-vui-component__label">Clear excluded dates cache</label>
						<div class="cx-vui-component__desc">Remove all dates from excluded dates table</div>
					</div>
					<div class="cx-vui-component__control">
						<cx-vui-button
							@click="clearExcludedDates"
							:loading="clearingExcluded"
						>
							<span slot="label"><?php _e( 'Clear', 'jet-appointments-booking' ); ?></span>
						</cx-vui-button>
					</div>
				</div>
			</cx-vui-tabs-panel>
		</cx-vui-tabs>
	</div>
</div>