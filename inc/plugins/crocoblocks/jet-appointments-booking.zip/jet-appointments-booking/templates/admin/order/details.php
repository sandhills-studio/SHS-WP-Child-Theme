<?php
/**
 * Admin order details
 */
?>
<hr>
<h3><?php _e( 'Appointment Details', 'jet-appointment-booking' ); ?></h3>
<p>
	<?php echo $service_label; ?>: <strong><?php echo $service; ?></strong><br>
	<?php if ( $provider ) : ?>
		<?php echo $provider_label; ?>: <strong><?php echo $provider; ?></strong><br>
	<?php endif; ?>
	<?php _e( 'Time', 'jet-appointments-booking' ); ?>: <strong><?php echo $slot; ?></strong>
</p>
