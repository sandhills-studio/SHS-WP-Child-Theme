<div class="wrap">
	<jet-apb-appointments-list v-if="isSet"></jet-apb-appointments-list>
	<div class="cx-vui-panel" v-else>
		<jet-apb-go-to-setup></jet-apb-go-to-setup>
	</div>
</div>