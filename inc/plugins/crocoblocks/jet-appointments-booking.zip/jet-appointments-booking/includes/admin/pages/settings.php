<?php
namespace JET_APB\Admin\Pages;

use JET_APB\Admin\Helpers\Page_Config;
use JET_APB\Plugin;
use JET_APB\Time_Slots;

/**
 * Base dashboard page
 */
class Settings extends Base {

	/**
	 * Page slug
	 * @return string
	 */
	public function slug() {
		return 'jet-apb-settings';
	}

	/**
	 * Page title
	 * @return string
	 */
	public function title() {
		return __( 'Settings', 'jet-appointments-booking' );
	}

	/**
	 * Is settings page
	 *
	 * @return boolean [description]
	 */
	public function is_settings_page() {
		return true;
	}

	/**
	 * Page render funciton
	 * @return void
	 */
	public function render() {
		echo '<div class="wrap"><div id="jet-apb-settings-page"></div></div>';
	}

	/**
	 * Return  page config object
	 *
	 * @return [type] [description]
	 */
	public function page_config() {
		return new Page_Config(
			$this->slug(),
			array(
				'settings'   => Plugin::instance()->settings->get_all(),
				'post_types' => \Jet_Engine_Tools::get_post_types_for_js( array(
					'value' => '',
					'label' => __( 'Select...', 'jet-engine' ),
				) ),
				'weekdays'   => array(
					'monday'    => __( 'Monday', 'jet-appointments-booking' ),
					'tuesday'   => __( 'Tuesday', 'jet-appointments-booking' ),
					'wednesday' => __( 'Wednesday', 'jet-appointments-booking' ),
					'thursday'  => __( 'Thursday', 'jet-appointments-booking' ),
					'friday'    => __( 'Friday', 'jet-appointments-booking' ),
					'saturday'  => __( 'Saturday', 'jet-appointments-booking' ),
					'sunday'    => __( 'Sunday', 'jet-appointments-booking' ),
				),
				'time_slots' => Time_Slots::prepare_slots_for_js(
					Time_Slots::generate_slots()
				),
			)
		);
	}

	/**
	 * Page specific assets
	 *
	 * @return [type] [description]
	 */
	public function assets() {

		$this->enqueue_script( 'momentjs', 'admin/lib/moment.min.js' );
		$this->enqueue_script( 'vuejs-datepicker', 'admin/lib/vuejs-datepicker.min.js' );
		$this->enqueue_script( $this->slug() . '-working-hours', 'admin/working-hours.js' );
		$this->enqueue_script( $this->slug(), 'admin/settings.js' );

		$this->enqueue_style( $this->slug() . '-working-hours', 'admin/working-hours.css' );

	}

	/**
	 * Page components templates
	 *
	 * @return [type] [description]
	 */
	public function vue_templates() {
		return array(
			'settings',
			'settings-general',
			'settings-advanced',
			'settings-labels',
			'settings-working-hours'
		);
	}

}
