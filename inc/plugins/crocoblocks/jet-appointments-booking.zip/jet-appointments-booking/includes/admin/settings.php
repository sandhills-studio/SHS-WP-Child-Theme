<?php
namespace JET_APB\Admin;

use JET_APB\Plugin;

/**
 * Settings manager
 */
class Settings {

	/**
	 * Default settings array
	 *
	 * @var array
	 */
	private $defaults = array(
		'is_set' => false,
		'services_cpt'  => false,
		'providers_cpt' => false,
		'working_hours' => array(
			'monday'    => array(),
			'tuesday'   => array(),
			'wednesday' => array(),
			'thursday'  => array(),
			'friday'    => array(),
			'saturday'  => array(),
			'sunday'    => array(),
		),
		'days_off' => false,
		'db_columns' => array(),
		'wc_integration' => false,
		'wc_product_id' => 0,
		'hide_setup' => false,
		'default_slot' => '',
		'check_by' => 'global',
		'manage_capacity' => false,
		'show_capacity_counter' => false,
		'use_custom_labels' => false,
		'slot_time_format' => 'H:i',
		'custom_labels' => array(
			'Sun' => 'Sun',
			'Mon' => 'Mon',
			'Tue' => 'Tue',
			'Wed' => 'Wed',
			'Thu' => 'Thu',
			'Fri' => 'Fri',
			'Sat' => 'Sat',
			'January' => 'January',
			'February' => 'February',
			'March' => 'March',
			'April' => 'April',
			'May' => 'May',
			'June' => 'June',
			'July' => 'July',
			'August' => 'August',
			'September' => 'September',
			'October' => 'October',
			'November' => 'November',
			'December' => 'December',
		),
	);

	/**
	 * Settings DB key
	 *
	 * @var string
	 */
	private $key = 'jet-apb-settings';

	/**
	 * Stored settings cache
	 *
	 * @var null
	 */
	public $settings = null;

	/**
	 * [__construct description]
	 * @param array $pages [description]
	 */
	public function __construct() {
		add_action( 'wp_ajax_jet_apb_save_settings', array( $this, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_jet_apb_clear_excluded', array( $this, 'reset_excluded_dates' ) );
	}

	/**
	 * Reset excluded dates data
	 *
	 * @return [type] [description]
	 */
	public function reset_excluded_dates() {

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array(
				'message' => 'Access denied',
			) );
		}

		Plugin::instance()->db->excluded_dates->clear();

	}

	/**
	 * Save settings by ajax request
	 *
	 * @return [type] [description]
	 */
	public function ajax_save_settings() {

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array(
				'message' => 'Access denied',
			) );
		}

		$settings = ! empty( $_REQUEST['settings'] ) ? $_REQUEST['settings'] : array();

		if ( empty( $settings ) ) {
			wp_send_json_error( array(
				'message' => 'Empty data',
			) );
		}

		foreach ( $settings as $setting => $value ) {

			if ( $this->setting_registered( $setting ) ) {

				switch ( $setting ) {

					case 'working_hours':
						$value = $this->sanitize_working_hours( $value );
						break;

					case 'days_off':

						if ( ! is_array( $value ) ) {
							$value = false;
						}

						break;

					case 'wc_integration':
					case 'hide_setup':
					case 'manage_capacity':
					case 'show_capacity_counter':
					case 'use_custom_labels':
						$value = filter_var( $value, FILTER_VALIDATE_BOOLEAN );
						break;

				}

				$this->update( $setting, $value, false );
			}
		}

		$this->write();

		wp_send_json_success( array(
			'message' => __( 'Settings saved!', 'jet-appointments-booking' ),
		) );

	}

	/**
	 * Sanitize updated working hours
	 *
	 * @param  [type] $value [description]
	 * @return [type]        [description]
	 */
	public function sanitize_working_hours( $input ) {

		$defaults  = $this->defaults['working_hours'];
		$sanitized = array();

		foreach ( $defaults as $key => $default_value ) {
			$sanitized[ $key ] = ! empty( $input[ $key ] ) ? $input[ $key ] : $default_value;
		}

		return $sanitized;
	}

	/**
	 * Return all settings and setup settings cache
	 *
	 * @return [type] [description]
	 */
	public function get_all() {

		if ( null === $this->settings ) {

			$this->settings = get_option( $this->key, array() );

			if ( ! is_array( $this->settings ) ) {
				$this->settings = $this->defaults;
			}

			if ( empty( $this->settings['custom_labels'] ) ) {
				$this->settings['custom_labels'] = $this->defaults['custom_labels'];
			}

		}

		return $this->settings;

	}

	/**
	 * Get setting by name
	 *
	 * @param  [type] $setting [description]
	 * @return [type]          [description]
	 */
	public function get( $setting ) {

		$settings = $this->get_all();

		if ( isset( $settings[ $setting ] ) ) {
			return $settings[ $setting ];
		} else {
			return isset( $this->defaults[ $setting ] ) ? $this->defaults[ $setting ] : null;
		}

	}

	/**
	 * Update setting in cahce and database
	 *
	 * @param  [type]  $setting [description]
	 * @param  boolean $write   [description]
	 * @return [type]           [description]
	 */
	public function update( $setting = null, $value = null, $write = true ) {

		$this->get_all();

		/**
		 * Modify options before write into DB
		 */
		do_action( 'jet-apb/settings/before-update', $this->settings, $setting, $value );

		$this->settings[ $setting ] = $value;

		if ( $write ) {
			$this->write();
		}

	}

	/**
	 * Write settings cache
	 * @return [type] [description]
	 */
	public function write() {

		/**
		 * Modify options before write into DB
		 */
		do_action( 'jet-apb/settings/before-write', $this );

		update_option( $this->key, $this->settings, false );
	}

	/**
	 * Check if passed settings is registered in defaults
	 *
	 * @return [type] [description]
	 */
	public function setting_registered( $setting = null ) {
		return ( $setting && isset( $this->defaults[ $setting ] ) );
	}

}
