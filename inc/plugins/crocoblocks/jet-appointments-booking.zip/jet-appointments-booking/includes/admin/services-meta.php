<?php
/**
 * Uses JetEngine meta component to process meta
 */
namespace JET_APB\Admin;

use JET_APB\Plugin;
use JET_APB\Time_Slots;

class Services_Meta {

	/**
	 * Class constructor
	 */
	public function __construct() {
		add_action( 'jet-engine/meta-boxes/register-instances', array( $this, 'register_meta_box' ) );
	}

	/**
	 * Regsiter services specific metabox on all services registration
	 *
	 * @param  [type] $meta_boxes_manager [description]
	 * @return [type]                     [description]
	 */
	public function register_meta_box( $meta_boxes_manager ) {

		$services_cpt = Plugin::instance()->settings->get( 'services_cpt' );

		if ( ! $services_cpt ) {
			return;
		}

		$object_name = $services_cpt . '_jet_apb';

		$meta_boxes_manager->register_custom_group(
			$object_name,
			__( 'Appointments Settings', 'jet-appointments-booking' )
		);

		$meta_fields = array(
			array(
				'type'             => 'select',
				'name'             => '_service_duration',
				'title'            => __( 'Duration', 'jet-appointments-booking' ),
				'default_val'      => Plugin::instance()->settings->get( 'default_slot' ),
				'options_callback' => array( $this, 'get_time_slots' ),
			),
			array(
				'type'             => 'select',
				'name'             => '_buffer_before',
				'title'            => __( 'Buffer Time Before Slot', 'jet-appointments-booking' ),
				'options_callback' => array( $this, 'get_buffer_time_slots' ),
			),
			array(
				'type'             => 'select',
				'name'             => '_buffer_after',
				'title'            => __( 'Buffer Time After Slot', 'jet-appointments-booking' ),
				'options_callback' => array( $this, 'get_buffer_time_slots' ),
			),
			array(
				'type'             => 'text',
				'name'             => '_app_price',
				'title'            => __( 'Price per slot', 'jet-appointments-booking' ),
			),
		);

		$manage_capacity = Plugin::instance()->settings->get( 'manage_capacity' );

		if ( $manage_capacity ) {
			$meta_fields[] = array(
				'type'        => 'text',
				'input_type'  => 'number',
				'default_val' => 1,
				'name'        => '_app_capacity',
				'title'       => __( 'Capacity', 'jet-appointments-booking' ),
			);
		}

		$meta_boxes_manager->register_metabox(
			$services_cpt,
			$meta_fields,
			__( 'Appointments Settings', 'jet-appointments-booking' ),
			$object_name
		);

	}

	/**
	 * Returns time slots
	 *
	 * @return [type] [description]
	 */
	public function get_time_slots() {

		return Time_Slots::prepare_slots_for_js(
			Time_Slots::generate_slots(
				array(
					'from'     => 30 * MINUTE_IN_SECONDS,
					'to'       => DAY_IN_SECONDS / 2,
					'interval' => 15 * MINUTE_IN_SECONDS,
					'format'   => 'U',
				)
			),
			'G\h i\m\i\n',
			true,
			true
		);

	}

	/**
	 * Returns time slots
	 *
	 * @return [type] [description]
	 */
	public function get_buffer_time_slots() {

		return Time_Slots::prepare_slots_for_js(
			Time_Slots::generate_slots(
				array(
					'to'       => DAY_IN_SECONDS / 2,
					'interval' => 15 * MINUTE_IN_SECONDS,
					'format'   => 'U',
				)
			),
			'G\h i\m\i\n',
			true,
			true
		);

	}

}
