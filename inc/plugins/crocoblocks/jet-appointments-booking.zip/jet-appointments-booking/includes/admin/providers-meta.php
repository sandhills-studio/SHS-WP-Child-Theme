<?php
/**
 * Uses JetEngine meta component to process meta
 */
namespace JET_APB\Admin;

use JET_APB\Plugin;
use JET_APB\Time_Slots;

class Providers_Meta {

	/**
	 * Class constructor
	 */
	public function __construct() {
		add_filter( 'jet-engine/relations/registered-relation', array( $this, 'register_providers_relation' ) );
	}

	/**
	 * Regsiter services specific metabox on all services registration
	 *
	 * @param  [type] $meta_boxes_manager [description]
	 * @return [type]                     [description]
	 */
	public function register_providers_relation( $relations ) {

		$services_cpt  = Plugin::instance()->settings->get( 'services_cpt' );
		$providers_cpt = Plugin::instance()->settings->get( 'providers_cpt' );

		if ( ! $services_cpt ) {
			return;
		}

		if ( empty( $relations ) ) {
			$relations = array();
		}

		$relations['item-0'] = array(
			'name'                => 'services to providers',
			'post_type_1'         => $services_cpt,
			'post_type_2'         => $providers_cpt,
			'type'                => 'many_to_many',
			'post_type_1_control' => 1,
			'post_type_2_control' => 1,
			'parent_relation'     => '',
			'id'                  => 'item-0',
		);

		return $relations;

	}

}
