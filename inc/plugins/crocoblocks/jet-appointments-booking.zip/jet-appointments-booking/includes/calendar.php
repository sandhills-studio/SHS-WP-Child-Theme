<?php
namespace JET_APB;

/**
 * Calendar related data
 */
class Calendar {

	/**
	 * Get date slots
	 *
	 * @return [type] [description]
	 */
	public function get_date_slots( $service = 0, $provider = 0, $date = 0, $time = 0 ) {

		if ( ! $service || ! $date ) {
			return false;
		}

		timer_start();

		$duration      = get_post_meta( $service, '_service_duration', true );
		$buffer_before = get_post_meta( $service, '_buffer_before', true );
		$buffer_after  = get_post_meta( $service, '_buffer_after', true );
		$working_hours = Plugin::instance()->settings->get( 'working_hours' );
		$weekday       = strtolower( date( 'l', $date ) );
		$day_schedule  = ! empty( $working_hours[ $weekday ] ) ? $working_hours[ $weekday ] : array();
		$slots         = array();

		Time_Slots::set_starting_point( $date );

		if ( 0 < $time ) {
			Time_Slots::set_timenow( $time );
		}

		if ( 1 < count( $day_schedule ) ) {

			usort( $day_schedule, function( $a, $b ) {

				$a_from = strtotime( $a['from'] );
				$b_from = strtotime( $b['from'] );

				if ( $a_from === $b_from ) {
					return 0;
				}

				return ( $a_from < $b_from ) ? -1 : 1;

			} );

		}

		foreach ( $day_schedule as $day_part ) {

			$slots = $slots + Time_Slots::generate_intervals( array(
				'from'          => $day_part['from'],
				'to'            => $day_part['to'],
				'duration'      => $duration,
				'buffer_before' => $buffer_before,
				'buffer_after'  => $buffer_after,
				'from_now'      => true,
			) );
		}

		$query_args = array(
			'date'    => $date,
			'status'  => Plugin::instance()->statuses->valid_statuses(),
		);

		if ( 'service' === Plugin::instance()->settings->get( 'check_by' ) ) {
			$query_args['service'] = $service;
		}

		if ( $provider ) {
			$query_args['provider'] = $provider;
		}

		$manage_capacity = Plugin::instance()->settings->get( 'manage_capacity' );
		$service_count   = 1;

		if ( $manage_capacity ) {
			$excluded      = Plugin::instance()->db->appointments->query_with_capacity( $query_args );
			$service_count = Plugin::instance()->tools->get_service_count( $service );
		} else {
			$excluded = Plugin::instance()->db->appointments->query( $query_args );
		}

		if ( ! empty( $excluded ) ) {
			foreach ( $excluded as $appointment ) {

				$excl_slot     = absint( $appointment['slot'] );
				$excl_slot_end = absint( $appointment['slot_end'] );
				$slot_count    = ! empty( $appointment['slot_count'] ) ? absint( $appointment['slot_count'] ) : 1;

				if ( ! $excl_slot ) {
					continue;
				}

				if ( $manage_capacity ) {

					if ( isset( $slots[ $excl_slot ] ) && $slot_count >= $service_count ) {
						unset( $slots[ $excl_slot ] );
					}

				} elseif ( isset( $slots[ $excl_slot ] ) ) {
					unset( $slots[ $excl_slot ] );
				}

				foreach ( $slots as $slot_start => $slot_data ) {

					if ( $slot_data['from'] <= $excl_slot && $excl_slot < $slot_data['to'] ) {

						if ( $manage_capacity && $slot_count >= $service_count ) {
							unset( $slots[ $slot_start ] );
						} elseif ( $manage_capacity ) {
							$slots[ $slot_start ]['slot_count'] = $slot_count;
						} elseif ( ! $manage_capacity ) {
							unset( $slots[ $slot_start ] );
						}

					} elseif ( $slot_data['from'] < $excl_slot_end && $excl_slot_end <= $slot_data['to'] ) {

						if ( $manage_capacity && $slot_count >= $service_count ) {
							unset( $slots[ $slot_start ] );
						} elseif ( $manage_capacity ) {
							$slots[ $slot_start ]['slot_count'] = $slot_count;
						} elseif ( ! $manage_capacity ) {
							unset( $slots[ $slot_start ] );
						}

					}

				}

			}
		}

		if ( empty( $slots ) ) {
			Plugin::instance()->db->excluded_dates->insert( array(
				'service'  => $service,
				'provider' => $provider,
				'date'     => $date,
			) );
		}

		return $slots;

	}

	/**
	 * Returns names of excluded week days
	 *
	 * @return [type] [description]
	 */
	public function get_available_week_days() {

		$working_hours = Plugin::instance()->settings->get( 'working_hours' );
		$result        = array();

		foreach ( $working_hours as $week_day => $schedule ) {
			if ( ! empty( $schedule ) ) {
				$result[] = $week_day;
			}
		}

		return $result;

	}

	/**
	 * Returns week days list
	 *
	 * @return [type] [description]
	 */
	public function get_week_days() {
		return array(
			'sunday',
			'monday',
			'tuesday',
			'wednesday',
			'thursday',
			'friday',
			'saturday',
		);
	}

	/**
	 * Returns excluded dates - official days off and booked dates
	 *
	 * @return [type] [description]
	 */
	public function get_excluded_dates( $service = null, $provider = null ) {

		$days_off = Plugin::instance()->settings->get( 'days_off' );
		$result   = array();

		if ( ! empty( $days_off ) ) {
			foreach ( $days_off as $day ) {
				$result[] = strtotime( $day['date'] );
			}
		}

		$query_args = array(
			'date>=' => strtotime( 'today midnight' ),
		);

		if ( ! empty( $service ) && 'service' === Plugin::instance()->settings->get( 'check_by' ) ) {
			$query_args['service'] = $service;
		}

		if ( ! empty( $provider ) ) {
			$query_args['provider'] = $provider;
		}

		$excluded = Plugin::instance()->db->excluded_dates->query( $query_args );

		if ( ! empty( $excluded ) ) {
			foreach ( $excluded as $date ) {
				$result[] = absint( $date['date'] );
			}
		}

		return array_unique( $result );

	}

}
