<?php
namespace JET_APB;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Main file
 */
class Plugin {

	/**
	 * Instance.
	 *
	 * Holds the plugin instance.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @var Plugin
	 */
	public static $instance = null;

	/**
	 * Instance.
	 *
	 * Ensures only one instance of the plugin class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$instance ) ) {

			self::$instance = new self();

		}

		return self::$instance;

	}

	/**
	 * Register autoloader.
	 */
	private function register_autoloader() {
		require JET_APB_PATH . 'includes/autoloader.php';
		Autoloader::run();
	}

	/**
	 * Initialize plugin parts
	 *
	 * @return void
	 */
	public function init_components() {

		$this->db             = new DB\Manager();
		$this->settings       = new Admin\Settings();
		$this->services_meta  = new Admin\Services_Meta();
		$this->setup          = new Set_Up();
		$this->form           = new Form();
		$this->calendar       = new Calendar();
		$this->rest_api       = new Rest_API\Manager();
		$this->wc             = new WC_Integration();
		$this->tools          = new Tools();
		$this->statuses       = new Statuses();

		if ( $this->settings->get( 'providers_cpt' ) ) {
			$this->providers_meta = new Admin\Providers_Meta();
		}

		new Listings();

		if ( is_admin() ) {

			$this->dashboard = new Admin\Dashboard( array(
				new Admin\Pages\Appointments(),
				new Admin\Pages\Settings(),
				new Admin\Pages\Set_Up(),
			) );

			new Updater\Plugin( array(
				'version' => JET_APB_VERSION,
				'slug'    => 'jet-appointments-booking',
			) );

			new Upgrade();

		}

	}

	/**
	 * Plugin constructor.
	 */
	private function __construct() {

		if ( ! function_exists( 'jet_engine' ) ) {
			
			add_action( 'admin_notices', function() {
				$class = 'notice notice-error';
				$message = __( '<b>WARNING!</b> <b>JetAppointmentsBooking</b> plugin requires <b>JetEngine</b> plugin to work properly!', 'jet-appointments-booking' );
				printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), wp_kses_post( $message ) ); 
			} );

			return;
		}

		$this->register_autoloader();

		add_action( 'after_setup_theme', array( $this, 'init_components' ), 0 );
	}

}

Plugin::instance();
