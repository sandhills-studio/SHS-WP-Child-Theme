<div class="cx-vui-tabs-panel" v-show="show">
	<slot></slot>
</div>