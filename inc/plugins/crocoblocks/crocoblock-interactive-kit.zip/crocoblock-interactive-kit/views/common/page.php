<?php
/**
 * Main wizard page
 */
?>
<div class="wrap">
	<div id="croco_ik">
		<cbw-main></cbw-main>
	</div>
</div>
