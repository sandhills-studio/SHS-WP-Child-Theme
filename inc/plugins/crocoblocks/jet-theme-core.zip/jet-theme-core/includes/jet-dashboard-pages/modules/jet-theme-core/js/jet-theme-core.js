(function () {

	'use strict';

	Vue.component( 'jet-theme-core', {
		template: '#jet-dashboard-jet-theme-core',
		data: function() {
			return {
				test: 1
			};
		}
	} );

})();
