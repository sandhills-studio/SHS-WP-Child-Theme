<?php
/**
 * templates loader view
 */
?>
<div class="jet-filters-list"></div>
<div class="jet-templates-wrap">
	<div class="jet-keywords-list"></div>
	<div class="jet-templates-list"></div>
</div>