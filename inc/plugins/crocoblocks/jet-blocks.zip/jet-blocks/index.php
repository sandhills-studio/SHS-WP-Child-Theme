<?php
/**
 * Silence is golden
 *
 * @package  jet-blocks
 * @category Core
 * @author   Zemez
 * @license  GPL-2.0+
 */
