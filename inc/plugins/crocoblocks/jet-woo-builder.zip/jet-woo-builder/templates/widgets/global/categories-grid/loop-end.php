<?php
/**
 * JetWooBuilder Categories Grid widget loop end template.
 */
?>
</div>
