(function () {

	'use strict';

	Vue.component( 'welcome-page', {
		template: '#jet-dashboard-welcome-page',
		data: function() {
			return {};
		}
	} );

})();
