# Jet Compare Wishlist

## Changelog

### 1.1.1
* Updated: JetDashboard to 1.0.12;
* Fixed: Minor bugs.

### 1.1.0
* Added: Option for customizing Heading Tags in widgets;
* Added: Compatibility with new Icons control;
* Added: Jet Dashboard;
* Updated: Stock status style controls;
* Fixed: Minor bugs.

### 1.0.2
* Added: Need helps links to widgets;
* Added: Changelog;
* Added: Jet Popups compatibility;
* Fixed: Minor bugs.

### 1.0.1
* FIX : Bug with add default option.

### 1.0.0