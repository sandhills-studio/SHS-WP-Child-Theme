<?php
/**
 * Main dashboard template
 */
?><div id="jet-cw-settings-page">
	<div class="jet-cw-settings-page">
		<h1 class="cs-vui-title"><?php _e( 'JetCompareWishlist Settings', 'jet-compare-wishlist' ); ?></h1>
		<div class="cx-vui-panel">
			<cx-vui-tabs
				:in-panel="false"
				value="compare-settings"
				layout="vertical">

				<?php do_action( 'jet-cw/settings-page-template/tabs-start' ); ?>

				<cx-vui-tabs-panel
					name="compare-settings"
					label="<?php _e( 'Compare', 'jet-compare-wishlist' ); ?>"
					key="compare-settings">

					<cx-vui-switcher
						name="enable_compare"
						label="<?php _e( 'Enable Compare', 'jet-compare-wishlist' ); ?>"
						description="<?php _e( 'Enable Compare Functionality', 'jet-compare-wishlist' ); ?>"
						:wrapper-css="[ 'equalwidth' ]"
						return-true="true"
						return-false="false"
						v-model="pageOptions['enable_compare'].value">
					</cx-vui-switcher>

					<cx-vui-switcher
						name="save_user_compare_list"
						label="<?php _e( 'Save for logged users', 'jet-compare-wishlist' ); ?>"
						description="<?php _e( 'Enable this option if you want save compare list for logged users', 'jet-compare-wishlist' ); ?>"
						:wrapper-css="[ 'equalwidth' ]"
						return-true="true"
						return-false="false"
						v-model="pageOptions['save_user_compare_list'].value">
					</cx-vui-switcher>

					<cx-vui-select
						name="compare_page"
						label="<?php _e( 'Compare Page', 'jet-compare-wishlist' ); ?>"
						description="<?php _e( 'Choose Compare Page', 'jet-compare-wishlist' ); ?>"
						:wrapper-css="[ 'equalwidth' ]"
						size="fullwidth"
						:options-list="pageOptions.compare_page.options"
						v-model="pageOptions.compare_page.value">
					</cx-vui-select>

					<cx-vui-select
						name="compare_page_max_items"
						label="<?php _e( 'Count products to compare', 'jet-compare-wishlist' ); ?>"
						description="<?php _e( 'Count products to show in compare widget', 'jet-compare-wishlist' ); ?>"
						:wrapper-css="[ 'equalwidth' ]"
						size="fullwidth"
						:options-list="pageOptions.compare_page_max_items.options"
						v-model="pageOptions.compare_page_max_items.value">
					</cx-vui-select>

					<cx-vui-switcher
						name="add_default_compare_button"
						label="<?php _e( 'Add default Compare Button', 'jet-compare-wishlist' ); ?>"
						description="<?php _e( 'Add compare button to default WooCommerce templates', 'jet-compare-wishlist' ); ?>"
						:wrapper-css="[ 'equalwidth' ]"
						return-true="true"
						return-false="false"
						v-model="pageOptions['add_default_compare_button'].value">
					</cx-vui-switcher>

				</cx-vui-tabs-panel>

				<cx-vui-tabs-panel
					name="wishlist-settings"
					label="<?php _e( 'Wishlist', 'jet-compare-wishlist' ); ?>"
					key="wishlist-settings">

					<cx-vui-switcher
						name="enable_wishlist"
						label="<?php _e( 'Enable Wishlist', 'jet-compare-wishlist' ); ?>"
						description="<?php _e( 'Enable Wishlist Functionality', 'jet-compare-wishlist' ); ?>"
						:wrapper-css="[ 'equalwidth' ]"
						return-true="true"
						return-false="false"
						v-model="pageOptions['enable_wishlist'].value">
					</cx-vui-switcher>

					<cx-vui-switcher
						name="save_user_wish_list"
						label="<?php _e( 'Save for logged users', 'jet-compare-wishlist' ); ?>"
						description="<?php _e( 'Enable this option if you want save wish list for logged users', 'jet-compare-wishlist' ); ?>"
						:wrapper-css="[ 'equalwidth' ]"
						return-true="true"
						return-false="false"
						v-model="pageOptions['save_user_wish_list'].value">
					</cx-vui-switcher>

					<cx-vui-select
						name="wishlist_page"
						label="<?php _e( 'Wishlist Page', 'jet-compare-wishlist' ); ?>"
						description="<?php _e( 'Choose Wishlist Page', 'jet-compare-wishlist' ); ?>"
						:wrapper-css="[ 'equalwidth' ]"
						size="fullwidth"
						:options-list="pageOptions.wishlist_page.options"
						v-model="pageOptions.wishlist_page.value">
					</cx-vui-select>

					<cx-vui-switcher
						name="add_default_wishlist_button"
						label="<?php _e( 'Add default Wishlist Button', 'jet-compare-wishlist' ); ?>"
						description="<?php _e( 'Add wishlist button to default WooCommerce templates', 'jet-compare-wishlist' ); ?>"
						:wrapper-css="[ 'equalwidth' ]"
						return-true="true"
						return-false="false"
						v-model="pageOptions['add_default_wishlist_button'].value">
					</cx-vui-switcher>

				</cx-vui-tabs-panel>

				<cx-vui-tabs-panel
					name="available-widgets"
					label="<?php _e( 'Available Widgets', 'jet-compare-wishlist' ); ?>"
					key="available-widgets">

					<div class="avaliable-widgets">
						<div class="avaliable-widgets__option-info">
							<div class="avaliable-widgets__option-info-name"><?php _e( 'Available Widgets', 'jet-compare-wishlist' ); ?></div>
							<div class="avaliable-widgets__option-info-desc"><?php _e( 'List of widgets that will be available when editing the page', 'jet-compare-wishlist' ); ?></div>
						</div>
						<div class="avaliable-widgets__controls">
							<div
								class="avaliable-widgets__control"
								v-for="(option, index) in pageOptions.avaliable_widgets.options">
								<cx-vui-switcher
									:key="index"
									:name="`avaliable-widget-${option.value}`"
									:label="option.label"
									:wrapper-css="[ 'equalwidth' ]"
									return-true="true"
									return-false="false"
									v-model="pageOptions.avaliable_widgets.value[option.value]"
								>
								</cx-vui-switcher>
							</div>
						</div>
					</div>

				</cx-vui-tabs-panel>

				<?php do_action( 'jet-cw/settings-page-template/tabs-end' ); ?>
			</cx-vui-tabs>
		</div>
	</div>
</div>
