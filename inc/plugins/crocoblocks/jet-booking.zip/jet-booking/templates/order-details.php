<?php
/**
 * WooCommerce order details
 */
?>
<h2 class="woocommerce-order-details__title"><?php _e( 'Booking Details', 'jet-appointments-booking' ); ?></h2>
<ul class="woocommerce-order-overview woocommerce-thankyou-order-details order_details">
	<li>
		<strong><?php echo $booking_title; ?></strong>
	</li>
	<li>
		<?php _e( 'Check In', 'jet-appointments-booking' ); ?>: <strong><?php echo $from; ?></strong>
	</li>
	<li>
		<?php _e( 'Check Out', 'jet-appointments-booking' ); ?>: <strong><?php echo $to; ?></strong>
	</li>
</ul>
