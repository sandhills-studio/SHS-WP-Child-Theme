<?php
/**
 * Render check-in checkout fields for bookin form
 */

$placeholder = ! empty( $args['first_field_placeholder'] ) ? esc_attr( $args['first_field_placeholder'] ) : '';
$default     = ! empty( $args['default'] ) ? esc_attr( $args['default'] ) : '';

if ( jet_abaf()->engine_plugin->default ) {
	$default = sprintf( '%1$s - %2$s', jet_abaf()->engine_plugin->default['checkin'], jet_abaf()->engine_plugin->default['checkout'] );
}

?>
<div class="jet-abaf-field">
	<input
		type="text"
		id="jet_abaf_field"
		class="jet-abaf-field__input jet-form__field"
		placeholder="<?php echo $placeholder; ?>"
		autocomplete="off"
		data-field="checkin-checkout"
		name="<?php echo $args['name']; ?>"
		<?php if ( ! empty( $args['required'] ) ) {
			echo 'required';
		} ?>
		value="<?php echo $default; ?>"
	>
</div>