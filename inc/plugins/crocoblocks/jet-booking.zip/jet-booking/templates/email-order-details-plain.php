<?php
/**
 * WooCommerce order details
 */
?>
<?php _e( 'Booking Details', 'jet-appointments-booking' ); ?>
<?php echo $booking_title; ?>
- <?php _e( 'Check In', 'jet-appointments-booking' ); ?>: <?php echo $from; ?>
- <?php _e( 'Check Out', 'jet-appointments-booking' ); ?>: <?php echo $to; ?>
