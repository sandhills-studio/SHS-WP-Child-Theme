<?php
/**
 * WooCommerce order details
 */
?>
<h2 style="color:#96588a;display:block;font-family:'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif;font-size:18px;font-weight:bold;line-height:130%;margin:0 0 18px;text-align:left"><?php
	_e( 'Booking Details', 'jet-appointments-booking' );
?></h2>
<ul>
	<li><b><em><?php echo $booking_title; ?></em></b></li>
	<li>
		<em><?php _e( 'Check In', 'jet-appointments-booking' ); ?>: <b><?php echo $from; ?></b></em>
	</li>
	<li>
		<em><?php _e( 'Check Out', 'jet-appointments-booking' ); ?>: <b><?php echo $to; ?></b></em>
	</li>
</ul>
