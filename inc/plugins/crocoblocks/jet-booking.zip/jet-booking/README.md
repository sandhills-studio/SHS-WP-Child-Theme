# ChangeLog

## 2.1.1
* FIX: WC product creation.

## 2.1.0
* ADD: Added Booking Availability Calendar widget;
* ADD: Allow to add booking details to WooCommerce checkout fields;
* ADD: Added Property Rates Based on the length of stay;
* ADD: Allow to add booking details to WooCommerce orders;
* ADD: Allow ability for users to add a booking to their calendar.
* FIX: Fixed minor bugs.
