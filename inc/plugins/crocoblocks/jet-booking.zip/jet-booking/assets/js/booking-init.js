(function () {

	var picker;
	var head = document.getElementsByTagName( 'head' )[0];
	var link = document.createElement( 'link' );

	link.rel   = 'stylesheet';
	link.type  = 'text/css';
	link.href  = window.JetABAFData.css_url;
	link.media = 'all';

	head.appendChild( link );

	validateDay = function( t ) {
		var formated = moment( t ).format( 'YYYY-MM-DD' ),
			valid    = true,
			_class   = '',
			_tooltip = '';

		if ( window.JetABAFData.booked_dates.length && 0 <= window.JetABAFData.booked_dates.indexOf( formated ) ) {
			valid    = false;
			_tooltip = window.JetABAFData.labels.booked;
		}

		return [ valid, _class, _tooltip ];

	};

	jQuery( document ).on( 'jet-engine/booking-form/init', function() {

		var config = {
			separator : ' - ',
			autoClose: true,
			startDate: new Date(),
			selectForward: true,
			beforeShowDay: validateDay,
			excludedDates: window.JetABAFData.booked_dates,
			perNights: window.JetABAFData.per_nights,
		};

		if ( window.JetABAFData.custom_labels ) {
			jQuery.dateRangePickerLanguages['custom'] = window.JetABAFData.labels;
			config.language = 'custom';
		}

		if ( window.JetABAFData.field_format ) {
			config.format = window.JetABAFData.field_format;
		}		

		if ( window.JetABAFData.weekly_bookings ) {
			config.batchMode     = 'week';
			config.showShortcuts = false;

			if ( window.JetABAFData.week_offset ) {
				config.weekOffset = parseInt( window.JetABAFData.week_offset, 10 );
				console.log( config.weekOffset );
			}

		} else if ( window.JetABAFData.one_day_bookings ) {
			config.singleDate = true;
		}

		if ( 'single' === window.JetABAFData.layout ) {
			var $field = jQuery( '#jet_abaf_field' );
			config.container = '.jet-abaf-field';

			config.setValue = function( s, s1, s2 ) {
				$field.val( s ).trigger( 'change.JetEngine' );
			};

			$field.dateRangePicker( config );
		} else {

			var $checkIn  = jQuery( '#jet_abaf_field_1' ),
				$checkOut = jQuery( '#jet_abaf_field_2' ),
				$result   = jQuery( '#jet_abaf_field_range' );

			config.container = '.jet-abaf-separate-fields';

			config.getValue = function() {
				if ( $checkIn.val() && $checkOut.val() )
					return $checkIn.val() + ' - ' + $checkOut.val();
				else
					return '';
			};

			config.setValue = function( s, s1, s2 ) {

				if ( s === s1 ) {
					s2 = s1;
				}

				$checkIn.val( s1 );
				$checkOut.val( s2 );
				$result.val( s ).trigger( 'change.JetEngine' );
			};

			jQuery( '.jet-abaf-separate-fields' ).dateRangePicker( config );

		}

		window.JetEngine.filters.addFilter( 'forms/calculated-field-value', function( value, $field ) {

			if ( 'checkin-checkout' !== $field.data( 'field' ) ) {
				return value;
			} else {

				var dateFormat = "YYYY-MM-DD";

				if ( window.JetABAFData.one_day_bookings ) {
					return 1;
				}

				if ( 1 < value.length ) {
					value = value.split( ' - ' );

					if ( window.JetABAFData.field_format ) {
						dateFormat = window.JetABAFData.field_format;
					}

					var startDate = moment( value[0], dateFormat );
					var endDate   = moment( value[1], dateFormat );

					value = endDate.diff( startDate, 'days' );
					value = parseInt( value, 10 );

					if ( ! window.JetABAFData.per_nights ) {
						value++;
					}

				}

				return value;
			}

		} );

	} );

}());