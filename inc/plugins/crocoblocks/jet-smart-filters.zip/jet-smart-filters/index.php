<?php
/**
 * Silence is golden.
 */