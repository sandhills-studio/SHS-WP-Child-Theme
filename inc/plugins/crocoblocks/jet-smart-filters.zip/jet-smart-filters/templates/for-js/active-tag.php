<?php
/**
 * Active tag item content
 */

?>
<% if ($value) { %>
	<div class="jet-active-tag__val"><% $value %></div>
<% } %>
<div class="jet-active-tag__remove">&times;</div>